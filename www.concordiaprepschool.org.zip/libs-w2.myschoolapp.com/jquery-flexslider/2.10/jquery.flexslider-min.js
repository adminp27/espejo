! function(e) {
    e.flexslider = function(t, a) {
        var i = e(t);
        i.vars = e.extend({}, e.flexslider.defaults, a);
        var n, s = i.vars.namespace,
            r = window.navigator && window.navigator.msPointerEnabled && window.MSGesture,
            o = ("ontouchstart" in window || r || window.DocumentTouch && document instanceof DocumentTouch) && i.vars.touch,
            l = "click touchend MSPointerUp keyup",
            c = "",
            d = "vertical" === i.vars.direction,
            u = i.vars.reverse,
            v = i.vars.itemWidth > 0,
            m = "fade" === i.vars.animation,
            p = "" !== i.vars.asNavFor,
            f = {};
        e.data(t, "flexslider", i), f = {
            init: function() {
                i.animating = !1, i.currentSlide = parseInt(i.vars.startAt ? i.vars.startAt : 0, 10), isNaN(i.currentSlide) && (i.currentSlide = 0), i.animatingTo = i.currentSlide, i.atEnd = 0 === i.currentSlide || i.currentSlide === i.last, i.containerSelector = i.vars.selector.substr(0, i.vars.selector.search(" ")), i.slides = e(i.vars.selector, i), i.container = e(i.containerSelector, i), i.count = i.slides.length, i.syncExists = e(i.vars.sync).length > 0, "slide" === i.vars.animation && (i.vars.animation = "swing"), i.prop = d ? "top" : "marginLeft", i.args = {}, i.manualPause = !1, i.stopped = !1, i.started = !1, i.startTimeout = null, i.transitions = !i.vars.video && !m && i.vars.useCSS && function() {
                    var e = document.createElement("div"),
                        t = ["perspectiveProperty", "WebkitPerspective", "MozPerspective", "OPerspective", "msPerspective"];
                    for (var a in t)
                        if (void 0 !== e.style[t[a]]) return i.pfx = t[a].replace("Perspective", "").toLowerCase(), i.prop = "-" + i.pfx + "-transform", !0;
                    return !1
                }(), i.ensureAnimationEnd = "", "" !== i.vars.controlsContainer && (i.controlsContainer = e(i.vars.controlsContainer).length > 0 && e(i.vars.controlsContainer)), "" !== i.vars.manualControls && (i.manualControls = e(i.vars.manualControls).length > 0 && e(i.vars.manualControls)), i.vars.randomize && (i.slides.sort(function() {
                    return Math.round(Math.random()) - .5
                }), i.container.empty().append(i.slides)), i.doMath(), i.setup("init"), i.vars.controlNav && f.controlNav.setup(), i.vars.directionNav && f.directionNav.setup(), i.vars.keyboard && (1 === e(i.containerSelector).length || i.vars.multipleKeyboard) && e(document).bind("keyup", function(e) {
                    var t = e.keyCode;
                    if (!i.animating && (39 === t || 37 === t)) {
                        var a = 39 === t ? i.getTarget("next") : 37 === t && i.getTarget("prev");
                        i.flexAnimate(a, i.vars.pauseOnAction)
                    }
                }), i.vars.mousewheel && i.bind("mousewheel", function(e, t, a, n) {
                    e.preventDefault();
                    var s = t < 0 ? i.getTarget("next") : i.getTarget("prev");
                    i.flexAnimate(s, i.vars.pauseOnAction)
                }), i.vars.pausePlay && f.pausePlay.setup(), i.vars.slideshow && i.vars.pauseInvisible && f.pauseInvisible.init(), i.vars.slideshow && (i.vars.pauseOnHover && i.hover(function() {
                    i.manualPlay || i.manualPause || i.pause()
                }, function() {
                    i.manualPause || i.manualPlay || i.stopped || i.play()
                }), i.vars.pauseInvisible && f.pauseInvisible.isHidden() || (i.vars.initDelay > 0 ? i.startTimeout = setTimeout(i.play, i.vars.initDelay) : i.play())), p && f.asNav.setup(), o && i.vars.touch && f.touch(), (!m || m && i.vars.smoothHeight) && e(window).bind("resize orientationchange focus", f.resize), i.find("img").attr("draggable", "false"), setTimeout(function() {
                    i.vars.start(i)
                }, 200)
            },
            asNav: {
                setup: function() {
                    i.asNav = !0, i.animatingTo = Math.floor(i.currentSlide / i.move), i.currentItem = i.currentSlide, i.slides.removeClass(s + "active-slide").eq(i.currentItem).addClass(s + "active-slide"), r ? (t._slider = i, i.slides.each(function() {
                        this._gesture = new MSGesture, this._gesture.target = this, this.addEventListener("MSPointerDown", function(e) {
                            e.preventDefault(), e.currentTarget._gesture && e.currentTarget._gesture.addPointer(e.pointerId)
                        }, !1), this.addEventListener("MSGestureTap", function(t) {
                            t.preventDefault();
                            var a = e(this),
                                n = a.index();
                            e(i.vars.asNavFor).data("flexslider").animating || a.hasClass("active") || (i.direction = i.currentItem < n ? "next" : "prev", i.flexAnimate(n, i.vars.pauseOnAction, !1, !0, !0))
                        })
                    })) : i.slides.on(l, function(t) {
                        t.preventDefault();
                        var a = e(this),
                            n = a.index();
                        a.offset().left - e(i).scrollLeft() <= 0 && a.hasClass(s + "active-slide") ? i.flexAnimate(i.getTarget("prev"), !0) : e(i.vars.asNavFor).data("flexslider").animating || a.hasClass(s + "active-slide") || (i.direction = i.currentItem < n ? "next" : "prev", i.flexAnimate(n, i.vars.pauseOnAction, !1, !0, !0))
                    })
                }
            },
            controlNav: {
                setup: function() {
                    i.manualControls ? f.controlNav.setupManual() : f.controlNav.setupPaging()
                },
                setupPaging: function() {
                    var t, a, n = "thumbnails" === i.vars.controlNav ? "control-thumbs" : "control-paging",
                        r = 1;
                    if (i.controlNavScaffold = e('<ol class="' + s + "control-nav " + s + n + '"></ol>'), i.pagingCount > 1)
                        for (var o = 0; o < i.pagingCount; o++) {
                            if (a = i.slides.eq(o), t = "thumbnails" === i.vars.controlNav ? '<img src="' + a.attr("data-thumb") + '"/>' : "<a>" + r + "</a>", "thumbnails" === i.vars.controlNav && !0 === i.vars.thumbCaptions) {
                                var d = a.attr("data-thumbcaption");
                                "" != d && null != d && (t += '<span class="' + s + 'caption">' + d + "</span>")
                            }
                            i.controlNavScaffold.append("<li>" + t + "</li>"), r++
                        }
                    i.controlsContainer ? e(i.controlsContainer).append(i.controlNavScaffold) : i.append(i.controlNavScaffold), f.controlNav.set(), f.controlNav.active(), i.controlNavScaffold.delegate("a, img", l, function(t) {
                        if (t.preventDefault(), "" === c || c === t.type) {
                            var a = e(this),
                                n = i.controlNav.index(a);
                            a.hasClass(s + "active") || (i.direction = n > i.currentSlide ? "next" : "prev", i.flexAnimate(n, i.vars.pauseOnAction))
                        }
                        "" === c && (c = t.type), f.setToClearWatchedEvent()
                    })
                },
                setupManual: function() {
                    i.controlNav = i.manualControls, f.controlNav.active(), i.controlNav.bind(l, function(t) {
                        if (t.preventDefault(), "" === c || c === t.type) {
                            var a = e(this),
                                n = i.controlNav.index(a);
                            a.hasClass(s + "active") || (n > i.currentSlide ? i.direction = "next" : i.direction = "prev", i.flexAnimate(n, i.vars.pauseOnAction))
                        }
                        "" === c && (c = t.type), f.setToClearWatchedEvent()
                    })
                },
                set: function() {
                    var t = "thumbnails" === i.vars.controlNav ? "img" : "a";
                    i.controlNav = e("." + s + "control-nav li " + t, i.controlsContainer ? i.controlsContainer : i)
                },
                active: function() {
                    i.controlNav.removeClass(s + "active").eq(i.animatingTo).addClass(s + "active")
                },
                update: function(t, a) {
                    i.pagingCount > 1 && "add" === t ? i.controlNavScaffold.append(e("<li><a>" + i.count + "</a></li>")) : 1 === i.pagingCount ? i.controlNavScaffold.find("li").remove() : i.controlNav.eq(a).closest("li").remove(), f.controlNav.set(), i.pagingCount > 1 && i.pagingCount !== i.controlNav.length ? i.update(a, t) : f.controlNav.active()
                }
            },
            directionNav: {
                setup: function() {
                    var t = e('<ul class="' + s + 'direction-nav"><li><a class="' + s + 'prev" href="#">' + i.vars.prevText + '</a></li><li><a class="' + s + 'next" href="#">' + i.vars.nextText + "</a></li></ul>");
                    i.controlsContainer ? (e(i.controlsContainer).append(t), i.directionNav = e("." + s + "direction-nav li a", i.controlsContainer)) : (i.append(t), i.directionNav = e("." + s + "direction-nav li a", i)), f.directionNav.update(), i.directionNav.bind(l, function(t) {
                        var a;
                        t.preventDefault(), "" !== c && c !== t.type || (a = e(this).hasClass(s + "next") ? i.getTarget("next") : i.getTarget("prev"), i.flexAnimate(a, i.vars.pauseOnAction)), "" === c && (c = t.type), f.setToClearWatchedEvent()
                    })
                },
                update: function() {
                    var e = s + "disabled";
                    1 === i.pagingCount ? i.directionNav.addClass(e).attr("tabindex", "-1") : i.vars.animationLoop ? i.directionNav.removeClass(e).removeAttr("tabindex") : 0 === i.animatingTo ? i.directionNav.removeClass(e).filter("." + s + "prev").addClass(e).attr("tabindex", "-1") : i.animatingTo === i.last ? i.directionNav.removeClass(e).filter("." + s + "next").addClass(e).attr("tabindex", "-1") : i.directionNav.removeClass(e).removeAttr("tabindex")
                }
            },
            pausePlay: {
                setup: function() {
                    var t = e('<div class="' + s + 'pauseplay"><a></a></div>');
                    i.controlsContainer ? (i.controlsContainer.append(t), i.pausePlay = e("." + s + "pauseplay a", i.controlsContainer)) : (i.append(t), i.pausePlay = e("." + s + "pauseplay a", i)), f.pausePlay.update(i.vars.slideshow ? s + "pause" : s + "play"), i.pausePlay.bind(l, function(t) {
                        t.preventDefault(), "" !== c && c !== t.type || (e(this).hasClass(s + "pause") ? (i.manualPause = !0, i.manualPlay = !1, i.pause()) : (i.manualPause = !1, i.manualPlay = !0, i.play())), "" === c && (c = t.type), f.setToClearWatchedEvent()
                    })
                },
                update: function(e) {
                    "play" === e ? i.pausePlay.removeClass(s + "pause").addClass(s + "play").html(i.vars.playText) : i.pausePlay.removeClass(s + "play").addClass(s + "pause").html(i.vars.pauseText)
                }
            },
            touch: function() {
                var e, a, n, s, o, l, c = !1,
                    p = 0,
                    f = 0,
                    h = 0;
                if (r) {
                    t.style.msTouchAction = "none", t._gesture = new MSGesture, t._gesture.target = t, t.addEventListener("MSPointerDown", function(e) {
                        e.stopPropagation(), i.animating ? e.preventDefault() : (i.pause(), t._gesture.addPointer(e.pointerId), h = 0, s = d ? i.h : i.w, l = Number(new Date), n = v && u && i.animatingTo === i.last ? 0 : v && u ? i.limit - (i.itemW + i.vars.itemMargin) * i.move * i.animatingTo : v && i.currentSlide === i.last ? i.limit : v ? (i.itemW + i.vars.itemMargin) * i.move * i.currentSlide : u ? (i.last - i.currentSlide + i.cloneOffset) * s : (i.currentSlide + i.cloneOffset) * s)
                    }, !1), t._slider = i, t.addEventListener("MSGestureChange", function(e) {
                        e.stopPropagation();
                        var a = e.target._slider;
                        if (!a) return;
                        var i = -e.translationX,
                            r = -e.translationY;
                        if (o = h += d ? r : i, c = d ? Math.abs(h) < Math.abs(-i) : Math.abs(h) < Math.abs(-r), e.detail === e.MSGESTURE_FLAG_INERTIA) return void setImmediate(function() {
                            t._gesture.stop()
                        });
                        (!c || Number(new Date) - l > 500) && (e.preventDefault(), !m && a.transitions && (a.vars.animationLoop || (o = h / (0 === a.currentSlide && h < 0 || a.currentSlide === a.last && h > 0 ? Math.abs(h) / s + 2 : 1)), a.setProps(n + o, "setTouch")))
                    }, !1), t.addEventListener("MSGestureEnd", function(t) {
                        t.stopPropagation();
                        var i = t.target._slider;
                        if (!i) return;
                        if (i.animatingTo === i.currentSlide && !c && null !== o) {
                            var r = u ? -o : o,
                                d = r > 0 ? i.getTarget("next") : i.getTarget("prev");
                            i.canAdvance(d) && (Number(new Date) - l < 550 && Math.abs(r) > 50 || Math.abs(r) > s / 2) ? i.flexAnimate(d, i.vars.pauseOnAction) : m || i.flexAnimate(i.currentSlide, i.vars.pauseOnAction, !0)
                        }
                        e = null, a = null, o = null, n = null, h = 0
                    }, !1)
                } else {
                    function g(t) {
                        p = t.touches[0].pageX, f = t.touches[0].pageY, o = d ? e - f : e - p;
                        (!(c = d ? Math.abs(o) < Math.abs(p - a) : Math.abs(o) < Math.abs(f - a)) || Number(new Date) - l > 500) && (t.preventDefault(), !m && i.transitions && (i.vars.animationLoop || (o /= 0 === i.currentSlide && o < 0 || i.currentSlide === i.last && o > 0 ? Math.abs(o) / s + 2 : 1), i.setProps(n + o, "setTouch")))
                    }

                    function S(r) {
                        if (t.removeEventListener("touchmove", g, !1), i.animatingTo === i.currentSlide && !c && null !== o) {
                            var d = u ? -o : o,
                                v = d > 0 ? i.getTarget("next") : i.getTarget("prev");
                            i.canAdvance(v) && (Number(new Date) - l < 550 && Math.abs(d) > 50 || Math.abs(d) > s / 2) ? i.flexAnimate(v, i.vars.pauseOnAction) : m || i.flexAnimate(i.currentSlide, i.vars.pauseOnAction, !0)
                        }
                        t.removeEventListener("touchend", S, !1), e = null, a = null, o = null, n = null
                    }
                    t.addEventListener("touchstart", function(r) {
                        i.animating ? r.preventDefault() : (window.navigator.msPointerEnabled || 1 === r.touches.length) && (i.pause(), s = d ? i.h : i.w, l = Number(new Date), p = r.touches[0].pageX, f = r.touches[0].pageY, n = v && u && i.animatingTo === i.last ? 0 : v && u ? i.limit - (i.itemW + i.vars.itemMargin) * i.move * i.animatingTo : v && i.currentSlide === i.last ? i.limit : v ? (i.itemW + i.vars.itemMargin) * i.move * i.currentSlide : u ? (i.last - i.currentSlide + i.cloneOffset) * s : (i.currentSlide + i.cloneOffset) * s, e = d ? f : p, a = d ? p : f, t.addEventListener("touchmove", g, !1), t.addEventListener("touchend", S, !1))
                    }, !1)
                }
            },
            resize: function() {
                !i.animating && i.is(":visible") && (v || i.doMath(), m ? f.smoothHeight() : v ? (d ? i.slides.height(i.computedH) : i.slides.width(i.computedW), i.update(i.pagingCount), i.setProps()) : d ? (i.viewport.height(i.h), i.setProps(i.h, "setTotal")) : (i.vars.smoothHeight && f.smoothHeight(), i.newSlides.width(i.computedW), i.setProps(i.computedW, "setTotal")))
            },
            smoothHeight: function(e) {
                if (!d || m) {
                    var t = m ? i : i.viewport,
                        a = i.slides.eq(i.animatingTo).height();
                    m && 0 === a && (a = t.height()), e ? t.animate({
                        height: a
                    }, e) : t.height(a)
                }
            },
            sync: function(t) {
                var a = e(i.vars.sync).data("flexslider"),
                    n = i.animatingTo;
                switch (t) {
                    case "animate":
                        a.flexAnimate(n, i.vars.pauseOnAction, !1, !0);
                        break;
                    case "play":
                        a.playing || a.asNav || a.play();
                        break;
                    case "pause":
                        a.pause()
                }
            },
            uniqueID: function(t) {
                return t.filter("[id]").add(t.find("[id]")).each(function() {
                    var t = e(this);
                    t.attr("id", t.attr("id") + "_clone")
                }), t
            },
            pauseInvisible: {
                visProp: null,
                init: function() {
                    var e = ["webkit", "moz", "ms", "o"];
                    if ("hidden" in document) return "hidden";
                    for (var t = 0; t < e.length; t++) e[t] + "Hidden" in document && (f.pauseInvisible.visProp = e[t] + "Hidden");
                    if (f.pauseInvisible.visProp) {
                        var a = f.pauseInvisible.visProp.replace(/[H|h]idden/, "") + "visibilitychange";
                        document.addEventListener(a, function() {
                            f.pauseInvisible.isHidden() ? i.startTimeout ? clearTimeout(i.startTimeout) : i.pause() : i.started ? i.play() : i.vars.initDelay > 0 ? setTimeout(i.play, i.vars.initDelay) : i.play()
                        })
                    }
                },
                isHidden: function() {
                    return document[f.pauseInvisible.visProp] || !1
                }
            },
            setToClearWatchedEvent: function() {
                clearTimeout(n), n = setTimeout(function() {
                    c = ""
                }, 3e3)
            }
        }, i.flexAnimate = function(t, a, n, r, l) {
            if (i.vars.animationLoop || t === i.currentSlide || (i.direction = t > i.currentSlide ? "next" : "prev"), p && 1 === i.pagingCount && (i.direction = i.currentItem < t ? "next" : "prev"), !i.animating && (i.canAdvance(t, l) || n) && i.is(":visible")) {
                if (p && r) {
                    var c = e(i.vars.asNavFor).data("flexslider");
                    if (i.atEnd = 0 === t || t === i.count - 1, c.flexAnimate(t, !0, !1, !0, l), i.direction = i.currentItem < t ? "next" : "prev", c.direction = i.direction, Math.ceil((t + 1) / i.visible) - 1 === i.currentSlide || 0 === t) return i.currentItem = t, i.slides.removeClass(s + "active-slide").eq(t).addClass(s + "active-slide"), !1;
                    i.currentItem = t, i.slides.removeClass(s + "active-slide").eq(t).addClass(s + "active-slide"), t = Math.floor(t / i.visible)
                }
                if (i.animating = !0, i.animatingTo = t, a && i.pause(), i.vars.before(i), i.syncExists && !l && f.sync("animate"), i.vars.controlNav && f.controlNav.active(), v || i.slides.removeClass(s + "active-slide").eq(t).addClass(s + "active-slide"), i.atEnd = 0 === t || t === i.last, i.vars.directionNav && f.directionNav.update(), t === i.last && (i.vars.end(i), i.vars.animationLoop || i.pause()), m) o ? (i.slides.eq(i.currentSlide).css({
                    opacity: 0,
                    zIndex: 1
                }), i.slides.eq(t).css({
                    opacity: 1,
                    zIndex: 2
                }), i.wrapup(x)) : (i.slides.eq(i.currentSlide).css({
                    zIndex: 1
                }).animate({
                    opacity: 0
                }, i.vars.animationSpeed, i.vars.easing), i.slides.eq(t).css({
                    zIndex: 2
                }).animate({
                    opacity: 1
                }, i.vars.animationSpeed, i.vars.easing, i.wrapup));
                else {
                    var h, g, S, x = d ? i.slides.filter(":first").height() : i.computedW;
                    v ? d ? (h = i.vars.itemHeight > i.h ? 2 * i.vars.itemMargin : i.vars.itemMargin, g = (S = (i.itemH + h) * i.move * i.animatingTo) > i.limit && 1 !== i.visible ? i.limit : S) : (h = i.vars.itemMargin, g = (S = (i.itemW + h) * i.move * i.animatingTo) > i.limit && 1 !== i.visible ? i.limit : S) : g = 0 === i.currentSlide && t === i.count - 1 && i.vars.animationLoop && "next" !== i.direction ? u ? (i.count + i.cloneOffset) * x : 0 : i.currentSlide === i.last && 0 === t && i.vars.animationLoop && "prev" !== i.direction ? u ? 0 : (i.count + 1) * x : u ? (i.count - 1 - t + i.cloneOffset) * x : (t + i.cloneOffset) * x, d && p && (g = (i.itemH + h) * (i.last !== i.animatingTo ? i.last - i.animatingTo : 1) < i.find(".flex-viewport").height() ? i.itemH * i.count - i.find(".flex-viewport").height() : S), i.setProps(g, "", i.vars.animationSpeed), i.transitions ? (i.vars.animationLoop && i.atEnd || (i.animating = !1, i.currentSlide = i.animatingTo), i.container.unbind("webkitTransitionEnd transitionend"), i.container.bind("webkitTransitionEnd transitionend", function() {
                        clearTimeout(i.ensureAnimationEnd), i.wrapup(x)
                    }), clearTimeout(i.ensureAnimationEnd), i.ensureAnimationEnd = setTimeout(function() {
                        i.wrapup(x)
                    }, i.vars.animationSpeed + 100)) : i.container.animate(i.args, i.vars.animationSpeed, i.vars.easing, function() {
                        i.wrapup(x)
                    })
                }
                i.vars.smoothHeight && f.smoothHeight(i.vars.animationSpeed)
            }
        }, i.wrapup = function(e) {
            m || v || (0 === i.currentSlide && i.animatingTo === i.last && i.vars.animationLoop ? i.setProps(e, "jumpEnd") : i.currentSlide === i.last && 0 === i.animatingTo && i.vars.animationLoop && i.setProps(e, "jumpStart")), i.animating = !1, i.currentSlide = i.animatingTo, i.vars.after(i)
        }, i.animateSlides = function() {
            i.animating || i.flexAnimate(i.getTarget("next"))
        }, i.pause = function() {
            clearInterval(i.animatedSlides), i.animatedSlides = null, i.playing = !1, i.vars.pausePlay && f.pausePlay.update("play"), i.syncExists && f.sync("pause")
        }, i.play = function() {
            i.playing && clearInterval(i.animatedSlides), i.animatedSlides = i.animatedSlides || setInterval(i.animateSlides, i.vars.slideshowSpeed), i.started = i.playing = !0, i.vars.pausePlay && f.pausePlay.update("pause"), i.syncExists && f.sync("play")
        }, i.stop = function() {
            i.pause(), i.stopped = !0
        }, i.canAdvance = function(e, t) {
            var a = p ? i.pagingCount - 1 : i.last;
            return !!t || (!(!p || i.currentItem !== i.count - 1 || 0 !== e || "prev" !== i.direction) || (!p || 0 !== i.currentItem || e !== i.pagingCount - 1 || "next" === i.direction) && (!(e === i.currentSlide && !p) && (!!i.vars.animationLoop || (!i.atEnd || 0 !== i.currentSlide || e !== a || "next" === i.direction) && (!i.atEnd || i.currentSlide !== a || 0 !== e || "next" !== i.direction))))
        }, i.getTarget = function(e) {
            return i.direction = e, "next" === e ? i.currentSlide === i.last ? 0 : i.currentSlide + 1 : 0 === i.currentSlide ? i.last : i.currentSlide - 1
        }, i.setProps = function(e, t, a) {
            var n, s = (n = e || (i.itemW + i.vars.itemMargin) * i.move * i.animatingTo, -1 * function() {
                if (v) return d ? "setTouch" === t || p ? e : u && i.animatingTo === i.last ? 0 : u ? i.limit - (i.itemH + i.vars.itemMargin) * i.move * i.animatingTo : i.animatingTo === i.last ? i.limit : n : "setTouch" === t ? e : u && i.animatingTo === i.last ? 0 : u ? i.limit - (i.itemW + i.vars.itemMargin) * i.move * i.animatingTo : i.animatingTo === i.last ? i.limit : n;
                switch (t) {
                    case "setTotal":
                        return u ? (i.count - 1 - i.currentSlide + i.cloneOffset) * e : (i.currentSlide + i.cloneOffset) * e;
                    case "setTouch":
                        return e;
                    case "jumpEnd":
                        return u ? e : i.count * e;
                    case "jumpStart":
                        return u ? i.count * e : e;
                    default:
                        return e
                }
            }() + "px");
            i.transitions && (s = d ? "translate3d(0," + s + ",0)" : "translate3d(" + s + ",0,0)", a = void 0 !== a ? a / 1e3 + "s" : "0s", i.container.css("-" + i.pfx + "-transition-duration", a), i.container.css("transition-duration", a)), i.args[i.prop] = s, (i.transitions || void 0 === a) && i.container.css(i.args), i.container.css("transform", s)
        }, i.setup = function(t) {
            var a, n;
            if (m) i.slides.css({
                width: "100%",
                float: "left",
                marginRight: "-100%",
                position: "relative"
            }), "init" === t && (o ? i.slides.css({
                opacity: 0,
                display: "block",
                webkitTransition: "opacity " + i.vars.animationSpeed / 1e3 + "s ease",
                zIndex: 1
            }).eq(i.currentSlide).css({
                opacity: 1,
                zIndex: 2
            }) : 0 == i.vars.fadeFirstSlide ? i.slides.css({
                opacity: 0,
                display: "block",
                zIndex: 1
            }).eq(i.currentSlide).css({
                zIndex: 2
            }).css({
                opacity: 1
            }) : i.slides.css({
                opacity: 0,
                display: "block",
                zIndex: 1
            }).eq(i.currentSlide).css({
                zIndex: 2
            }).animate({
                opacity: 1
            }, i.vars.animationSpeed, i.vars.easing)), i.vars.smoothHeight && f.smoothHeight();
            else if ("init" === t && (i.viewport = e('<div class="' + s + 'viewport"></div>').css({
                    overflow: "hidden",
                    position: "relative"
                }).appendTo(i).append(i.container), i.cloneCount = 0, i.cloneOffset = 0, u && (n = e.makeArray(i.slides).reverse(), i.slides = e(n), i.container.empty().append(i.slides))), i.vars.animationLoop && !v && (i.cloneCount = 2, i.cloneOffset = 1, "init" !== t && i.container.find(".clone").remove(), i.container.append(f.uniqueID(i.slides.first().clone().addClass("clone")).attr("aria-hidden", "true")).prepend(f.uniqueID(i.slides.last().clone().addClass("clone")).attr("aria-hidden", "true"))), i.newSlides = e(i.vars.selector, i), a = u ? i.count - 1 - i.currentSlide + i.cloneOffset : i.currentSlide + i.cloneOffset, d && !v) i.container.height(200 * (i.count + i.cloneCount) + "%").css("position", "absolute").width("100%"), setTimeout(function() {
                i.newSlides.css({
                    display: "block"
                }), i.doMath(), i.viewport.height(i.h), i.setProps(a * i.h, "init")
            }, "init" === t ? 150 : 0);
            else if (d && v) {
                var r = 0;
                i.container.width(i.computedW), setTimeout(function() {
                    i.newSlides.css({
                        display: "block"
                    }), i.doMath(), i.viewport.height(i.h), i.setProps(a * i.h, "init"), i.slides.each(function() {
                        r += e(this).outerHeight()
                    }), i.container.height(r)
                }, "init" === t ? 150 : 0)
            } else i.container.width(200 * (i.count + i.cloneCount) + "%"), setTimeout(function() {
                i.doMath(), i.setProps(a * i.computedW, "init"), i.newSlides.css({
                    width: i.computedW,
                    float: "left",
                    display: "block"
                }), i.vars.smoothHeight && f.smoothHeight()
            }, "init" === t ? 150 : 0);
            v || i.slides.removeClass(s + "active-slide").eq(i.currentSlide).addClass(s + "active-slide"), i.vars.init(i)
        }, i.doMathNew = function() {
            var e = i.slides.first(),
                t = i.vars.itemMargin,
                a = i.vars.minItems,
                n = i.vars.maxItems;
            i.w = void 0 === i.viewport ? i.width() : i.viewport.width(), i.h = e.height(), i.boxPadding = e.outerWidth() - e.width(), v ? (i.itemT = i.vars.itemWidth + t, i.minW = a ? a * i.itemT : i.w, i.maxW = n ? n * i.itemT - t : i.w, i.itemW = i.minW > i.w ? (i.w - t * (a - 1)) / a : i.maxW < i.w ? (i.w - t * (n - 1)) / n : i.vars.itemWidth > i.w ? i.w : i.vars.itemWidth, i.visible = Math.floor(i.w / i.itemW), i.move = i.vars.move > 0 && i.vars.move < i.visible ? i.vars.move : i.visible, i.pagingCount = Math.ceil((i.count - i.visible) / i.move + 1), i.last = i.pagingCount - 1, i.limit = 1 === i.pagingCount ? 0 : i.vars.itemWidth > i.w ? i.itemW * (i.count - 1) + t * (i.count - 1) : (i.itemW + t) * i.count - i.w - t) : (i.itemW = i.w, i.pagingCount = i.count, i.last = i.count - 1), i.computedW = i.itemW - i.boxPadding
        }, i.doMath = function() {
            var e = i.slides.first(),
                t = i.vars.itemMargin,
                a = i.vars.minItems,
                n = i.vars.maxItems;
            i.w = i.width(), i.h = e.height(), i.boxWPadding = e.outerWidth() - e.width(), i.boxHPadding = e.outerHeight() - e.height(), v ? (d && void 0 !== i.master && (i.h = i.master.data("flexslider").h), i.itemHT = i.vars.itemHeight + t, i.minH = a ? a * i.itemHT : i.h, i.maxH = n ? n * i.itemHT : i.h, i.itemH = i.minH > i.h ? (i.h - t * a) / a : i.maxH < i.h ? (i.h - t * n) / n : i.vars.itemHeight > i.h ? i.h : i.vars.itemHeight, i.itemWT = i.vars.itemWidth + t, i.minW = a ? a * i.itemWT : i.w, i.maxW = n ? n * i.itemWT : i.w, i.itemW = i.minW > i.w ? (i.w - t * a) / a : i.maxW < i.w ? (i.w - t * n) / n : i.vars.itemWidth > i.w ? i.w : i.vars.itemWidth, i.itemW = Math.ceil(i.itemW), d ? (i.visible = Math.floor(i.h / (i.itemH + t)), i.move = i.vars.move > 0 && i.vars.move < i.visible ? i.vars.move : i.visible, i.pagingCount = Math.ceil((i.count - i.visible) / i.move + 1), i.last = i.pagingCount - 1, i.limit = 1 === i.pagingCount ? 0 : i.vars.itemHeight > i.h ? (i.itemH + 2 * t) * i.count - i.h - t : (i.itemH + t) * i.count - i.h - t) : (i.visible = Math.floor(i.w / (i.itemW + t)), i.move = i.vars.move > 0 && i.vars.move < i.visible ? i.vars.move : i.visible, i.pagingCount = Math.ceil((i.count - i.visible) / i.move + 1), i.last = i.pagingCount - 1, i.limit = 1 === i.pagingCount ? 0 : i.vars.itemWidth > i.w ? (i.itemW + 2 * t) * i.count - i.w - t : (i.itemW + t) * i.count - i.w - t)) : (i.itemW = i.w, i.itemH = i.h, i.pagingCount = i.count, i.last = i.count - 1), i.computedW = i.itemW - i.boxWPadding, i.computedH = i.itemH - i.boxHPadding
        }, i.update = function(e, t) {
            i.doMath(), v || (e < i.currentSlide ? i.currentSlide += 1 : e <= i.currentSlide && 0 !== e && (i.currentSlide -= 1), i.animatingTo = i.currentSlide), i.vars.controlNav && !i.manualControls && ("add" === t && !v || i.pagingCount > i.controlNav.length ? f.controlNav.update("add") : ("remove" === t && !v || i.pagingCount < i.controlNav.length) && (v && i.currentSlide > i.last && (i.currentSlide -= 1, i.animatingTo -= 1), f.controlNav.update("remove", i.last))), i.vars.directionNav && f.directionNav.update()
        }, i.addSlide = function(t, a) {
            var n = e(t);
            i.count += 1, i.last = i.count - 1, d && u ? void 0 !== a ? i.slides.eq(i.count - a).after(n) : i.container.prepend(n) : void 0 !== a ? i.slides.eq(a).before(n) : i.container.append(n), i.update(a, "add"), i.slides = e(i.vars.selector + ":not(.clone)", i), i.setup(), i.vars.added(i)
        }, i.removeSlide = function(t) {
            var a = isNaN(t) ? i.slides.index(e(t)) : t;
            i.count -= 1, i.last = i.count - 1, isNaN(t) ? e(t, i.slides).remove() : d && u ? i.slides.eq(i.last).remove() : i.slides.eq(t).remove(), i.doMath(), i.update(a, "remove"), i.slides = e(i.vars.selector + ":not(.clone)", i), i.setup(), i.vars.removed(i)
        }, f.init()
    }, e(window).blur(function(e) {
        focused = !1
    }).focus(function(e) {
        focused = !0
    }), e.flexslider.defaults = {
        namespace: "flex-",
        selector: ".slides > li",
        animation: "fade",
        easing: "swing",
        direction: "horizontal",
        reverse: !1,
        animationLoop: !0,
        smoothHeight: !1,
        startAt: 0,
        slideshow: !0,
        slideshowSpeed: 7e3,
        animationSpeed: 600,
        initDelay: 0,
        randomize: !1,
        fadeFirstSlide: !0,
        thumbCaptions: !1,
        pauseOnAction: !0,
        pauseOnHover: !1,
        pauseInvisible: !0,
        useCSS: !0,
        touch: !0,
        video: !1,
        controlNav: !0,
        directionNav: !0,
        prevText: "Previous",
        nextText: "Next",
        keyboard: !0,
        multipleKeyboard: !1,
        mousewheel: !1,
        pausePlay: !1,
        pauseText: "Pause",
        playText: "Play",
        controlsContainer: "",
        manualControls: "",
        sync: "",
        asNavFor: "",
        itemWidth: 0,
        itemMargin: 0,
        minItems: 1,
        maxItems: 0,
        move: 0,
        allowOneSlide: !0,
        start: function() {},
        before: function() {},
        after: function() {},
        end: function() {},
        added: function() {},
        removed: function() {},
        init: function() {}
    }, e.fn.flexslider = function(t) {
        if (void 0 === t && (t = {}), "object" == typeof t) return this.each(function() {
            var a = e(this),
                i = t.selector ? t.selector : ".slides > li",
                n = a.find(i);
            1 === n.length && !0 === t.allowOneSlide || 0 === n.length ? (n.fadeIn(400), t.start && t.start(a)) : void 0 === a.data("flexslider") && new e.flexslider(this, t)
        });
        var a = e(this).data("flexslider");
        switch (t) {
            case "play":
                a.play();
                break;
            case "pause":
                a.pause();
                break;
            case "stop":
                a.stop();
                break;
            case "next":
                a.flexAnimate(a.getTarget("next"), !0);
                break;
            case "prev":
            case "previous":
                a.flexAnimate(a.getTarget("prev"), !0);
                break;
            default:
                "number" == typeof t && a.flexAnimate(t, !0)
        }
    }
}(jQuery);