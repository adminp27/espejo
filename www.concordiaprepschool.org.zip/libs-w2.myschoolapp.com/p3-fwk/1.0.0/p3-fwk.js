// bootsrtrap herodevs 3.4.3
if ("undefined" == typeof jQuery) throw new Error("Bootstrap's JavaScript requires jQuery");
! function() {
    "use strict";
    var t = jQuery.fn.jquery.split(" ")[0].split(".");
    if (t[0] < 2 && t[1] < 9 || 1 == t[0] && 9 == t[1] && t[2] < 1 || 3 < t[0]) throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher, but lower than version 4")
}(),
function(o) {
    "use strict";
    o.fn.emulateTransitionEnd = function(t) {
        var e = !1,
            i = this;
        o(this).one("bsTransitionEnd", function() {
            e = !0
        });
        return setTimeout(function() {
            e || o(i).trigger(o.support.transition.end)
        }, t), this
    }, o(function() {
        o.support.transition = function() {
            var t, e = document.createElement("bootstrap"),
                i = {
                    WebkitTransition: "webkitTransitionEnd",
                    MozTransition: "transitionend",
                    OTransition: "oTransitionEnd otransitionend",
                    transition: "transitionend"
                };
            for (t in i)
                if (e.style[t] !== undefined) return {
                    end: i[t]
                };
            return !1
        }(), o.support.transition && (o.event.special.bsTransitionEnd = {
            bindType: o.support.transition.end,
            delegateType: o.support.transition.end,
            handle: function(t) {
                if (o(t.target).is(this)) return t.handleObj.handler.apply(this, arguments)
            }
        })
    })
}(jQuery),
function(s) {
    "use strict";
    var e = '[data-dismiss="alert"]',
        a = function(t) {
            s(t).on("click", e, this.close)
        };
    a.VERSION = "3.4.1", a.TRANSITION_DURATION = 150, a.prototype.close = function(t) {
        var e = s(this),
            i = e.attr("data-target"),
            o = (i = "#" === (i = i || (i = e.attr("href")) && i.replace(/.*(?=#[^\s]*$)/, "")) ? [] : i, s(document).find(i));

        function n() {
            o.detach().trigger("closed.bs.alert").remove()
        }
        t && t.preventDefault(), (o = o.length ? o : e.closest(".alert")).trigger(t = s.Event("close.bs.alert")), t.isDefaultPrevented() || (o.removeClass("in"), s.support.transition && o.hasClass("fade") ? o.one("bsTransitionEnd", n).emulateTransitionEnd(a.TRANSITION_DURATION) : n())
    };
    var t = s.fn.alert;
    s.fn.alert = function(i) {
        return this.each(function() {
            var t = s(this),
                e = t.data("bs.alert");
            e || t.data("bs.alert", e = new a(this)), "string" == typeof i && e[i].call(t)
        })
    }, s.fn.alert.Constructor = a, s.fn.alert.noConflict = function() {
        return s.fn.alert = t, this
    }, s(document).on("click.bs.alert.data-api", e, a.prototype.close)
}(jQuery),
function(s) {
    "use strict";
    var o = function(t, e) {
        this.$element = s(t), this.options = s.extend({}, o.DEFAULTS, e), this.isLoading = !1
    };

    function i(i) {
        return this.each(function() {
            var t = s(this),
                e = t.data("bs.button");
            e || t.data("bs.button", e = new o(this, "object" == typeof i && i)), "toggle" == i ? e.toggle() : i && e.setState(i)
        })
    }
    o.VERSION = "3.4.1", o.DEFAULTS = {
        loadingText: "loading..."
    }, o.prototype.setState = function(t) {
        var e = "disabled",
            i = this.$element,
            o = i.is("input") ? "val" : "html",
            n = i.data();
        t += "Text", null == n.resetText && i.data("resetText", i[o]()), setTimeout(s.proxy(function() {
            i[o]((null == n[t] ? this.options : n)[t]), "loadingText" == t ? (this.isLoading = !0, i.addClass(e).attr(e, e).prop(e, !0)) : this.isLoading && (this.isLoading = !1, i.removeClass(e).removeAttr(e).prop(e, !1))
        }, this), 0)
    }, o.prototype.toggle = function() {
        var t, e = !0,
            i = this.$element.closest('[data-toggle="buttons"]');
        i.length ? ("radio" == (t = this.$element.find("input")).prop("type") ? (t.prop("checked") && (e = !1), i.find(".active").removeClass("active"), this.$element.addClass("active")) : "checkbox" == t.prop("type") && (t.prop("checked") !== this.$element.hasClass("active") && (e = !1), this.$element.toggleClass("active")), t.prop("checked", this.$element.hasClass("active")), e && t.trigger("change")) : (this.$element.attr("aria-pressed", !this.$element.hasClass("active")), this.$element.toggleClass("active"))
    };
    var t = s.fn.button;
    s.fn.button = i, s.fn.button.Constructor = o, s.fn.button.noConflict = function() {
        return s.fn.button = t, this
    }, s(document).on("click.bs.button.data-api", '[data-toggle^="button"]', function(t) {
        var e = s(t.target).closest(".btn");
        i.call(e, "toggle"), s(t.target).is('input[type="radio"], input[type="checkbox"]') || (t.preventDefault(), (e.is("input,button") ? e : e.find("input:visible,button:visible").first()).trigger("focus"))
    }).on("focus.bs.button.data-api blur.bs.button.data-api", '[data-toggle^="button"]', function(t) {
        s(t.target).closest(".btn").toggleClass("focus", /^focus(in)?$/.test(t.type))
    })
}(jQuery),
function(h) {
    "use strict";
    var d = function(t, e) {
        this.$element = h(t), this.$indicators = this.$element.find(".carousel-indicators"), this.options = e, this.paused = null, this.sliding = null, this.interval = null, this.$active = null, this.$items = null, this.options.keyboard && this.$element.on("keydown.bs.carousel", h.proxy(this.keydown, this)), "hover" != this.options.pause || "ontouchstart" in document.documentElement || this.$element.on("mouseenter.bs.carousel", h.proxy(this.pause, this)).on("mouseleave.bs.carousel", h.proxy(this.cycle, this))
    };

    function n(n) {
        return this.each(function() {
            var t = h(this),
                e = t.data("bs.carousel"),
                i = h.extend({}, d.DEFAULTS, t.data(), "object" == typeof n && n),
                o = "string" == typeof n ? n : i.slide;
            e || t.data("bs.carousel", e = new d(this, i)), "number" == typeof n ? e.to(n) : o ? e[o]() : i.interval && e.pause().cycle()
        })
    }
    d.VERSION = "3.4.1", d.TRANSITION_DURATION = 600, d.DEFAULTS = {
        interval: 5e3,
        pause: "hover",
        wrap: !0,
        keyboard: !0
    }, d.prototype.keydown = function(t) {
        if (!/input|textarea/i.test(t.target.tagName)) {
            switch (t.which) {
                case 37:
                    this.prev();
                    break;
                case 39:
                    this.next();
                    break;
                default:
                    return
            }
            t.preventDefault()
        }
    }, d.prototype.cycle = function(t) {
        return t || (this.paused = !1), this.interval && clearInterval(this.interval), this.options.interval && !this.paused && (this.interval = setInterval(h.proxy(this.next, this), this.options.interval)), this
    }, d.prototype.getItemIndex = function(t) {
        return this.$items = t.parent().children(".item"), this.$items.index(t || this.$active)
    }, d.prototype.getItemForDirection = function(t, e) {
        var i = this.getItemIndex(e);
        return ("prev" == t && 0 === i || "next" == t && i == this.$items.length - 1) && !this.options.wrap ? e : (e = (i + ("prev" == t ? -1 : 1)) % this.$items.length, this.$items.eq(e))
    }, d.prototype.to = function(t) {
        var e = this,
            i = this.getItemIndex(this.$active = this.$element.find(".item.active"));
        if (!(t > this.$items.length - 1 || t < 0)) return this.sliding ? this.$element.one("slid.bs.carousel", function() {
            e.to(t)
        }) : i == t ? this.pause().cycle() : this.slide(i < t ? "next" : "prev", this.$items.eq(t))
    }, d.prototype.pause = function(t) {
        return t || (this.paused = !0), this.$element.find(".next, .prev").length && h.support.transition && (this.$element.trigger(h.support.transition.end), this.cycle(!0)), this.interval = clearInterval(this.interval), this
    }, d.prototype.next = function() {
        if (!this.sliding) return this.slide("next")
    }, d.prototype.prev = function() {
        if (!this.sliding) return this.slide("prev")
    }, d.prototype.slide = function(t, e) {
        var i, o, n, s = this.$element.find(".item.active"),
            a = e || this.getItemForDirection(t, s),
            e = this.interval,
            r = "next" == t ? "left" : "right",
            l = this;
        return a.hasClass("active") ? this.sliding = !1 : (i = a[0], o = h.Event("slide.bs.carousel", {
            relatedTarget: i,
            direction: r
        }), this.$element.trigger(o), o.isDefaultPrevented() ? void 0 : (this.sliding = !0, e && this.pause(), this.$indicators.length && (this.$indicators.find(".active").removeClass("active"), o = h(this.$indicators.children()[this.getItemIndex(a)])) && o.addClass("active"), n = h.Event("slid.bs.carousel", {
            relatedTarget: i,
            direction: r
        }), h.support.transition && this.$element.hasClass("slide") ? (a.addClass(t), "object" == typeof a && a.length && a[0].offsetWidth, s.addClass(r), a.addClass(r), s.one("bsTransitionEnd", function() {
            a.removeClass([t, r].join(" ")).addClass("active"), s.removeClass(["active", r].join(" ")), l.sliding = !1, setTimeout(function() {
                l.$element.trigger(n)
            }, 0)
        }).emulateTransitionEnd(d.TRANSITION_DURATION)) : (s.removeClass("active"), a.addClass("active"), this.sliding = !1, this.$element.trigger(n)), e && this.cycle(), this))
    };
    var t = h.fn.carousel,
        e = (h.fn.carousel = n, h.fn.carousel.Constructor = d, h.fn.carousel.noConflict = function() {
            return h.fn.carousel = t, this
        }, function(t) {
            var e, i = h(this),
                o = (o = i.attr("href")) && o.replace(/.*(?=#[^\s]+$)/, ""),
                o = i.attr("data-target") || o,
                o = h(document).find(o);
            o.hasClass("carousel") && (e = h.extend({}, o.data(), i.data()), (i = i.attr("data-slide-to")) && (e.interval = !1), n.call(o, e), i && o.data("bs.carousel").to(i), t.preventDefault())
        });
    h(document).on("click.bs.carousel.data-api", "[data-slide]", e).on("click.bs.carousel.data-api", "[data-slide-to]", e), h(window).on("load", function() {
        h('[data-ride="carousel"]').each(function() {
            var t = h(this);
            n.call(t, t.data())
        })
    })
}(jQuery),
function(n) {
    "use strict";
    var s = function(t, e) {
        this.$element = n(t), this.options = n.extend({}, s.DEFAULTS, e), this.$trigger = n('[data-toggle="collapse"][href="#' + t.id + '"],[data-toggle="collapse"][data-target="#' + t.id + '"]'), this.transitioning = null, this.options.parent ? this.$parent = this.getParent() : this.addAriaAndCollapsedClass(this.$element, this.$trigger), this.options.toggle && this.toggle()
    };

    function i(t) {
        t = t.attr("data-target") || (t = t.attr("href")) && t.replace(/.*(?=#[^\s]+$)/, "");
        return n(document).find(t)
    }

    function a(o) {
        return this.each(function() {
            var t = n(this),
                e = t.data("bs.collapse"),
                i = n.extend({}, s.DEFAULTS, t.data(), "object" == typeof o && o);
            !e && i.toggle && /show|hide/.test(o) && (i.toggle = !1), e || t.data("bs.collapse", e = new s(this, i)), "string" == typeof o && e[o]()
        })
    }
    s.VERSION = "3.4.1", s.TRANSITION_DURATION = 350, s.DEFAULTS = {
        toggle: !0
    }, s.prototype.dimension = function() {
        return this.$element.hasClass("width") ? "width" : "height"
    }, s.prototype.show = function() {
        if (!this.transitioning && !this.$element.hasClass("in")) {
            var t = this.$parent && this.$parent.children(".panel").children(".in, .collapsing");
            if (!(t && t.length && (o = t.data("bs.collapse")) && o.transitioning)) {
                var e = n.Event("show.bs.collapse");
                if (this.$element.trigger(e), !e.isDefaultPrevented()) {
                    t && t.length && (a.call(t, "hide"), o || t.data("bs.collapse", null));
                    var i = this.dimension(),
                        e = (this.$element.removeClass("collapse").addClass("collapsing")[i](0).attr("aria-expanded", !0), this.$trigger.removeClass("collapsed").attr("aria-expanded", !0), this.transitioning = 1, function() {
                            this.$element.removeClass("collapsing").addClass("collapse in")[i](""), this.transitioning = 0, this.$element.trigger("shown.bs.collapse")
                        });
                    if (!n.support.transition) return e.call(this);
                    var o = n.camelCase(["scroll", i].join("-"));
                    this.$element.one("bsTransitionEnd", n.proxy(e, this)).emulateTransitionEnd(s.TRANSITION_DURATION)[i](this.$element[0][o])
                }
            }
        }
    }, s.prototype.hide = function() {
        if (!this.transitioning && this.$element.hasClass("in")) {
            var t = n.Event("hide.bs.collapse");
            if (this.$element.trigger(t), !t.isDefaultPrevented()) {
                var t = this.dimension(),
                    e = (this.$element[t](this.$element[t]())[0].offsetHeight, this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded", !1), this.$trigger.addClass("collapsed").attr("aria-expanded", !1), this.transitioning = 1, function() {
                        this.transitioning = 0, this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")
                    });
                if (!n.support.transition) return e.call(this);
                this.$element[t](0).one("bsTransitionEnd", n.proxy(e, this)).emulateTransitionEnd(s.TRANSITION_DURATION)
            }
        }
    }, s.prototype.toggle = function() {
        this[this.$element.hasClass("in") ? "hide" : "show"]()
    }, s.prototype.getParent = function() {
        return n(document).find(this.options.parent).find('[data-toggle="collapse"][data-parent="' + this.options.parent + '"]').each(n.proxy(function(t, e) {
            e = n(e);
            this.addAriaAndCollapsedClass(i(e), e)
        }, this)).end()
    }, s.prototype.addAriaAndCollapsedClass = function(t, e) {
        var i = t.hasClass("in");
        t.attr("aria-expanded", i), e.toggleClass("collapsed", !i).attr("aria-expanded", i)
    };
    var t = n.fn.collapse;
    n.fn.collapse = a, n.fn.collapse.Constructor = s, n.fn.collapse.noConflict = function() {
        return n.fn.collapse = t, this
    }, n(document).on("click.bs.collapse.data-api", '[data-toggle="collapse"]', function(t) {
        var e = n(this),
            t = (e.attr("data-target") || t.preventDefault(), i(e)),
            e = t.data("bs.collapse") ? "toggle" : e.data();
        a.call(t, e)
    })
}(jQuery),
function(n) {
    "use strict";
    var s = '[data-toggle="dropdown"]',
        o = function(t) {
            n(t).on("click.bs.dropdown", this.toggle)
        };

    function a(t) {
        var e = t.attr("data-target"),
            e = "#" !== (e = e || (e = t.attr("href")) && /#[A-Za-z]/.test(e) && e.replace(/.*(?=#[^\s]*$)/, "")) ? n(document).find(e) : null;
        return e && e.length ? e : t.parent()
    }

    function r(o) {
        o && 3 === o.which || (n(".dropdown-backdrop").remove(), n(s).each(function() {
            var t = n(this),
                e = a(t),
                i = {
                    relatedTarget: this
                };
            !e.hasClass("open") || o && "click" == o.type && /input|textarea/i.test(o.target.tagName) && n.contains(e[0], o.target) || (e.trigger(o = n.Event("hide.bs.dropdown", i)), o.isDefaultPrevented()) || (t.attr("aria-expanded", "false"), e.removeClass("open").trigger(n.Event("hidden.bs.dropdown", i)))
        }))
    }
    o.VERSION = "3.4.1", o.prototype.toggle = function(t) {
        var e = n(this);
        if (!e.is(".disabled, :disabled")) {
            var i = a(e),
                o = i.hasClass("open");
            if (r(), !o) {
                "ontouchstart" in document.documentElement && !i.closest(".navbar-nav").length && n(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(n(this)).on("click", r);
                o = {
                    relatedTarget: this
                };
                if (i.trigger(t = n.Event("show.bs.dropdown", o)), t.isDefaultPrevented()) return;
                e.trigger("focus").attr("aria-expanded", "true"), i.toggleClass("open").trigger(n.Event("shown.bs.dropdown", o))
            }
            return !1
        }
    }, o.prototype.keydown = function(t) {
        if (/(38|40|27|32)/.test(t.which) && !/input|textarea/i.test(t.target.tagName)) {
            var e = n(this);
            if (t.preventDefault(), t.stopPropagation(), !e.is(".disabled, :disabled")) {
                var i = a(e),
                    o = i.hasClass("open");
                if (!o && 27 != t.which || o && 27 == t.which) return 27 == t.which && i.find(s).trigger("focus"), e.trigger("click");
                o = i.find(".dropdown-menu li:not(.disabled):visible a");
                o.length && (e = o.index(t.target), 38 == t.which && 0 < e && e--, 40 == t.which && e < o.length - 1 && e++, o.eq(e = ~e ? e : 0).trigger("focus"))
            }
        }
    };
    var t = n.fn.dropdown;
    n.fn.dropdown = function(i) {
        return this.each(function() {
            var t = n(this),
                e = t.data("bs.dropdown");
            e || t.data("bs.dropdown", e = new o(this)), "string" == typeof i && e[i].call(t)
        })
    }, n.fn.dropdown.Constructor = o, n.fn.dropdown.noConflict = function() {
        return n.fn.dropdown = t, this
    }, n(document).on("click.bs.dropdown.data-api", r).on("click.bs.dropdown.data-api", ".dropdown form", function(t) {
        t.stopPropagation()
    }).on("click.bs.dropdown.data-api", s, o.prototype.toggle).on("keydown.bs.dropdown.data-api", s, o.prototype.keydown).on("keydown.bs.dropdown.data-api", ".dropdown-menu", o.prototype.keydown)
}(jQuery),
function(s) {
    "use strict";
    var a = function(t, e) {
        this.options = e, this.$body = s(document.body), this.$element = s(t), this.$dialog = this.$element.find(".modal-dialog"), this.$backdrop = null, this.isShown = null, this.originalBodyPad = null, this.scrollbarWidth = 0, this.ignoreBackdropClick = !1, this.fixedContent = ".navbar-fixed-top, .navbar-fixed-bottom", this.options.remote && this.$element.find(".modal-content").load(this.options.remote, s.proxy(function() {
            this.$element.trigger("loaded.bs.modal")
        }, this))
    };

    function r(o, n) {
        return this.each(function() {
            var t = s(this),
                e = t.data("bs.modal"),
                i = s.extend({}, a.DEFAULTS, t.data(), "object" == typeof o && o);
            e || t.data("bs.modal", e = new a(this, i)), "string" == typeof o ? e[o](n) : i.show && e.show(n)
        })
    }
    a.VERSION = "3.4.1", a.TRANSITION_DURATION = 300, a.BACKDROP_TRANSITION_DURATION = 150, a.DEFAULTS = {
        backdrop: !0,
        keyboard: !0,
        show: !0
    }, a.prototype.toggle = function(t) {
        return this.isShown ? this.hide() : this.show(t)
    }, a.prototype.show = function(i) {
        var o = this,
            t = s.Event("show.bs.modal", {
                relatedTarget: i
            });
        this.$element.trigger(t), this.isShown || t.isDefaultPrevented() || (this.isShown = !0, this.checkScrollbar(), this.setScrollbar(), this.$body.addClass("modal-open"), this.escape(), this.resize(), this.$element.on("click.dismiss.bs.modal", '[data-dismiss="modal"]', s.proxy(this.hide, this)), this.$dialog.on("mousedown.dismiss.bs.modal", function() {
            o.$element.one("mouseup.dismiss.bs.modal", function(t) {
                s(t.target).is(o.$element) && (o.ignoreBackdropClick = !0)
            })
        }), this.backdrop(function() {
            var t = s.support.transition && o.$element.hasClass("fade"),
                e = (o.$element.parent().length || o.$element.appendTo(o.$body), o.$element.show().scrollTop(0), o.adjustDialog(), t && o.$element[0].offsetWidth, o.$element.addClass("in"), o.enforceFocus(), s.Event("shown.bs.modal", {
                    relatedTarget: i
                }));
            t ? o.$dialog.one("bsTransitionEnd", function() {
                o.$element.trigger("focus").trigger(e)
            }).emulateTransitionEnd(a.TRANSITION_DURATION) : o.$element.trigger("focus").trigger(e)
        }))
    }, a.prototype.hide = function(t) {
        t && t.preventDefault(), t = s.Event("hide.bs.modal"), this.$element.trigger(t), this.isShown && !t.isDefaultPrevented() && (this.isShown = !1, this.escape(), this.resize(), s(document).off("focusin.bs.modal"), this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"), this.$dialog.off("mousedown.dismiss.bs.modal"), s.support.transition && this.$element.hasClass("fade") ? this.$element.one("bsTransitionEnd", s.proxy(this.hideModal, this)).emulateTransitionEnd(a.TRANSITION_DURATION) : this.hideModal())
    }, a.prototype.enforceFocus = function() {
        s(document).off("focusin.bs.modal").on("focusin.bs.modal", s.proxy(function(t) {
            document === t.target || this.$element[0] === t.target || this.$element.has(t.target).length || this.$element.trigger("focus")
        }, this))
    }, a.prototype.escape = function() {
        this.isShown && this.options.keyboard ? this.$element.on("keydown.dismiss.bs.modal", s.proxy(function(t) {
            27 == t.which && this.hide()
        }, this)) : this.isShown || this.$element.off("keydown.dismiss.bs.modal")
    }, a.prototype.resize = function() {
        this.isShown ? s(window).on("resize.bs.modal", s.proxy(this.handleUpdate, this)) : s(window).off("resize.bs.modal")
    }, a.prototype.hideModal = function() {
        var t = this;
        this.$element.hide(), this.backdrop(function() {
            t.$body.removeClass("modal-open"), t.resetAdjustments(), t.resetScrollbar(), t.$element.trigger("hidden.bs.modal")
        })
    }, a.prototype.removeBackdrop = function() {
        this.$backdrop && this.$backdrop.remove(), this.$backdrop = null
    }, a.prototype.backdrop = function(t) {
        var e, i = this,
            o = this.$element.hasClass("fade") ? "fade" : "";
        this.isShown && this.options.backdrop ? (e = s.support.transition && o, this.$backdrop = s(document.createElement("div")).addClass("modal-backdrop " + o).appendTo(this.$body), this.$element.on("click.dismiss.bs.modal", s.proxy(function(t) {
            this.ignoreBackdropClick ? this.ignoreBackdropClick = !1 : t.target === t.currentTarget && ("static" == this.options.backdrop ? this.$element[0].focus() : this.hide())
        }, this)), e && this.$backdrop[0].offsetWidth, this.$backdrop.addClass("in"), t && (e ? this.$backdrop.one("bsTransitionEnd", t).emulateTransitionEnd(a.BACKDROP_TRANSITION_DURATION) : t())) : !this.isShown && this.$backdrop ? (this.$backdrop.removeClass("in"), o = function() {
            i.removeBackdrop(), t && t()
        }, s.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one("bsTransitionEnd", o).emulateTransitionEnd(a.BACKDROP_TRANSITION_DURATION) : o()) : t && t()
    }, a.prototype.handleUpdate = function() {
        this.adjustDialog()
    }, a.prototype.adjustDialog = function() {
        var t = this.$element[0].scrollHeight > document.documentElement.clientHeight;
        this.$element.css({
            paddingLeft: !this.bodyIsOverflowing && t ? this.scrollbarWidth : "",
            paddingRight: this.bodyIsOverflowing && !t ? this.scrollbarWidth : ""
        })
    }, a.prototype.resetAdjustments = function() {
        this.$element.css({
            paddingLeft: "",
            paddingRight: ""
        })
    }, a.prototype.checkScrollbar = function() {
        var t, e = window.innerWidth;
        e || (e = (t = document.documentElement.getBoundingClientRect()).right - Math.abs(t.left)), this.bodyIsOverflowing = document.body.clientWidth < e, this.scrollbarWidth = this.measureScrollbar()
    }, a.prototype.setScrollbar = function() {
        var t = parseInt(this.$body.css("padding-right") || 0, 10),
            n = (this.originalBodyPad = document.body.style.paddingRight || "", this.scrollbarWidth);
        this.bodyIsOverflowing && (this.$body.css("padding-right", t + n), s(this.fixedContent).each(function(t, e) {
            var i = e.style.paddingRight,
                o = s(e).css("padding-right");
            s(e).data("padding-right", i).css("padding-right", parseFloat(o) + n + "px")
        }))
    }, a.prototype.resetScrollbar = function() {
        this.$body.css("padding-right", this.originalBodyPad), s(this.fixedContent).each(function(t, e) {
            var i = s(e).data("padding-right");
            s(e).removeData("padding-right"), e.style.paddingRight = i || ""
        })
    }, a.prototype.measureScrollbar = function() {
        var t = document.createElement("div"),
            e = (t.className = "modal-scrollbar-measure", this.$body.append(t), t.offsetWidth - t.clientWidth);
        return this.$body[0].removeChild(t), e
    };
    var t = s.fn.modal;
    s.fn.modal = r, s.fn.modal.Constructor = a, s.fn.modal.noConflict = function() {
        return s.fn.modal = t, this
    }, s(document).on("click.bs.modal.data-api", '[data-toggle="modal"]', function(t) {
        var e = s(this),
            i = e.attr("href"),
            o = e.attr("data-target") || i && i.replace(/.*(?=#[^\s]+$)/, ""),
            n = s(document).find(o),
            o = n.data("bs.modal") ? "toggle" : s.extend({
                remote: !/#/.test(i) && i
            }, n.data(), e.data());
        e.is("a") && t.preventDefault(), n.one("show.bs.modal", function(t) {
            t.isDefaultPrevented() || n.one("hidden.bs.modal", function() {
                e.is(":visible") && e.trigger("focus")
            })
        }), r.call(n, o, this)
    })
}(jQuery),
function(f) {
    "use strict";
    var o = ["sanitize", "whiteList", "sanitizeFn"],
        u = ["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"],
        t = {
            "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
            a: ["target", "href", "title", "rel"],
            area: [],
            b: [],
            br: [],
            col: [],
            code: [],
            div: [],
            em: [],
            hr: [],
            h1: [],
            h2: [],
            h3: [],
            h4: [],
            h5: [],
            h6: [],
            i: [],
            img: ["src", "alt", "title", "width", "height"],
            li: [],
            ol: [],
            p: [],
            pre: [],
            s: [],
            small: [],
            span: [],
            sub: [],
            sup: [],
            strong: [],
            u: [],
            ul: []
        },
        g = /^(?:(?:https?|mailto|ftp|tel|file):|[^&:/?#]*(?:[/?#]|$))/gi,
        m = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[a-z0-9+/]+=*$/i;

    function n(t, e, i) {
        if (0 === t.length) return t;
        if (i && "function" == typeof i) return i(t);
        if (!document.implementation || !document.implementation.createHTMLDocument) return t;
        for (var i = document.implementation.createHTMLDocument("sanitization"), o = (i.body.innerHTML = t, f.map(e, function(t, e) {
                return e
            })), n = f(i.body).find("*"), s = 0, a = n.length; s < a; s++) {
            var r = n[s],
                l = r.nodeName.toLowerCase();
            if (-1 === f.inArray(l, o)) r.parentNode.removeChild(r);
            else
                for (var h = f.map(r.attributes, function(t) {
                        return t
                    }), d = [].concat(e["*"] || [], e[l] || []), p = 0, c = h.length; p < c; p++) ! function(t, e) {
                    var i = t.nodeName.toLowerCase();
                    if (-1 !== f.inArray(i, e)) return -1 === f.inArray(i, u) || Boolean(t.nodeValue.match(g) || t.nodeValue.match(m));
                    for (var o = f(e).filter(function(t, e) {
                            return e instanceof RegExp
                        }), n = 0, s = o.length; n < s; n++)
                        if (i.match(o[n])) return 1
                }(h[p], d) && r.removeAttribute(h[p].nodeName)
        }
        return i.body.innerHTML
    }
    var l = function(t, e) {
        this.type = null, this.options = null, this.enabled = null, this.timeout = null, this.hoverState = null, this.$element = null, this.inState = null, this.init("tooltip", t, e)
    };
    l.VERSION = "3.4.1", l.TRANSITION_DURATION = 150, l.DEFAULTS = {
        animation: !0,
        placement: "top",
        selector: !1,
        template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
        trigger: "hover focus",
        title: "",
        delay: 0,
        html: !1,
        container: !1,
        viewport: {
            selector: "body",
            padding: 0
        },
        sanitize: !0,
        sanitizeFn: null,
        whiteList: t
    }, l.prototype.init = function(t, e, i) {
        if (this.enabled = !0, this.type = t, this.$element = f(e), this.options = this.getOptions(i), this.$viewport = this.options.viewport && f(document).find(f.isFunction(this.options.viewport) ? this.options.viewport.call(this, this.$element) : this.options.viewport.selector || this.options.viewport), this.inState = {
                click: !1,
                hover: !1,
                focus: !1
            }, this.$element[0] instanceof document.constructor && !this.options.selector) throw new Error("`selector` option must be specified when initializing " + this.type + " on the window.document object!");
        for (var o = this.options.trigger.split(" "), n = o.length; n--;) {
            var s, a = o[n];
            "click" == a ? this.$element.on("click." + this.type, this.options.selector, f.proxy(this.toggle, this)) : "manual" != a && (s = "hover" == a ? "mouseleave" : "focusout", this.$element.on(("hover" == a ? "mouseenter" : "focusin") + "." + this.type, this.options.selector, f.proxy(this.enter, this)), this.$element.on(s + "." + this.type, this.options.selector, f.proxy(this.leave, this)))
        }
        this.options.selector ? this._options = f.extend({}, this.options, {
            trigger: "manual",
            selector: ""
        }) : this.fixTitle()
    }, l.prototype.getDefaults = function() {
        return l.DEFAULTS
    }, l.prototype.getOptions = function(t) {
        var e, i = this.$element.data();
        for (e in i) i.hasOwnProperty(e) && -1 !== f.inArray(e, o) && delete i[e];
        return (t = f.extend({}, this.getDefaults(), i, t)).delay && "number" == typeof t.delay && (t.delay = {
            show: t.delay,
            hide: t.delay
        }), t.sanitize && (t.template = n(t.template, t.whiteList, t.sanitizeFn)), t
    }, l.prototype.getDelegateOptions = function() {
        var i = {},
            o = this.getDefaults();
        return this._options && f.each(this._options, function(t, e) {
            o[t] != e && (i[t] = e)
        }), i
    }, l.prototype.enter = function(t) {
        var e = t instanceof this.constructor ? t : f(t.currentTarget).data("bs." + this.type);
        if (e || (e = new this.constructor(t.currentTarget, this.getDelegateOptions()), f(t.currentTarget).data("bs." + this.type, e)), t instanceof f.Event && (e.inState["focusin" == t.type ? "focus" : "hover"] = !0), e.tip().hasClass("in") || "in" == e.hoverState) e.hoverState = "in";
        else {
            if (clearTimeout(e.timeout), e.hoverState = "in", !e.options.delay || !e.options.delay.show) return e.show();
            e.timeout = setTimeout(function() {
                "in" == e.hoverState && e.show()
            }, e.options.delay.show)
        }
    }, l.prototype.isInStateTrue = function() {
        for (var t in this.inState)
            if (this.inState[t]) return !0;
        return !1
    }, l.prototype.leave = function(t) {
        var e = t instanceof this.constructor ? t : f(t.currentTarget).data("bs." + this.type);
        if (e || (e = new this.constructor(t.currentTarget, this.getDelegateOptions()), f(t.currentTarget).data("bs." + this.type, e)), t instanceof f.Event && (e.inState["focusout" == t.type ? "focus" : "hover"] = !1), !e.isInStateTrue()) {
            if (clearTimeout(e.timeout), e.hoverState = "out", !e.options.delay || !e.options.delay.hide) return e.hide();
            e.timeout = setTimeout(function() {
                "out" == e.hoverState && e.hide()
            }, e.options.delay.hide)
        }
    }, l.prototype.show = function() {
        var e, t, i, o, n, s, a, r = f.Event("show.bs." + this.type);
        this.hasContent() && this.enabled && (this.$element.trigger(r), n = f.contains(this.$element[0].ownerDocument.documentElement, this.$element[0]), !r.isDefaultPrevented()) && n && (r = (e = this).tip(), n = this.getUID(this.type), this.setContent(), r.attr("id", n), this.$element.attr("aria-describedby", n), this.options.animation && r.addClass("fade"), n = "function" == typeof this.options.placement ? this.options.placement.call(this, r[0], this.$element[0]) : this.options.placement, (a = (t = /\s?auto?\s?/i).test(n)) && (n = n.replace(t, "") || "top"), r.detach().css({
            top: 0,
            left: 0,
            display: "block"
        }).addClass(n).data("bs." + this.type, this), this.options.container ? r.appendTo(f(document).find(this.options.container)) : r.insertAfter(this.$element), this.$element.trigger("inserted.bs." + this.type), t = this.getPosition(), i = r[0].offsetWidth, o = r[0].offsetHeight, a && (a = n, s = this.getPosition(this.$viewport), n = "bottom" == n && t.bottom + o > s.bottom ? "top" : "top" == n && t.top - o < s.top ? "bottom" : "right" == n && t.right + i > s.width ? "left" : "left" == n && t.left - i < s.left ? "right" : n, r.removeClass(a).addClass(n)), s = this.getCalculatedOffset(n, t, i, o), this.applyPlacement(s, n), a = function() {
            var t = e.hoverState;
            e.$element.trigger("shown.bs." + e.type), e.hoverState = null, "out" == t && e.leave(e)
        }, f.support.transition && this.$tip.hasClass("fade") ? r.one("bsTransitionEnd", a).emulateTransitionEnd(l.TRANSITION_DURATION) : a())
    }, l.prototype.applyPlacement = function(t, e) {
        var i = this.tip(),
            o = i[0].offsetWidth,
            n = i[0].offsetHeight,
            s = parseInt(i.css("margin-top"), 10),
            a = parseInt(i.css("margin-left"), 10),
            s = (isNaN(s) && (s = 0), isNaN(a) && (a = 0), t.top += s, t.left += a, f.offset.setOffset(i[0], f.extend({
                using: function(t) {
                    i.css({
                        top: Math.round(t.top),
                        left: Math.round(t.left)
                    })
                }
            }, t), 0), i.addClass("in"), i[0].offsetWidth),
            a = i[0].offsetHeight,
            r = ("top" == e && a != n && (t.top = t.top + n - a), this.getViewportAdjustedDelta(e, t, s, a)),
            e = (r.left ? t.left += r.left : t.top += r.top, /top|bottom/.test(e)),
            o = e ? 2 * r.left - o + s : 2 * r.top - n + a,
            s = e ? "offsetWidth" : "offsetHeight";
        i.offset(t), this.replaceArrow(o, i[0][s], e)
    }, l.prototype.replaceArrow = function(t, e, i) {
        this.arrow().css(i ? "left" : "top", 50 * (1 - t / e) + "%").css(i ? "top" : "left", "")
    }, l.prototype.setContent = function() {
        var t = this.tip(),
            e = this.getTitle();
        this.options.html ? (this.options.sanitize && (e = n(e, this.options.whiteList, this.options.sanitizeFn)), t.find(".tooltip-inner").html(e)) : t.find(".tooltip-inner").text(e), t.removeClass("fade in top bottom left right")
    }, l.prototype.hide = function(t) {
        var e = this,
            i = f(this.$tip),
            o = f.Event("hide.bs." + this.type);

        function n() {
            "in" != e.hoverState && i.detach(), e.$element && e.$element.removeAttr("aria-describedby").trigger("hidden.bs." + e.type), t && t()
        }
        if (this.$element.trigger(o), !o.isDefaultPrevented()) return i.removeClass("in"), f.support.transition && i.hasClass("fade") ? i.one("bsTransitionEnd", n).emulateTransitionEnd(l.TRANSITION_DURATION) : n(), this.hoverState = null, this
    }, l.prototype.fixTitle = function() {
        var t = this.$element;
        !t.attr("title") && "string" == typeof t.attr("data-original-title") || t.attr("data-original-title", t.attr("title") || "").attr("title", "")
    }, l.prototype.hasContent = function() {
        return this.getTitle()
    }, l.prototype.getPosition = function(t) {
        var e = (t = t || this.$element)[0],
            i = "BODY" == e.tagName,
            o = e.getBoundingClientRect(),
            e = (null == o.width && (o = f.extend({}, o, {
                width: o.right - o.left,
                height: o.bottom - o.top
            })), window.SVGElement && e instanceof window.SVGElement),
            e = i ? {
                top: 0,
                left: 0
            } : e ? null : t.offset(),
            t = {
                scroll: i ? document.documentElement.scrollTop || document.body.scrollTop : t.scrollTop()
            },
            i = i ? {
                width: f(window).width(),
                height: f(window).height()
            } : null;
        return f.extend({}, o, t, i, e)
    }, l.prototype.getCalculatedOffset = function(t, e, i, o) {
        return "bottom" == t ? {
            top: e.top + e.height,
            left: e.left + e.width / 2 - i / 2
        } : "top" == t ? {
            top: e.top - o,
            left: e.left + e.width / 2 - i / 2
        } : "left" == t ? {
            top: e.top + e.height / 2 - o / 2,
            left: e.left - i
        } : {
            top: e.top + e.height / 2 - o / 2,
            left: e.left + e.width
        }
    }, l.prototype.getViewportAdjustedDelta = function(t, e, i, o) {
        var n, s, a = {
            top: 0,
            left: 0
        };
        return this.$viewport && (n = this.options.viewport && this.options.viewport.padding || 0, s = this.getPosition(this.$viewport), /right|left/.test(t) ? (t = e.top - n - s.scroll, o = e.top + n - s.scroll + o, t < s.top ? a.top = s.top - t : o > s.top + s.height && (a.top = s.top + s.height - o)) : (t = e.left - n, o = e.left + n + i, t < s.left ? a.left = s.left - t : o > s.right && (a.left = s.left + s.width - o))), a
    }, l.prototype.getTitle = function() {
        var t = this.$element,
            e = this.options;
        return t.attr("data-original-title") || ("function" == typeof e.title ? e.title.call(t[0]) : e.title)
    }, l.prototype.getUID = function(t) {
        for (; t += ~~(1e6 * Math.random()), document.getElementById(t););
        return t
    }, l.prototype.tip = function() {
        if (this.$tip || (this.$tip = f(this.options.template), 1 == this.$tip.length)) return this.$tip;
        throw new Error(this.type + " `template` option must consist of exactly 1 top-level element!")
    }, l.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".tooltip-arrow")
    }, l.prototype.enable = function() {
        this.enabled = !0
    }, l.prototype.disable = function() {
        this.enabled = !1
    }, l.prototype.toggleEnabled = function() {
        this.enabled = !this.enabled
    }, l.prototype.toggle = function(t) {
        var e = this;
        t && !(e = f(t.currentTarget).data("bs." + this.type)) && (e = new this.constructor(t.currentTarget, this.getDelegateOptions()), f(t.currentTarget).data("bs." + this.type, e)), t ? (e.inState.click = !e.inState.click, e.isInStateTrue() ? e.enter(e) : e.leave(e)) : e.tip().hasClass("in") ? e.leave(e) : e.enter(e)
    }, l.prototype.destroy = function() {
        var t = this;
        clearTimeout(this.timeout), this.hide(function() {
            t.$element.off("." + t.type).removeData("bs." + t.type), t.$tip && t.$tip.detach(), t.$tip = null, t.$arrow = null, t.$viewport = null, t.$element = null
        })
    }, l.prototype.sanitizeHtml = function(t) {
        return n(t, this.options.whiteList, this.options.sanitizeFn)
    };
    var e = f.fn.tooltip;
    f.fn.tooltip = function(o) {
        return this.each(function() {
            var t = f(this),
                e = t.data("bs.tooltip"),
                i = "object" == typeof o && o;
            !e && /destroy|hide/.test(o) || (e || t.data("bs.tooltip", e = new l(this, i)), "string" == typeof o && e[o]())
        })
    }, f.fn.tooltip.Constructor = l, f.fn.tooltip.noConflict = function() {
        return f.fn.tooltip = e, this
    }
}(jQuery),
function(n) {
    "use strict";
    var s = function(t, e) {
        this.init("popover", t, e)
    };
    if (!n.fn.tooltip) throw new Error("Popover requires tooltip.js");
    s.VERSION = "3.4.1", s.DEFAULTS = n.extend({}, n.fn.tooltip.Constructor.DEFAULTS, {
        placement: "right",
        trigger: "click",
        content: "",
        template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
    }), ((s.prototype = n.extend({}, n.fn.tooltip.Constructor.prototype)).constructor = s).prototype.getDefaults = function() {
        return s.DEFAULTS
    }, s.prototype.setContent = function() {
        var t, e = this.tip(),
            i = this.getTitle(),
            o = this.getContent();
        this.options.html ? (t = typeof o, this.options.sanitize && (i = this.sanitizeHtml(i), "string" == t) && (o = this.sanitizeHtml(o)), e.find(".popover-title").html(i), e.find(".popover-content").children().detach().end()["string" == t ? "html" : "append"](o)) : (e.find(".popover-title").text(i), e.find(".popover-content").children().detach().end().text(o)), e.removeClass("fade top bottom left right in"), e.find(".popover-title").html() || e.find(".popover-title").hide()
    }, s.prototype.hasContent = function() {
        return this.getTitle() || this.getContent()
    }, s.prototype.getContent = function() {
        var t = this.$element,
            e = this.options;
        return t.attr("data-content") || ("function" == typeof e.content ? e.content.call(t[0]) : e.content)
    }, s.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".arrow")
    };
    var t = n.fn.popover;
    n.fn.popover = function(o) {
        return this.each(function() {
            var t = n(this),
                e = t.data("bs.popover"),
                i = "object" == typeof o && o;
            !e && /destroy|hide/.test(o) || (e || t.data("bs.popover", e = new s(this, i)), "string" == typeof o && e[o]())
        })
    }, n.fn.popover.Constructor = s, n.fn.popover.noConflict = function() {
        return n.fn.popover = t, this
    }
}(jQuery),
function(n) {
    "use strict";

    function o(t, e) {
        this.$body = n(document.body), this.$scrollElement = n(t).is(document.body) ? n(window) : n(t), this.options = n.extend({}, o.DEFAULTS, e), this.selector = (this.options.target || "") + " .nav li > a", this.offsets = [], this.targets = [], this.activeTarget = null, this.scrollHeight = 0, this.$scrollElement.on("scroll.bs.scrollspy", n.proxy(this.process, this)), this.refresh(), this.process()
    }

    function e(i) {
        return this.each(function() {
            var t = n(this),
                e = t.data("bs.scrollspy");
            e || t.data("bs.scrollspy", e = new o(this, "object" == typeof i && i)), "string" == typeof i && e[i]()
        })
    }
    o.VERSION = "3.4.1", o.DEFAULTS = {
        offset: 10
    }, o.prototype.getScrollHeight = function() {
        return this.$scrollElement[0].scrollHeight || Math.max(this.$body[0].scrollHeight, document.documentElement.scrollHeight)
    }, o.prototype.refresh = function() {
        var t = this,
            i = "offset",
            o = 0;
        this.offsets = [], this.targets = [], this.scrollHeight = this.getScrollHeight(), n.isWindow(this.$scrollElement[0]) || (i = "position", o = this.$scrollElement.scrollTop()), this.$body.find(this.selector).map(function() {
            var t = n(this),
                t = t.data("target") || t.attr("href"),
                e = /^#./.test(t) && n(t);
            return e && e.length && e.is(":visible") ? [
                [e[i]().top + o, t]
            ] : null
        }).sort(function(t, e) {
            return t[0] - e[0]
        }).each(function() {
            t.offsets.push(this[0]), t.targets.push(this[1])
        })
    }, o.prototype.process = function() {
        var t, e = this.$scrollElement.scrollTop() + this.options.offset,
            i = this.getScrollHeight(),
            o = this.options.offset + i - this.$scrollElement.height(),
            n = this.offsets,
            s = this.targets,
            a = this.activeTarget;
        if (this.scrollHeight != i && this.refresh(), o <= e) return a != (t = s[s.length - 1]) && this.activate(t);
        if (a && e < n[0]) return this.activeTarget = null, this.clear();
        for (t = n.length; t--;) a != s[t] && e >= n[t] && (n[t + 1] === undefined || e < n[t + 1]) && this.activate(s[t])
    }, o.prototype.activate = function(t) {
        this.activeTarget = t, this.clear();
        t = this.selector + '[data-target="' + t + '"],' + this.selector + '[href="' + t + '"]', t = n(t).parents("li").addClass("active");
        (t = t.parent(".dropdown-menu").length ? t.closest("li.dropdown").addClass("active") : t).trigger("activate.bs.scrollspy")
    }, o.prototype.clear = function() {
        n(this.selector).parentsUntil(this.options.target, ".active").removeClass("active")
    };
    var t = n.fn.scrollspy;
    n.fn.scrollspy = e, n.fn.scrollspy.Constructor = o, n.fn.scrollspy.noConflict = function() {
        return n.fn.scrollspy = t, this
    }, n(window).on("load.bs.scrollspy.data-api", function() {
        n('[data-spy="scroll"]').each(function() {
            var t = n(this);
            e.call(t, t.data())
        })
    })
}(jQuery),
function(a) {
    "use strict";
    var r = function(t) {
        this.element = a(t)
    };

    function e(i) {
        return this.each(function() {
            var t = a(this),
                e = t.data("bs.tab");
            e || t.data("bs.tab", e = new r(this)), "string" == typeof i && e[i]()
        })
    }
    r.VERSION = "3.4.1", r.TRANSITION_DURATION = 150, r.prototype.show = function() {
        var t, e, i, o = this.element,
            n = o.closest("ul:not(.dropdown-menu)"),
            s = (s = o.data("target")) || (s = o.attr("href")) && s.replace(/.*(?=#[^\s]*$)/, "");
        o.parent("li").hasClass("active") || (t = n.find(".active:last a"), e = a.Event("hide.bs.tab", {
            relatedTarget: o[0]
        }), i = a.Event("show.bs.tab", {
            relatedTarget: t[0]
        }), t.trigger(e), o.trigger(i), i.isDefaultPrevented()) || e.isDefaultPrevented() || (i = a(document).find(s), this.activate(o.closest("li"), n), this.activate(i, i.parent(), function() {
            t.trigger({
                type: "hidden.bs.tab",
                relatedTarget: o[0]
            }), o.trigger({
                type: "shown.bs.tab",
                relatedTarget: t[0]
            })
        }))
    }, r.prototype.activate = function(t, e, i) {
        var o = e.find("> .active"),
            n = i && a.support.transition && (o.length && o.hasClass("fade") || !!e.find("> .fade").length);

        function s() {
            o.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !1), t.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded", !0), n ? (t[0].offsetWidth, t.addClass("in")) : t.removeClass("fade"), t.parent(".dropdown-menu").length && t.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !0), i && i()
        }
        o.length && n ? o.one("bsTransitionEnd", s).emulateTransitionEnd(r.TRANSITION_DURATION) : s(), o.removeClass("in")
    };
    var t = a.fn.tab,
        i = (a.fn.tab = e, a.fn.tab.Constructor = r, a.fn.tab.noConflict = function() {
            return a.fn.tab = t, this
        }, function(t) {
            t.preventDefault(), e.call(a(this), "show")
        });
    a(document).on("click.bs.tab.data-api", '[data-toggle="tab"]', i).on("click.bs.tab.data-api", '[data-toggle="pill"]', i)
}(jQuery),
function(a) {
    "use strict";
    var r = function(t, e) {
        this.options = a.extend({}, r.DEFAULTS, e);
        e = this.options.target === r.DEFAULTS.target ? a(this.options.target) : a(document).find(this.options.target);
        this.$target = e.on("scroll.bs.affix.data-api", a.proxy(this.checkPosition, this)).on("click.bs.affix.data-api", a.proxy(this.checkPositionWithEventLoop, this)), this.$element = a(t), this.affixed = null, this.unpin = null, this.pinnedOffset = null, this.checkPosition()
    };

    function i(i) {
        return this.each(function() {
            var t = a(this),
                e = t.data("bs.affix");
            e || t.data("bs.affix", e = new r(this, "object" == typeof i && i)), "string" == typeof i && e[i]()
        })
    }
    r.VERSION = "3.4.1", r.RESET = "affix affix-top affix-bottom", r.DEFAULTS = {
        offset: 0,
        target: window
    }, r.prototype.getState = function(t, e, i, o) {
        var n, s = this.$target.scrollTop(),
            a = this.$element.offset(),
            r = this.$target.height();
        return null != i && "top" == this.affixed ? s < i && "top" : "bottom" == this.affixed ? null != i ? !(s + this.unpin <= a.top) && "bottom" : !(s + r <= t - o) && "bottom" : (a = (n = null == this.affixed) ? s : a.top, null != i && s <= i ? "top" : null != o && t - o <= a + (n ? r : e) && "bottom")
    }, r.prototype.getPinnedOffset = function() {
        if (this.pinnedOffset) return this.pinnedOffset;
        this.$element.removeClass(r.RESET).addClass("affix");
        var t = this.$target.scrollTop(),
            e = this.$element.offset();
        return this.pinnedOffset = e.top - t
    }, r.prototype.checkPositionWithEventLoop = function() {
        setTimeout(a.proxy(this.checkPosition, this), 1)
    }, r.prototype.checkPosition = function() {
        if (this.$element.is(":visible")) {
            var t = this.$element.height(),
                e = this.options.offset,
                i = e.top,
                o = e.bottom,
                n = Math.max(a(document).height(), a(document.body).height()),
                e = ("object" != typeof e && (o = i = e), "function" == typeof i && (i = e.top(this.$element)), "function" == typeof o && (o = e.bottom(this.$element)), this.getState(n, t, i, o));
            if (this.affixed != e) {
                null != this.unpin && this.$element.css("top", "");
                var i = "affix" + (e ? "-" + e : ""),
                    s = a.Event(i + ".bs.affix");
                if (this.$element.trigger(s), s.isDefaultPrevented()) return;
                this.affixed = e, this.unpin = "bottom" == e ? this.getPinnedOffset() : null, this.$element.removeClass(r.RESET).addClass(i).trigger(i.replace("affix", "affixed") + ".bs.affix")
            }
            "bottom" == e && this.$element.offset({
                top: n - t - o
            })
        }
    };
    var t = a.fn.affix;
    a.fn.affix = i, a.fn.affix.Constructor = r, a.fn.affix.noConflict = function() {
        return a.fn.affix = t, this
    }, a(window).on("load", function() {
        a('[data-spy="affix"]').each(function() {
            var t = a(this),
                e = t.data();
            e.offset = e.offset || {}, null != e.offsetBottom && (e.offset.bottom = e.offsetBottom), null != e.offsetTop && (e.offset.top = e.offsetTop), i.call(t, e)
        })
    })
}(jQuery);

// handlebars 4.7.8
! function(a, b) {
    "object" == typeof exports && "object" == typeof module ? module.exports = b() : "function" == typeof define && define.amd ? define([], b) : "object" == typeof exports ? exports.Handlebars = b() : a.Handlebars = b()
}(this, function() {
    return function(a) {
        function b(d) {
            if (c[d]) return c[d].exports;
            var e = c[d] = {
                exports: {},
                id: d,
                loaded: !1
            };
            return a[d].call(e.exports, e, e.exports, b), e.loaded = !0, e.exports
        }
        var c = {};
        return b.m = a, b.c = c, b.p = "", b(0)
    }([function(a, b, c) {
        "use strict";

        function d() {
            var a = r();
            return a.compile = function(b, c) {
                return k.compile(b, c, a)
            }, a.precompile = function(b, c) {
                return k.precompile(b, c, a)
            }, a.AST = i["default"], a.Compiler = k.Compiler, a.JavaScriptCompiler = m["default"], a.Parser = j.parser, a.parse = j.parse, a.parseWithoutProcessing = j.parseWithoutProcessing, a
        }
        var e = c(1)["default"];
        b.__esModule = !0;
        var f = c(2),
            g = e(f),
            h = c(84),
            i = e(h),
            j = c(85),
            k = c(90),
            l = c(91),
            m = e(l),
            n = c(88),
            o = e(n),
            p = c(83),
            q = e(p),
            r = g["default"].create,
            s = d();
        s.create = d, q["default"](s), s.Visitor = o["default"], s["default"] = s, b["default"] = s, a.exports = b["default"]
    }, function(a, b) {
        "use strict";
        b["default"] = function(a) {
            return a && a.__esModule ? a : {
                "default": a
            }
        }, b.__esModule = !0
    }, function(a, b, c) {
        "use strict";

        function d() {
            var a = new h.HandlebarsEnvironment;
            return n.extend(a, h), a.SafeString = j["default"], a.Exception = l["default"], a.Utils = n, a.escapeExpression = n.escapeExpression, a.VM = p, a.template = function(b) {
                return p.template(b, a)
            }, a
        }
        var e = c(3)["default"],
            f = c(1)["default"];
        b.__esModule = !0;
        var g = c(4),
            h = e(g),
            i = c(77),
            j = f(i),
            k = c(6),
            l = f(k),
            m = c(5),
            n = e(m),
            o = c(78),
            p = e(o),
            q = c(83),
            r = f(q),
            s = d();
        s.create = d, r["default"](s), s["default"] = s, b["default"] = s, a.exports = b["default"]
    }, function(a, b) {
        "use strict";
        b["default"] = function(a) {
            if (a && a.__esModule) return a;
            var b = {};
            if (null != a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && (b[c] = a[c]);
            return b["default"] = a, b
        }, b.__esModule = !0
    }, function(a, b, c) {
        "use strict";

        function d(a, b, c) {
            this.helpers = a || {}, this.partials = b || {}, this.decorators = c || {}, i.registerDefaultHelpers(this), j.registerDefaultDecorators(this)
        }
        var e = c(1)["default"];
        b.__esModule = !0, b.HandlebarsEnvironment = d;
        var f = c(5),
            g = c(6),
            h = e(g),
            i = c(10),
            j = c(70),
            k = c(72),
            l = e(k),
            m = c(73),
            n = "4.7.8";
        b.VERSION = n;
        var o = 8;
        b.COMPILER_REVISION = o;
        var p = 7;
        b.LAST_COMPATIBLE_COMPILER_REVISION = p;
        var q = {
            1: "<= 1.0.rc.2",
            2: "== 1.0.0-rc.3",
            3: "== 1.0.0-rc.4",
            4: "== 1.x.x",
            5: "== 2.0.0-alpha.x",
            6: ">= 2.0.0-beta.1",
            7: ">= 4.0.0 <4.3.0",
            8: ">= 4.3.0"
        };
        b.REVISION_CHANGES = q;
        var r = "[object Object]";
        d.prototype = {
            constructor: d,
            logger: l["default"],
            log: l["default"].log,
            registerHelper: function(a, b) {
                if (f.toString.call(a) === r) {
                    if (b) throw new h["default"]("Arg not supported with multiple helpers");
                    f.extend(this.helpers, a)
                } else this.helpers[a] = b
            },
            unregisterHelper: function(a) {
                delete this.helpers[a]
            },
            registerPartial: function(a, b) {
                if (f.toString.call(a) === r) f.extend(this.partials, a);
                else {
                    if ("undefined" == typeof b) throw new h["default"]('Attempting to register a partial called "' + a + '" as undefined');
                    this.partials[a] = b
                }
            },
            unregisterPartial: function(a) {
                delete this.partials[a]
            },
            registerDecorator: function(a, b) {
                if (f.toString.call(a) === r) {
                    if (b) throw new h["default"]("Arg not supported with multiple decorators");
                    f.extend(this.decorators, a)
                } else this.decorators[a] = b
            },
            unregisterDecorator: function(a) {
                delete this.decorators[a]
            },
            resetLoggedPropertyAccesses: function() {
                m.resetLoggedProperties()
            }
        };
        var s = l["default"].log;
        b.log = s, b.createFrame = f.createFrame, b.logger = l["default"]
    }, function(a, b) {
        "use strict";

        function c(a) {
            return k[a]
        }

        function d(a) {
            for (var b = 1; b < arguments.length; b++)
                for (var c in arguments[b]) Object.prototype.hasOwnProperty.call(arguments[b], c) && (a[c] = arguments[b][c]);
            return a
        }

        function e(a, b) {
            for (var c = 0, d = a.length; c < d; c++)
                if (a[c] === b) return c;
            return -1
        }

        function f(a) {
            if ("string" != typeof a) {
                if (a && a.toHTML) return a.toHTML();
                if (null == a) return "";
                if (!a) return a + "";
                a = "" + a
            }
            return m.test(a) ? a.replace(l, c) : a
        }

        function g(a) {
            return !a && 0 !== a || !(!p(a) || 0 !== a.length)
        }

        function h(a) {
            var b = d({}, a);
            return b._parent = a, b
        }

        function i(a, b) {
            return a.path = b, a
        }

        function j(a, b) {
            return (a ? a + "." : "") + b
        }
        b.__esModule = !0, b.extend = d, b.indexOf = e, b.escapeExpression = f, b.isEmpty = g, b.createFrame = h, b.blockParams = i, b.appendContextPath = j;
        var k = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#x27;",
                "`": "&#x60;",
                "=": "&#x3D;"
            },
            l = /[&<>"'`=]/g,
            m = /[&<>"'`=]/,
            n = Object.prototype.toString;
        b.toString = n;
        var o = function(a) {
            return "function" == typeof a
        };
        o(/x/) && (b.isFunction = o = function(a) {
            return "function" == typeof a && "[object Function]" === n.call(a)
        }), b.isFunction = o;
        var p = Array.isArray || function(a) {
            return !(!a || "object" != typeof a) && "[object Array]" === n.call(a)
        };
        b.isArray = p
    }, function(a, b, c) {
        "use strict";

        function d(a, b) {
            var c = b && b.loc,
                g = void 0,
                h = void 0,
                i = void 0,
                j = void 0;
            c && (g = c.start.line, h = c.end.line, i = c.start.column, j = c.end.column, a += " - " + g + ":" + i);
            for (var k = Error.prototype.constructor.call(this, a), l = 0; l < f.length; l++) this[f[l]] = k[f[l]];
            Error.captureStackTrace && Error.captureStackTrace(this, d);
            try {
                c && (this.lineNumber = g, this.endLineNumber = h, e ? (Object.defineProperty(this, "column", {
                    value: i,
                    enumerable: !0
                }), Object.defineProperty(this, "endColumn", {
                    value: j,
                    enumerable: !0
                })) : (this.column = i, this.endColumn = j))
            } catch (m) {}
        }
        var e = c(7)["default"];
        b.__esModule = !0;
        var f = ["description", "fileName", "lineNumber", "endLineNumber", "message", "name", "number", "stack"];
        d.prototype = new Error, b["default"] = d, a.exports = b["default"]
    }, function(a, b, c) {
        a.exports = {
            "default": c(8),
            __esModule: !0
        }
    }, function(a, b, c) {
        var d = c(9);
        a.exports = function(a, b, c) {
            return d.setDesc(a, b, c)
        }
    }, function(a, b) {
        var c = Object;
        a.exports = {
            create: c.create,
            getProto: c.getPrototypeOf,
            isEnum: {}.propertyIsEnumerable,
            getDesc: c.getOwnPropertyDescriptor,
            setDesc: c.defineProperty,
            setDescs: c.defineProperties,
            getKeys: c.keys,
            getNames: c.getOwnPropertyNames,
            getSymbols: c.getOwnPropertySymbols,
            each: [].forEach
        }
    }, function(a, b, c) {
        "use strict";

        function d(a) {
            h["default"](a), j["default"](a), l["default"](a), n["default"](a), p["default"](a), r["default"](a), t["default"](a)
        }

        function e(a, b, c) {
            a.helpers[b] && (a.hooks[b] = a.helpers[b], c || delete a.helpers[b])
        }
        var f = c(1)["default"];
        b.__esModule = !0, b.registerDefaultHelpers = d, b.moveHelperToHooks = e;
        var g = c(11),
            h = f(g),
            i = c(12),
            j = f(i),
            k = c(65),
            l = f(k),
            m = c(66),
            n = f(m),
            o = c(67),
            p = f(o),
            q = c(68),
            r = f(q),
            s = c(69),
            t = f(s)
    }, function(a, b, c) {
        "use strict";
        b.__esModule = !0;
        var d = c(5);
        b["default"] = function(a) {
            a.registerHelper("blockHelperMissing", function(b, c) {
                var e = c.inverse,
                    f = c.fn;
                if (b === !0) return f(this);
                if (b === !1 || null == b) return e(this);
                if (d.isArray(b)) return b.length > 0 ? (c.ids && (c.ids = [c.name]), a.helpers.each(b, c)) : e(this);
                if (c.data && c.ids) {
                    var g = d.createFrame(c.data);
                    g.contextPath = d.appendContextPath(c.data.contextPath, c.name), c = {
                        data: g
                    }
                }
                return f(b, c)
            })
        }, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";
        var d = c(13)["default"],
            e = c(43)["default"],
            f = c(55)["default"],
            g = c(60)["default"],
            h = c(1)["default"];
        b.__esModule = !0;
        var i = c(5),
            j = c(6),
            k = h(j);
        b["default"] = function(a) {
            a.registerHelper("each", function(a, b) {
                function c(b, c, d) {
                    n && (n.key = b, n.index = c, n.first = 0 === c, n.last = !!d, o && (n.contextPath = o + b)), m += h(a[b], {
                        data: n,
                        blockParams: i.blockParams([a[b], b], [o + b, null])
                    })
                }
                if (!b) throw new k["default"]("Must pass iterator to #each");
                var h = b.fn,
                    j = b.inverse,
                    l = 0,
                    m = "",
                    n = void 0,
                    o = void 0;
                if (b.data && b.ids && (o = i.appendContextPath(b.data.contextPath, b.ids[0]) + "."), i.isFunction(a) && (a = a.call(this)), b.data && (n = i.createFrame(b.data)), a && "object" == typeof a)
                    if (i.isArray(a))
                        for (var p = a.length; l < p; l++) l in a && c(l, l, l === a.length - 1);
                    else if ("function" == typeof d && a[e]) {
                    for (var q = [], r = f(a), s = r.next(); !s.done; s = r.next()) q.push(s.value);
                    a = q;
                    for (var p = a.length; l < p; l++) c(l, l, l === a.length - 1)
                } else ! function() {
                    var b = void 0;
                    g(a).forEach(function(a) {
                        void 0 !== b && c(b, l - 1), b = a, l++
                    }), void 0 !== b && c(b, l - 1, !0)
                }();
                return 0 === l && (m = j(this)), m
            })
        }, a.exports = b["default"]
    }, function(a, b, c) {
        a.exports = {
            "default": c(14),
            __esModule: !0
        }
    }, function(a, b, c) {
        c(15), c(42), a.exports = c(21).Symbol
    }, function(a, b, c) {
        "use strict";
        var d = c(9),
            e = c(16),
            f = c(17),
            g = c(18),
            h = c(20),
            i = c(24),
            j = c(19),
            k = c(27),
            l = c(28),
            m = c(30),
            n = c(29),
            o = c(31),
            p = c(36),
            q = c(37),
            r = c(38),
            s = c(39),
            t = c(32),
            u = c(26),
            v = d.getDesc,
            w = d.setDesc,
            x = d.create,
            y = p.get,
            z = e.Symbol,
            A = e.JSON,
            B = A && A.stringify,
            C = !1,
            D = n("_hidden"),
            E = d.isEnum,
            F = k("symbol-registry"),
            G = k("symbols"),
            H = "function" == typeof z,
            I = Object.prototype,
            J = g && j(function() {
                return 7 != x(w({}, "a", {
                    get: function() {
                        return w(this, "a", {
                            value: 7
                        }).a
                    }
                })).a
            }) ? function(a, b, c) {
                var d = v(I, b);
                d && delete I[b], w(a, b, c), d && a !== I && w(I, b, d)
            } : w,
            K = function(a) {
                var b = G[a] = x(z.prototype);
                return b._k = a, g && C && J(I, a, {
                    configurable: !0,
                    set: function(b) {
                        f(this, D) && f(this[D], a) && (this[D][a] = !1), J(this, a, u(1, b))
                    }
                }), b
            },
            L = function(a) {
                return "symbol" == typeof a
            },
            M = function(a, b, c) {
                return c && f(G, b) ? (c.enumerable ? (f(a, D) && a[D][b] && (a[D][b] = !1), c = x(c, {
                    enumerable: u(0, !1)
                })) : (f(a, D) || w(a, D, u(1, {})), a[D][b] = !0), J(a, b, c)) : w(a, b, c)
            },
            N = function(a, b) {
                s(a);
                for (var c, d = q(b = t(b)), e = 0, f = d.length; f > e;) M(a, c = d[e++], b[c]);
                return a
            },
            O = function(a, b) {
                return void 0 === b ? x(a) : N(x(a), b)
            },
            P = function(a) {
                var b = E.call(this, a);
                return !(b || !f(this, a) || !f(G, a) || f(this, D) && this[D][a]) || b
            },
            Q = function(a, b) {
                var c = v(a = t(a), b);
                return !c || !f(G, b) || f(a, D) && a[D][b] || (c.enumerable = !0), c
            },
            R = function(a) {
                for (var b, c = y(t(a)), d = [], e = 0; c.length > e;) f(G, b = c[e++]) || b == D || d.push(b);
                return d
            },
            S = function(a) {
                for (var b, c = y(t(a)), d = [], e = 0; c.length > e;) f(G, b = c[e++]) && d.push(G[b]);
                return d
            },
            T = function(a) {
                if (void 0 !== a && !L(a)) {
                    for (var b, c, d = [a], e = 1, f = arguments; f.length > e;) d.push(f[e++]);
                    return b = d[1], "function" == typeof b && (c = b), !c && r(b) || (b = function(a, b) {
                        if (c && (b = c.call(this, a, b)), !L(b)) return b
                    }), d[1] = b, B.apply(A, d)
                }
            },
            U = j(function() {
                var a = z();
                return "[null]" != B([a]) || "{}" != B({
                    a: a
                }) || "{}" != B(Object(a))
            });
        H || (z = function() {
            if (L(this)) throw TypeError("Symbol is not a constructor");
            return K(m(arguments.length > 0 ? arguments[0] : void 0))
        }, i(z.prototype, "toString", function() {
            return this._k
        }), L = function(a) {
            return a instanceof z
        }, d.create = O, d.isEnum = P, d.getDesc = Q, d.setDesc = M, d.setDescs = N, d.getNames = p.get = R, d.getSymbols = S, g && !c(41) && i(I, "propertyIsEnumerable", P, !0));
        var V = {
            "for": function(a) {
                return f(F, a += "") ? F[a] : F[a] = z(a)
            },
            keyFor: function(a) {
                return o(F, a)
            },
            useSetter: function() {
                C = !0
            },
            useSimple: function() {
                C = !1
            }
        };
        d.each.call("hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables".split(","), function(a) {
            var b = n(a);
            V[a] = H ? b : K(b)
        }), C = !0, h(h.G + h.W, {
            Symbol: z
        }), h(h.S, "Symbol", V), h(h.S + h.F * !H, "Object", {
            create: O,
            defineProperty: M,
            defineProperties: N,
            getOwnPropertyDescriptor: Q,
            getOwnPropertyNames: R,
            getOwnPropertySymbols: S
        }), A && h(h.S + h.F * (!H || U), "JSON", {
            stringify: T
        }), l(z, "Symbol"), l(Math, "Math", !0), l(e.JSON, "JSON", !0)
    }, function(a, b) {
        var c = a.exports = "undefined" != typeof window && window.Math == Math ? window : "undefined" != typeof self && self.Math == Math ? self : Function("return this")();
        "number" == typeof __g && (__g = c)
    }, function(a, b) {
        var c = {}.hasOwnProperty;
        a.exports = function(a, b) {
            return c.call(a, b)
        }
    }, function(a, b, c) {
        a.exports = !c(19)(function() {
            return 7 != Object.defineProperty({}, "a", {
                get: function() {
                    return 7
                }
            }).a
        })
    }, function(a, b) {
        a.exports = function(a) {
            try {
                return !!a()
            } catch (b) {
                return !0
            }
        }
    }, function(a, b, c) {
        var d = c(16),
            e = c(21),
            f = c(22),
            g = "prototype",
            h = function(a, b, c) {
                var i, j, k, l = a & h.F,
                    m = a & h.G,
                    n = a & h.S,
                    o = a & h.P,
                    p = a & h.B,
                    q = a & h.W,
                    r = m ? e : e[b] || (e[b] = {}),
                    s = m ? d : n ? d[b] : (d[b] || {})[g];
                m && (c = b);
                for (i in c) j = !l && s && i in s, j && i in r || (k = j ? s[i] : c[i], r[i] = m && "function" != typeof s[i] ? c[i] : p && j ? f(k, d) : q && s[i] == k ? function(a) {
                    var b = function(b) {
                        return this instanceof a ? new a(b) : a(b)
                    };
                    return b[g] = a[g], b
                }(k) : o && "function" == typeof k ? f(Function.call, k) : k, o && ((r[g] || (r[g] = {}))[i] = k))
            };
        h.F = 1, h.G = 2, h.S = 4, h.P = 8, h.B = 16, h.W = 32, a.exports = h
    }, function(a, b) {
        var c = a.exports = {
            version: "1.2.6"
        };
        "number" == typeof __e && (__e = c)
    }, function(a, b, c) {
        var d = c(23);
        a.exports = function(a, b, c) {
            if (d(a), void 0 === b) return a;
            switch (c) {
                case 1:
                    return function(c) {
                        return a.call(b, c)
                    };
                case 2:
                    return function(c, d) {
                        return a.call(b, c, d)
                    };
                case 3:
                    return function(c, d, e) {
                        return a.call(b, c, d, e)
                    }
            }
            return function() {
                return a.apply(b, arguments)
            }
        }
    }, function(a, b) {
        a.exports = function(a) {
            if ("function" != typeof a) throw TypeError(a + " is not a function!");
            return a
        }
    }, function(a, b, c) {
        a.exports = c(25)
    }, function(a, b, c) {
        var d = c(9),
            e = c(26);
        a.exports = c(18) ? function(a, b, c) {
            return d.setDesc(a, b, e(1, c))
        } : function(a, b, c) {
            return a[b] = c, a
        }
    }, function(a, b) {
        a.exports = function(a, b) {
            return {
                enumerable: !(1 & a),
                configurable: !(2 & a),
                writable: !(4 & a),
                value: b
            }
        }
    }, function(a, b, c) {
        var d = c(16),
            e = "__core-js_shared__",
            f = d[e] || (d[e] = {});
        a.exports = function(a) {
            return f[a] || (f[a] = {})
        }
    }, function(a, b, c) {
        var d = c(9).setDesc,
            e = c(17),
            f = c(29)("toStringTag");
        a.exports = function(a, b, c) {
            a && !e(a = c ? a : a.prototype, f) && d(a, f, {
                configurable: !0,
                value: b
            })
        }
    }, function(a, b, c) {
        var d = c(27)("wks"),
            e = c(30),
            f = c(16).Symbol;
        a.exports = function(a) {
            return d[a] || (d[a] = f && f[a] || (f || e)("Symbol." + a))
        }
    }, function(a, b) {
        var c = 0,
            d = Math.random();
        a.exports = function(a) {
            return "Symbol(".concat(void 0 === a ? "" : a, ")_", (++c + d).toString(36))
        }
    }, function(a, b, c) {
        var d = c(9),
            e = c(32);
        a.exports = function(a, b) {
            for (var c, f = e(a), g = d.getKeys(f), h = g.length, i = 0; h > i;)
                if (f[c = g[i++]] === b) return c
        }
    }, function(a, b, c) {
        var d = c(33),
            e = c(35);
        a.exports = function(a) {
            return d(e(a))
        }
    }, function(a, b, c) {
        var d = c(34);
        a.exports = Object("z").propertyIsEnumerable(0) ? Object : function(a) {
            return "String" == d(a) ? a.split("") : Object(a)
        }
    }, function(a, b) {
        var c = {}.toString;
        a.exports = function(a) {
            return c.call(a).slice(8, -1)
        }
    }, function(a, b) {
        a.exports = function(a) {
            if (void 0 == a) throw TypeError("Can't call method on  " + a);
            return a
        }
    }, function(a, b, c) {
        var d = c(32),
            e = c(9).getNames,
            f = {}.toString,
            g = "object" == typeof window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [],
            h = function(a) {
                try {
                    return e(a)
                } catch (b) {
                    return g.slice()
                }
            };
        a.exports.get = function(a) {
            return g && "[object Window]" == f.call(a) ? h(a) : e(d(a))
        }
    }, function(a, b, c) {
        var d = c(9);
        a.exports = function(a) {
            var b = d.getKeys(a),
                c = d.getSymbols;
            if (c)
                for (var e, f = c(a), g = d.isEnum, h = 0; f.length > h;) g.call(a, e = f[h++]) && b.push(e);
            return b
        }
    }, function(a, b, c) {
        var d = c(34);
        a.exports = Array.isArray || function(a) {
            return "Array" == d(a)
        }
    }, function(a, b, c) {
        var d = c(40);
        a.exports = function(a) {
            if (!d(a)) throw TypeError(a + " is not an object!");
            return a
        }
    }, function(a, b) {
        a.exports = function(a) {
            return "object" == typeof a ? null !== a : "function" == typeof a
        }
    }, function(a, b) {
        a.exports = !0
    }, function(a, b) {}, function(a, b, c) {
        a.exports = {
            "default": c(44),
            __esModule: !0
        }
    }, function(a, b, c) {
        c(45), c(51), a.exports = c(29)("iterator")
    }, function(a, b, c) {
        "use strict";
        var d = c(46)(!0);
        c(48)(String, "String", function(a) {
            this._t = String(a), this._i = 0
        }, function() {
            var a, b = this._t,
                c = this._i;
            return c >= b.length ? {
                value: void 0,
                done: !0
            } : (a = d(b, c), this._i += a.length, {
                value: a,
                done: !1
            })
        })
    }, function(a, b, c) {
        var d = c(47),
            e = c(35);
        a.exports = function(a) {
            return function(b, c) {
                var f, g, h = String(e(b)),
                    i = d(c),
                    j = h.length;
                return i < 0 || i >= j ? a ? "" : void 0 : (f = h.charCodeAt(i), f < 55296 || f > 56319 || i + 1 === j || (g = h.charCodeAt(i + 1)) < 56320 || g > 57343 ? a ? h.charAt(i) : f : a ? h.slice(i, i + 2) : (f - 55296 << 10) + (g - 56320) + 65536)
            }
        }
    }, function(a, b) {
        var c = Math.ceil,
            d = Math.floor;
        a.exports = function(a) {
            return isNaN(a = +a) ? 0 : (a > 0 ? d : c)(a)
        }
    }, function(a, b, c) {
        "use strict";
        var d = c(41),
            e = c(20),
            f = c(24),
            g = c(25),
            h = c(17),
            i = c(49),
            j = c(50),
            k = c(28),
            l = c(9).getProto,
            m = c(29)("iterator"),
            n = !([].keys && "next" in [].keys()),
            o = "@@iterator",
            p = "keys",
            q = "values",
            r = function() {
                return this
            };
        a.exports = function(a, b, c, s, t, u, v) {
            j(c, b, s);
            var w, x, y = function(a) {
                    if (!n && a in C) return C[a];
                    switch (a) {
                        case p:
                            return function() {
                                return new c(this, a)
                            };
                        case q:
                            return function() {
                                return new c(this, a)
                            }
                    }
                    return function() {
                        return new c(this, a)
                    }
                },
                z = b + " Iterator",
                A = t == q,
                B = !1,
                C = a.prototype,
                D = C[m] || C[o] || t && C[t],
                E = D || y(t);
            if (D) {
                var F = l(E.call(new a));
                k(F, z, !0), !d && h(C, o) && g(F, m, r), A && D.name !== q && (B = !0, E = function() {
                    return D.call(this)
                })
            }
            if (d && !v || !n && !B && C[m] || g(C, m, E), i[b] = E, i[z] = r, t)
                if (w = {
                        values: A ? E : y(q),
                        keys: u ? E : y(p),
                        entries: A ? y("entries") : E
                    }, v)
                    for (x in w) x in C || f(C, x, w[x]);
                else e(e.P + e.F * (n || B), b, w);
            return w
        }
    }, function(a, b) {
        a.exports = {}
    }, function(a, b, c) {
        "use strict";
        var d = c(9),
            e = c(26),
            f = c(28),
            g = {};
        c(25)(g, c(29)("iterator"), function() {
            return this
        }), a.exports = function(a, b, c) {
            a.prototype = d.create(g, {
                next: e(1, c)
            }), f(a, b + " Iterator")
        }
    }, function(a, b, c) {
        c(52);
        var d = c(49);
        d.NodeList = d.HTMLCollection = d.Array
    }, function(a, b, c) {
        "use strict";
        var d = c(53),
            e = c(54),
            f = c(49),
            g = c(32);
        a.exports = c(48)(Array, "Array", function(a, b) {
            this._t = g(a), this._i = 0, this._k = b
        }, function() {
            var a = this._t,
                b = this._k,
                c = this._i++;
            return !a || c >= a.length ? (this._t = void 0, e(1)) : "keys" == b ? e(0, c) : "values" == b ? e(0, a[c]) : e(0, [c, a[c]])
        }, "values"), f.Arguments = f.Array, d("keys"), d("values"), d("entries")
    }, function(a, b) {
        a.exports = function() {}
    }, function(a, b) {
        a.exports = function(a, b) {
            return {
                value: b,
                done: !!a
            }
        }
    }, function(a, b, c) {
        a.exports = {
            "default": c(56),
            __esModule: !0
        }
    }, function(a, b, c) {
        c(51), c(45), a.exports = c(57)
    }, function(a, b, c) {
        var d = c(39),
            e = c(58);
        a.exports = c(21).getIterator = function(a) {
            var b = e(a);
            if ("function" != typeof b) throw TypeError(a + " is not iterable!");
            return d(b.call(a))
        }
    }, function(a, b, c) {
        var d = c(59),
            e = c(29)("iterator"),
            f = c(49);
        a.exports = c(21).getIteratorMethod = function(a) {
            if (void 0 != a) return a[e] || a["@@iterator"] || f[d(a)]
        }
    }, function(a, b, c) {
        var d = c(34),
            e = c(29)("toStringTag"),
            f = "Arguments" == d(function() {
                return arguments
            }());
        a.exports = function(a) {
            var b, c, g;
            return void 0 === a ? "Undefined" : null === a ? "Null" : "string" == typeof(c = (b = Object(a))[e]) ? c : f ? d(b) : "Object" == (g = d(b)) && "function" == typeof b.callee ? "Arguments" : g
        }
    }, function(a, b, c) {
        a.exports = {
            "default": c(61),
            __esModule: !0
        }
    }, function(a, b, c) {
        c(62), a.exports = c(21).Object.keys
    }, function(a, b, c) {
        var d = c(63);
        c(64)("keys", function(a) {
            return function(b) {
                return a(d(b))
            }
        })
    }, function(a, b, c) {
        var d = c(35);
        a.exports = function(a) {
            return Object(d(a))
        }
    }, function(a, b, c) {
        var d = c(20),
            e = c(21),
            f = c(19);
        a.exports = function(a, b) {
            var c = (e.Object || {})[a] || Object[a],
                g = {};
            g[a] = b(c), d(d.S + d.F * f(function() {
                c(1)
            }), "Object", g)
        }
    }, function(a, b, c) {
        "use strict";
        var d = c(1)["default"];
        b.__esModule = !0;
        var e = c(6),
            f = d(e);
        b["default"] = function(a) {
            a.registerHelper("helperMissing", function() {
                if (1 !== arguments.length) throw new f["default"]('Missing helper: "' + arguments[arguments.length - 1].name + '"')
            })
        }, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";
        var d = c(1)["default"];
        b.__esModule = !0;
        var e = c(5),
            f = c(6),
            g = d(f);
        b["default"] = function(a) {
            a.registerHelper("if", function(a, b) {
                if (2 != arguments.length) throw new g["default"]("#if requires exactly one argument");
                return e.isFunction(a) && (a = a.call(this)), !b.hash.includeZero && !a || e.isEmpty(a) ? b.inverse(this) : b.fn(this)
            }), a.registerHelper("unless", function(b, c) {
                if (2 != arguments.length) throw new g["default"]("#unless requires exactly one argument");
                return a.helpers["if"].call(this, b, {
                    fn: c.inverse,
                    inverse: c.fn,
                    hash: c.hash
                })
            })
        }, a.exports = b["default"]
    }, function(a, b) {
        "use strict";
        b.__esModule = !0, b["default"] = function(a) {
            a.registerHelper("log", function() {
                for (var b = [void 0], c = arguments[arguments.length - 1], d = 0; d < arguments.length - 1; d++) b.push(arguments[d]);
                var e = 1;
                null != c.hash.level ? e = c.hash.level : c.data && null != c.data.level && (e = c.data.level), b[0] = e, a.log.apply(a, b)
            })
        }, a.exports = b["default"]
    }, function(a, b) {
        "use strict";
        b.__esModule = !0, b["default"] = function(a) {
            a.registerHelper("lookup", function(a, b, c) {
                return a ? c.lookupProperty(a, b) : a
            })
        }, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";
        var d = c(1)["default"];
        b.__esModule = !0;
        var e = c(5),
            f = c(6),
            g = d(f);
        b["default"] = function(a) {
            a.registerHelper("with", function(a, b) {
                if (2 != arguments.length) throw new g["default"]("#with requires exactly one argument");
                e.isFunction(a) && (a = a.call(this));
                var c = b.fn;
                if (e.isEmpty(a)) return b.inverse(this);
                var d = b.data;
                return b.data && b.ids && (d = e.createFrame(b.data), d.contextPath = e.appendContextPath(b.data.contextPath, b.ids[0])), c(a, {
                    data: d,
                    blockParams: e.blockParams([a], [d && d.contextPath])
                })
            })
        }, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";

        function d(a) {
            g["default"](a)
        }
        var e = c(1)["default"];
        b.__esModule = !0, b.registerDefaultDecorators = d;
        var f = c(71),
            g = e(f)
    }, function(a, b, c) {
        "use strict";
        b.__esModule = !0;
        var d = c(5);
        b["default"] = function(a) {
            a.registerDecorator("inline", function(a, b, c, e) {
                var f = a;
                return b.partials || (b.partials = {}, f = function(e, f) {
                    var g = c.partials;
                    c.partials = d.extend({}, g, b.partials);
                    var h = a(e, f);
                    return c.partials = g, h
                }), b.partials[e.args[0]] = e.fn, f
            })
        }, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";
        b.__esModule = !0;
        var d = c(5),
            e = {
                methodMap: ["debug", "info", "warn", "error"],
                level: "info",
                lookupLevel: function(a) {
                    if ("string" == typeof a) {
                        var b = d.indexOf(e.methodMap, a.toLowerCase());
                        a = b >= 0 ? b : parseInt(a, 10)
                    }
                    return a
                },
                log: function(a) {
                    if (a = e.lookupLevel(a), "undefined" != typeof console && e.lookupLevel(e.level) <= a) {
                        var b = e.methodMap[a];
                        console[b] || (b = "log");
                        for (var c = arguments.length, d = Array(c > 1 ? c - 1 : 0), f = 1; f < c; f++) d[f - 1] = arguments[f];
                        console[b].apply(console, d)
                    }
                }
            };
        b["default"] = e, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";

        function d(a) {
            var b = i(null);
            b.constructor = !1, b.__defineGetter__ = !1, b.__defineSetter__ = !1, b.__lookupGetter__ = !1;
            var c = i(null);
            return c.__proto__ = !1, {
                properties: {
                    whitelist: l.createNewLookupObject(c, a.allowedProtoProperties),
                    defaultValue: a.allowProtoPropertiesByDefault
                },
                methods: {
                    whitelist: l.createNewLookupObject(b, a.allowedProtoMethods),
                    defaultValue: a.allowProtoMethodsByDefault
                }
            }
        }

        function e(a, b, c) {
            return "function" == typeof a ? f(b.methods, c) : f(b.properties, c)
        }

        function f(a, b) {
            return void 0 !== a.whitelist[b] ? a.whitelist[b] === !0 : void 0 !== a.defaultValue ? a.defaultValue : (g(b), !1)
        }

        function g(a) {
            o[a] !== !0 && (o[a] = !0, n["default"].log("error", 'Handlebars: Access has been denied to resolve the property "' + a + '" because it is not an "own property" of its parent.\nYou can add a runtime option to disable the check or this warning:\nSee https://handlebarsjs.com/api-reference/runtime-options.html#options-to-control-prototype-access for details'))
        }

        function h() {
            j(o).forEach(function(a) {
                delete o[a]
            })
        }
        var i = c(74)["default"],
            j = c(60)["default"],
            k = c(1)["default"];
        b.__esModule = !0, b.createProtoAccessControl = d, b.resultIsAllowed = e, b.resetLoggedProperties = h;
        var l = c(76),
            m = c(72),
            n = k(m),
            o = i(null)
    }, function(a, b, c) {
        a.exports = {
            "default": c(75),
            __esModule: !0
        }
    }, function(a, b, c) {
        var d = c(9);
        a.exports = function(a, b) {
            return d.create(a, b)
        }
    }, function(a, b, c) {
        "use strict";

        function d() {
            for (var a = arguments.length, b = Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            return f.extend.apply(void 0, [e(null)].concat(b))
        }
        var e = c(74)["default"];
        b.__esModule = !0, b.createNewLookupObject = d;
        var f = c(5)
    }, function(a, b) {
        "use strict";

        function c(a) {
            this.string = a
        }
        b.__esModule = !0, c.prototype.toString = c.prototype.toHTML = function() {
            return "" + this.string
        }, b["default"] = c, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";

        function d(a) {
            var b = a && a[0] || 1,
                c = v.COMPILER_REVISION;
            if (!(b >= v.LAST_COMPATIBLE_COMPILER_REVISION && b <= v.COMPILER_REVISION)) {
                if (b < v.LAST_COMPATIBLE_COMPILER_REVISION) {
                    var d = v.REVISION_CHANGES[c],
                        e = v.REVISION_CHANGES[b];
                    throw new u["default"]("Template was precompiled with an older version of Handlebars than the current runtime. Please update your precompiler to a newer version (" + d + ") or downgrade your runtime to an older version (" + e + ").")
                }
                throw new u["default"]("Template was precompiled with a newer version of Handlebars than the current runtime. Please update your runtime to a newer version (" + a[1] + ").")
            }
        }

        function e(a, b) {
            function c(c, d, e) {
                e.hash && (d = s.extend({}, d, e.hash), e.ids && (e.ids[0] = !0)), c = b.VM.resolvePartial.call(this, c, d, e);
                var f = s.extend({}, e, {
                        hooks: this.hooks,
                        protoAccessControl: this.protoAccessControl
                    }),
                    g = b.VM.invokePartial.call(this, c, d, f);
                if (null == g && b.compile && (e.partials[e.name] = b.compile(c, a.compilerOptions, b), g = e.partials[e.name](d, f)), null != g) {
                    if (e.indent) {
                        for (var h = g.split("\n"), i = 0, j = h.length; i < j && (h[i] || i + 1 !== j); i++) h[i] = e.indent + h[i];
                        g = h.join("\n")
                    }
                    return g
                }
                throw new u["default"]("The partial " + e.name + " could not be compiled when running in runtime-only mode")
            }

            function d(b) {
                function c(b) {
                    return "" + a.main(g, b, g.helpers, g.partials, f, i, h)
                }
                var e = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1],
                    f = e.data;
                d._setup(e), !e.partial && a.useData && (f = j(b, f));
                var h = void 0,
                    i = a.useBlockParams ? [] : void 0;
                return a.useDepths && (h = e.depths ? b != e.depths[0] ? [b].concat(e.depths) : e.depths : [b]), (c = k(a.main, c, g, e.depths || [], f, i))(b, e)
            }
            if (!b) throw new u["default"]("No environment passed to template");
            if (!a || !a.main) throw new u["default"]("Unknown template object: " + typeof a);
            a.main.decorator = a.main_d, b.VM.checkRevision(a.compiler);
            var e = a.compiler && 7 === a.compiler[0],
                g = {
                    strict: function(a, b, c) {
                        if (!(a && b in a)) throw new u["default"]('"' + b + '" not defined in ' + a, {
                            loc: c
                        });
                        return g.lookupProperty(a, b)
                    },
                    lookupProperty: function(a, b) {
                        var c = a[b];
                        return null == c ? c : Object.prototype.hasOwnProperty.call(a, b) ? c : y.resultIsAllowed(c, g.protoAccessControl, b) ? c : void 0
                    },
                    lookup: function(a, b) {
                        for (var c = a.length, d = 0; d < c; d++) {
                            var e = a[d] && g.lookupProperty(a[d], b);
                            if (null != e) return a[d][b]
                        }
                    },
                    lambda: function(a, b) {
                        return "function" == typeof a ? a.call(b) : a
                    },
                    escapeExpression: s.escapeExpression,
                    invokePartial: c,
                    fn: function(b) {
                        var c = a[b];
                        return c.decorator = a[b + "_d"], c
                    },
                    programs: [],
                    program: function(a, b, c, d, e) {
                        var g = this.programs[a],
                            h = this.fn(a);
                        return b || e || d || c ? g = f(this, a, h, b, c, d, e) : g || (g = this.programs[a] = f(this, a, h)), g
                    },
                    data: function(a, b) {
                        for (; a && b--;) a = a._parent;
                        return a
                    },
                    mergeIfNeeded: function(a, b) {
                        var c = a || b;
                        return a && b && a !== b && (c = s.extend({}, b, a)), c
                    },
                    nullContext: n({}),
                    noop: b.VM.noop,
                    compilerInfo: a.compiler
                };
            return d.isTop = !0, d._setup = function(c) {
                if (c.partial) g.protoAccessControl = c.protoAccessControl, g.helpers = c.helpers, g.partials = c.partials, g.decorators = c.decorators, g.hooks = c.hooks;
                else {
                    var d = s.extend({}, b.helpers, c.helpers);
                    l(d, g), g.helpers = d, a.usePartial && (g.partials = g.mergeIfNeeded(c.partials, b.partials)), (a.usePartial || a.useDecorators) && (g.decorators = s.extend({}, b.decorators, c.decorators)), g.hooks = {}, g.protoAccessControl = y.createProtoAccessControl(c);
                    var f = c.allowCallsToHelperMissing || e;
                    w.moveHelperToHooks(g, "helperMissing", f), w.moveHelperToHooks(g, "blockHelperMissing", f)
                }
            }, d._child = function(b, c, d, e) {
                if (a.useBlockParams && !d) throw new u["default"]("must pass block params");
                if (a.useDepths && !e) throw new u["default"]("must pass parent depths");
                return f(g, b, a[b], c, 0, d, e)
            }, d
        }

        function f(a, b, c, d, e, f, g) {
            function h(b) {
                var e = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1],
                    h = g;
                return !g || b == g[0] || b === a.nullContext && null === g[0] || (h = [b].concat(g)), c(a, b, a.helpers, a.partials, e.data || d, f && [e.blockParams].concat(f), h)
            }
            return h = k(c, h, a, g, d, f), h.program = b, h.depth = g ? g.length : 0, h.blockParams = e || 0, h
        }

        function g(a, b, c) {
            return a ? a.call || c.name || (c.name = a, a = c.partials[a]) : a = "@partial-block" === c.name ? c.data["partial-block"] : c.partials[c.name], a
        }

        function h(a, b, c) {
            var d = c.data && c.data["partial-block"];
            c.partial = !0, c.ids && (c.data.contextPath = c.ids[0] || c.data.contextPath);
            var e = void 0;
            if (c.fn && c.fn !== i && ! function() {
                    c.data = v.createFrame(c.data);
                    var a = c.fn;
                    e = c.data["partial-block"] = function(b) {
                        var c = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1];
                        return c.data = v.createFrame(c.data), c.data["partial-block"] = d, a(b, c)
                    }, a.partials && (c.partials = s.extend({}, c.partials, a.partials))
                }(), void 0 === a && e && (a = e), void 0 === a) throw new u["default"]("The partial " + c.name + " could not be found");
            if (a instanceof Function) return a(b, c)
        }

        function i() {
            return ""
        }

        function j(a, b) {
            return b && "root" in b || (b = b ? v.createFrame(b) : {}, b.root = a), b
        }

        function k(a, b, c, d, e, f) {
            if (a.decorator) {
                var g = {};
                b = a.decorator(b, g, c, d && d[0], e, f, d), s.extend(b, g)
            }
            return b
        }

        function l(a, b) {
            o(a).forEach(function(c) {
                var d = a[c];
                a[c] = m(d, b)
            })
        }

        function m(a, b) {
            var c = b.lookupProperty;
            return x.wrapHelper(a, function(a) {
                return s.extend({
                    lookupProperty: c
                }, a)
            })
        }
        var n = c(79)["default"],
            o = c(60)["default"],
            p = c(3)["default"],
            q = c(1)["default"];
        b.__esModule = !0, b.checkRevision = d, b.template = e, b.wrapProgram = f, b.resolvePartial = g, b.invokePartial = h, b.noop = i;
        var r = c(5),
            s = p(r),
            t = c(6),
            u = q(t),
            v = c(4),
            w = c(10),
            x = c(82),
            y = c(73)
    }, function(a, b, c) {
        a.exports = {
            "default": c(80),
            __esModule: !0
        }
    }, function(a, b, c) {
        c(81), a.exports = c(21).Object.seal
    }, function(a, b, c) {
        var d = c(40);
        c(64)("seal", function(a) {
            return function(b) {
                return a && d(b) ? a(b) : b
            }
        })
    }, function(a, b) {
        "use strict";

        function c(a, b) {
            if ("function" != typeof a) return a;
            var c = function() {
                var c = arguments[arguments.length - 1];
                return arguments[arguments.length - 1] = b(c), a.apply(this, arguments)
            };
            return c
        }
        b.__esModule = !0, b.wrapHelper = c
    }, function(a, b) {
        "use strict";
        b.__esModule = !0, b["default"] = function(a) {
            ! function() {
                "object" != typeof globalThis && (Object.prototype.__defineGetter__("__magic__", function() {
                    return this
                }), __magic__.globalThis = __magic__, delete Object.prototype.__magic__)
            }();
            var b = globalThis.Handlebars;
            a.noConflict = function() {
                return globalThis.Handlebars === a && (globalThis.Handlebars = b), a
            }
        }, a.exports = b["default"]
    }, function(a, b) {
        "use strict";
        b.__esModule = !0;
        var c = {
            helpers: {
                helperExpression: function(a) {
                    return "SubExpression" === a.type || ("MustacheStatement" === a.type || "BlockStatement" === a.type) && !!(a.params && a.params.length || a.hash)
                },
                scopedId: function(a) {
                    return /^\.|this\b/.test(a.original)
                },
                simpleId: function(a) {
                    return 1 === a.parts.length && !c.helpers.scopedId(a) && !a.depth
                }
            }
        };
        b["default"] = c, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";

        function d(a, b) {
            if ("Program" === a.type) return a;
            i["default"].yy = o, o.locInfo = function(a) {
                return new o.SourceLocation(b && b.srcName, a)
            };
            var c = i["default"].parse(a);
            return c
        }

        function e(a, b) {
            var c = d(a, b),
                e = new k["default"](b);
            return e.accept(c)
        }
        var f = c(1)["default"],
            g = c(3)["default"];
        b.__esModule = !0, b.parseWithoutProcessing = d, b.parse = e;
        var h = c(86),
            i = f(h),
            j = c(87),
            k = f(j),
            l = c(89),
            m = g(l),
            n = c(5);
        b.parser = i["default"];
        var o = {};
        n.extend(o, m)
    }, function(a, b) {
        "use strict";
        b.__esModule = !0;
        var c = function() {
            function a() {
                this.yy = {}
            }
            var b = {
                    trace: function() {},
                    yy: {},
                    symbols_: {
                        error: 2,
                        root: 3,
                        program: 4,
                        EOF: 5,
                        program_repetition0: 6,
                        statement: 7,
                        mustache: 8,
                        block: 9,
                        rawBlock: 10,
                        partial: 11,
                        partialBlock: 12,
                        content: 13,
                        COMMENT: 14,
                        CONTENT: 15,
                        openRawBlock: 16,
                        rawBlock_repetition0: 17,
                        END_RAW_BLOCK: 18,
                        OPEN_RAW_BLOCK: 19,
                        helperName: 20,
                        openRawBlock_repetition0: 21,
                        openRawBlock_option0: 22,
                        CLOSE_RAW_BLOCK: 23,
                        openBlock: 24,
                        block_option0: 25,
                        closeBlock: 26,
                        openInverse: 27,
                        block_option1: 28,
                        OPEN_BLOCK: 29,
                        openBlock_repetition0: 30,
                        openBlock_option0: 31,
                        openBlock_option1: 32,
                        CLOSE: 33,
                        OPEN_INVERSE: 34,
                        openInverse_repetition0: 35,
                        openInverse_option0: 36,
                        openInverse_option1: 37,
                        openInverseChain: 38,
                        OPEN_INVERSE_CHAIN: 39,
                        openInverseChain_repetition0: 40,
                        openInverseChain_option0: 41,
                        openInverseChain_option1: 42,
                        inverseAndProgram: 43,
                        INVERSE: 44,
                        inverseChain: 45,
                        inverseChain_option0: 46,
                        OPEN_ENDBLOCK: 47,
                        OPEN: 48,
                        mustache_repetition0: 49,
                        mustache_option0: 50,
                        OPEN_UNESCAPED: 51,
                        mustache_repetition1: 52,
                        mustache_option1: 53,
                        CLOSE_UNESCAPED: 54,
                        OPEN_PARTIAL: 55,
                        partialName: 56,
                        partial_repetition0: 57,
                        partial_option0: 58,
                        openPartialBlock: 59,
                        OPEN_PARTIAL_BLOCK: 60,
                        openPartialBlock_repetition0: 61,
                        openPartialBlock_option0: 62,
                        param: 63,
                        sexpr: 64,
                        OPEN_SEXPR: 65,
                        sexpr_repetition0: 66,
                        sexpr_option0: 67,
                        CLOSE_SEXPR: 68,
                        hash: 69,
                        hash_repetition_plus0: 70,
                        hashSegment: 71,
                        ID: 72,
                        EQUALS: 73,
                        blockParams: 74,
                        OPEN_BLOCK_PARAMS: 75,
                        blockParams_repetition_plus0: 76,
                        CLOSE_BLOCK_PARAMS: 77,
                        path: 78,
                        dataName: 79,
                        STRING: 80,
                        NUMBER: 81,
                        BOOLEAN: 82,
                        UNDEFINED: 83,
                        NULL: 84,
                        DATA: 85,
                        pathSegments: 86,
                        SEP: 87,
                        $accept: 0,
                        $end: 1
                    },
                    terminals_: {
                        2: "error",
                        5: "EOF",
                        14: "COMMENT",
                        15: "CONTENT",
                        18: "END_RAW_BLOCK",
                        19: "OPEN_RAW_BLOCK",
                        23: "CLOSE_RAW_BLOCK",
                        29: "OPEN_BLOCK",
                        33: "CLOSE",
                        34: "OPEN_INVERSE",
                        39: "OPEN_INVERSE_CHAIN",
                        44: "INVERSE",
                        47: "OPEN_ENDBLOCK",
                        48: "OPEN",
                        51: "OPEN_UNESCAPED",
                        54: "CLOSE_UNESCAPED",
                        55: "OPEN_PARTIAL",
                        60: "OPEN_PARTIAL_BLOCK",
                        65: "OPEN_SEXPR",
                        68: "CLOSE_SEXPR",
                        72: "ID",
                        73: "EQUALS",
                        75: "OPEN_BLOCK_PARAMS",
                        77: "CLOSE_BLOCK_PARAMS",
                        80: "STRING",
                        81: "NUMBER",
                        82: "BOOLEAN",
                        83: "UNDEFINED",
                        84: "NULL",
                        85: "DATA",
                        87: "SEP"
                    },
                    productions_: [0, [3, 2],
                        [4, 1],
                        [7, 1],
                        [7, 1],
                        [7, 1],
                        [7, 1],
                        [7, 1],
                        [7, 1],
                        [7, 1],
                        [13, 1],
                        [10, 3],
                        [16, 5],
                        [9, 4],
                        [9, 4],
                        [24, 6],
                        [27, 6],
                        [38, 6],
                        [43, 2],
                        [45, 3],
                        [45, 1],
                        [26, 3],
                        [8, 5],
                        [8, 5],
                        [11, 5],
                        [12, 3],
                        [59, 5],
                        [63, 1],
                        [63, 1],
                        [64, 5],
                        [69, 1],
                        [71, 3],
                        [74, 3],
                        [20, 1],
                        [20, 1],
                        [20, 1],
                        [20, 1],
                        [20, 1],
                        [20, 1],
                        [20, 1],
                        [56, 1],
                        [56, 1],
                        [79, 2],
                        [78, 1],
                        [86, 3],
                        [86, 1],
                        [6, 0],
                        [6, 2],
                        [17, 0],
                        [17, 2],
                        [21, 0],
                        [21, 2],
                        [22, 0],
                        [22, 1],
                        [25, 0],
                        [25, 1],
                        [28, 0],
                        [28, 1],
                        [30, 0],
                        [30, 2],
                        [31, 0],
                        [31, 1],
                        [32, 0],
                        [32, 1],
                        [35, 0],
                        [35, 2],
                        [36, 0],
                        [36, 1],
                        [37, 0],
                        [37, 1],
                        [40, 0],
                        [40, 2],
                        [41, 0],
                        [41, 1],
                        [42, 0],
                        [42, 1],
                        [46, 0],
                        [46, 1],
                        [49, 0],
                        [49, 2],
                        [50, 0],
                        [50, 1],
                        [52, 0],
                        [52, 2],
                        [53, 0],
                        [53, 1],
                        [57, 0],
                        [57, 2],
                        [58, 0],
                        [58, 1],
                        [61, 0],
                        [61, 2],
                        [62, 0],
                        [62, 1],
                        [66, 0],
                        [66, 2],
                        [67, 0],
                        [67, 1],
                        [70, 1],
                        [70, 2],
                        [76, 1],
                        [76, 2]
                    ],
                    performAction: function(a, b, c, d, e, f, g) {
                        var h = f.length - 1;
                        switch (e) {
                            case 1:
                                return f[h - 1];
                            case 2:
                                this.$ = d.prepareProgram(f[h]);
                                break;
                            case 3:
                                this.$ = f[h];
                                break;
                            case 4:
                                this.$ = f[h];
                                break;
                            case 5:
                                this.$ = f[h];
                                break;
                            case 6:
                                this.$ = f[h];
                                break;
                            case 7:
                                this.$ = f[h];
                                break;
                            case 8:
                                this.$ = f[h];
                                break;
                            case 9:
                                this.$ = {
                                    type: "CommentStatement",
                                    value: d.stripComment(f[h]),
                                    strip: d.stripFlags(f[h], f[h]),
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 10:
                                this.$ = {
                                    type: "ContentStatement",
                                    original: f[h],
                                    value: f[h],
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 11:
                                this.$ = d.prepareRawBlock(f[h - 2], f[h - 1], f[h], this._$);
                                break;
                            case 12:
                                this.$ = {
                                    path: f[h - 3],
                                    params: f[h - 2],
                                    hash: f[h - 1]
                                };
                                break;
                            case 13:
                                this.$ = d.prepareBlock(f[h - 3], f[h - 2], f[h - 1], f[h], !1, this._$);
                                break;
                            case 14:
                                this.$ = d.prepareBlock(f[h - 3], f[h - 2], f[h - 1], f[h], !0, this._$);
                                break;
                            case 15:
                                this.$ = {
                                    open: f[h - 5],
                                    path: f[h - 4],
                                    params: f[h - 3],
                                    hash: f[h - 2],
                                    blockParams: f[h - 1],
                                    strip: d.stripFlags(f[h - 5], f[h])
                                };
                                break;
                            case 16:
                                this.$ = {
                                    path: f[h - 4],
                                    params: f[h - 3],
                                    hash: f[h - 2],
                                    blockParams: f[h - 1],
                                    strip: d.stripFlags(f[h - 5], f[h])
                                };
                                break;
                            case 17:
                                this.$ = {
                                    path: f[h - 4],
                                    params: f[h - 3],
                                    hash: f[h - 2],
                                    blockParams: f[h - 1],
                                    strip: d.stripFlags(f[h - 5], f[h])
                                };
                                break;
                            case 18:
                                this.$ = {
                                    strip: d.stripFlags(f[h - 1], f[h - 1]),
                                    program: f[h]
                                };
                                break;
                            case 19:
                                var i = d.prepareBlock(f[h - 2], f[h - 1], f[h], f[h], !1, this._$),
                                    j = d.prepareProgram([i], f[h - 1].loc);
                                j.chained = !0, this.$ = {
                                    strip: f[h - 2].strip,
                                    program: j,
                                    chain: !0
                                };
                                break;
                            case 20:
                                this.$ = f[h];
                                break;
                            case 21:
                                this.$ = {
                                    path: f[h - 1],
                                    strip: d.stripFlags(f[h - 2], f[h])
                                };
                                break;
                            case 22:
                                this.$ = d.prepareMustache(f[h - 3], f[h - 2], f[h - 1], f[h - 4], d.stripFlags(f[h - 4], f[h]), this._$);
                                break;
                            case 23:
                                this.$ = d.prepareMustache(f[h - 3], f[h - 2], f[h - 1], f[h - 4], d.stripFlags(f[h - 4], f[h]), this._$);
                                break;
                            case 24:
                                this.$ = {
                                    type: "PartialStatement",
                                    name: f[h - 3],
                                    params: f[h - 2],
                                    hash: f[h - 1],
                                    indent: "",
                                    strip: d.stripFlags(f[h - 4], f[h]),
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 25:
                                this.$ = d.preparePartialBlock(f[h - 2], f[h - 1], f[h], this._$);
                                break;
                            case 26:
                                this.$ = {
                                    path: f[h - 3],
                                    params: f[h - 2],
                                    hash: f[h - 1],
                                    strip: d.stripFlags(f[h - 4], f[h])
                                };
                                break;
                            case 27:
                                this.$ = f[h];
                                break;
                            case 28:
                                this.$ = f[h];
                                break;
                            case 29:
                                this.$ = {
                                    type: "SubExpression",
                                    path: f[h - 3],
                                    params: f[h - 2],
                                    hash: f[h - 1],
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 30:
                                this.$ = {
                                    type: "Hash",
                                    pairs: f[h],
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 31:
                                this.$ = {
                                    type: "HashPair",
                                    key: d.id(f[h - 2]),
                                    value: f[h],
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 32:
                                this.$ = d.id(f[h - 1]);
                                break;
                            case 33:
                                this.$ = f[h];
                                break;
                            case 34:
                                this.$ = f[h];
                                break;
                            case 35:
                                this.$ = {
                                    type: "StringLiteral",
                                    value: f[h],
                                    original: f[h],
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 36:
                                this.$ = {
                                    type: "NumberLiteral",
                                    value: Number(f[h]),
                                    original: Number(f[h]),
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 37:
                                this.$ = {
                                    type: "BooleanLiteral",
                                    value: "true" === f[h],
                                    original: "true" === f[h],
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 38:
                                this.$ = {
                                    type: "UndefinedLiteral",
                                    original: void 0,
                                    value: void 0,
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 39:
                                this.$ = {
                                    type: "NullLiteral",
                                    original: null,
                                    value: null,
                                    loc: d.locInfo(this._$)
                                };
                                break;
                            case 40:
                                this.$ = f[h];
                                break;
                            case 41:
                                this.$ = f[h];
                                break;
                            case 42:
                                this.$ = d.preparePath(!0, f[h], this._$);
                                break;
                            case 43:
                                this.$ = d.preparePath(!1, f[h], this._$);
                                break;
                            case 44:
                                f[h - 2].push({
                                    part: d.id(f[h]),
                                    original: f[h],
                                    separator: f[h - 1]
                                }), this.$ = f[h - 2];
                                break;
                            case 45:
                                this.$ = [{
                                    part: d.id(f[h]),
                                    original: f[h]
                                }];
                                break;
                            case 46:
                                this.$ = [];
                                break;
                            case 47:
                                f[h - 1].push(f[h]);
                                break;
                            case 48:
                                this.$ = [];
                                break;
                            case 49:
                                f[h - 1].push(f[h]);
                                break;
                            case 50:
                                this.$ = [];
                                break;
                            case 51:
                                f[h - 1].push(f[h]);
                                break;
                            case 58:
                                this.$ = [];
                                break;
                            case 59:
                                f[h - 1].push(f[h]);
                                break;
                            case 64:
                                this.$ = [];
                                break;
                            case 65:
                                f[h - 1].push(f[h]);
                                break;
                            case 70:
                                this.$ = [];
                                break;
                            case 71:
                                f[h - 1].push(f[h]);
                                break;
                            case 78:
                                this.$ = [];
                                break;
                            case 79:
                                f[h - 1].push(f[h]);
                                break;
                            case 82:
                                this.$ = [];
                                break;
                            case 83:
                                f[h - 1].push(f[h]);
                                break;
                            case 86:
                                this.$ = [];
                                break;
                            case 87:
                                f[h - 1].push(f[h]);
                                break;
                            case 90:
                                this.$ = [];
                                break;
                            case 91:
                                f[h - 1].push(f[h]);
                                break;
                            case 94:
                                this.$ = [];
                                break;
                            case 95:
                                f[h - 1].push(f[h]);
                                break;
                            case 98:
                                this.$ = [f[h]];
                                break;
                            case 99:
                                f[h - 1].push(f[h]);
                                break;
                            case 100:
                                this.$ = [f[h]];
                                break;
                            case 101:
                                f[h - 1].push(f[h])
                        }
                    },
                    table: [{
                        3: 1,
                        4: 2,
                        5: [2, 46],
                        6: 3,
                        14: [2, 46],
                        15: [2, 46],
                        19: [2, 46],
                        29: [2, 46],
                        34: [2, 46],
                        48: [2, 46],
                        51: [2, 46],
                        55: [2, 46],
                        60: [2, 46]
                    }, {
                        1: [3]
                    }, {
                        5: [1, 4]
                    }, {
                        5: [2, 2],
                        7: 5,
                        8: 6,
                        9: 7,
                        10: 8,
                        11: 9,
                        12: 10,
                        13: 11,
                        14: [1, 12],
                        15: [1, 20],
                        16: 17,
                        19: [1, 23],
                        24: 15,
                        27: 16,
                        29: [1, 21],
                        34: [1, 22],
                        39: [2, 2],
                        44: [2, 2],
                        47: [2, 2],
                        48: [1, 13],
                        51: [1, 14],
                        55: [1, 18],
                        59: 19,
                        60: [1, 24]
                    }, {
                        1: [2, 1]
                    }, {
                        5: [2, 47],
                        14: [2, 47],
                        15: [2, 47],
                        19: [2, 47],
                        29: [2, 47],
                        34: [2, 47],
                        39: [2, 47],
                        44: [2, 47],
                        47: [2, 47],
                        48: [2, 47],
                        51: [2, 47],
                        55: [2, 47],
                        60: [2, 47]
                    }, {
                        5: [2, 3],
                        14: [2, 3],
                        15: [2, 3],
                        19: [2, 3],
                        29: [2, 3],
                        34: [2, 3],
                        39: [2, 3],
                        44: [2, 3],
                        47: [2, 3],
                        48: [2, 3],
                        51: [2, 3],
                        55: [2, 3],
                        60: [2, 3]
                    }, {
                        5: [2, 4],
                        14: [2, 4],
                        15: [2, 4],
                        19: [2, 4],
                        29: [2, 4],
                        34: [2, 4],
                        39: [2, 4],
                        44: [2, 4],
                        47: [2, 4],
                        48: [2, 4],
                        51: [2, 4],
                        55: [2, 4],
                        60: [2, 4]
                    }, {
                        5: [2, 5],
                        14: [2, 5],
                        15: [2, 5],
                        19: [2, 5],
                        29: [2, 5],
                        34: [2, 5],
                        39: [2, 5],
                        44: [2, 5],
                        47: [2, 5],
                        48: [2, 5],
                        51: [2, 5],
                        55: [2, 5],
                        60: [2, 5]
                    }, {
                        5: [2, 6],
                        14: [2, 6],
                        15: [2, 6],
                        19: [2, 6],
                        29: [2, 6],
                        34: [2, 6],
                        39: [2, 6],
                        44: [2, 6],
                        47: [2, 6],
                        48: [2, 6],
                        51: [2, 6],
                        55: [2, 6],
                        60: [2, 6]
                    }, {
                        5: [2, 7],
                        14: [2, 7],
                        15: [2, 7],
                        19: [2, 7],
                        29: [2, 7],
                        34: [2, 7],
                        39: [2, 7],
                        44: [2, 7],
                        47: [2, 7],
                        48: [2, 7],
                        51: [2, 7],
                        55: [2, 7],
                        60: [2, 7]
                    }, {
                        5: [2, 8],
                        14: [2, 8],
                        15: [2, 8],
                        19: [2, 8],
                        29: [2, 8],
                        34: [2, 8],
                        39: [2, 8],
                        44: [2, 8],
                        47: [2, 8],
                        48: [2, 8],
                        51: [2, 8],
                        55: [2, 8],
                        60: [2, 8]
                    }, {
                        5: [2, 9],
                        14: [2, 9],
                        15: [2, 9],
                        19: [2, 9],
                        29: [2, 9],
                        34: [2, 9],
                        39: [2, 9],
                        44: [2, 9],
                        47: [2, 9],
                        48: [2, 9],
                        51: [2, 9],
                        55: [2, 9],
                        60: [2, 9]
                    }, {
                        20: 25,
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        20: 36,
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        4: 37,
                        6: 3,
                        14: [2, 46],
                        15: [2, 46],
                        19: [2, 46],
                        29: [2, 46],
                        34: [2, 46],
                        39: [2, 46],
                        44: [2, 46],
                        47: [2, 46],
                        48: [2, 46],
                        51: [2, 46],
                        55: [2, 46],
                        60: [2, 46]
                    }, {
                        4: 38,
                        6: 3,
                        14: [2, 46],
                        15: [2, 46],
                        19: [2, 46],
                        29: [2, 46],
                        34: [2, 46],
                        44: [2, 46],
                        47: [2, 46],
                        48: [2, 46],
                        51: [2, 46],
                        55: [2, 46],
                        60: [2, 46]
                    }, {
                        15: [2, 48],
                        17: 39,
                        18: [2, 48]
                    }, {
                        20: 41,
                        56: 40,
                        64: 42,
                        65: [1, 43],
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        4: 44,
                        6: 3,
                        14: [2, 46],
                        15: [2, 46],
                        19: [2, 46],
                        29: [2, 46],
                        34: [2, 46],
                        47: [2, 46],
                        48: [2, 46],
                        51: [2, 46],
                        55: [2, 46],
                        60: [2, 46]
                    }, {
                        5: [2, 10],
                        14: [2, 10],
                        15: [2, 10],
                        18: [2, 10],
                        19: [2, 10],
                        29: [2, 10],
                        34: [2, 10],
                        39: [2, 10],
                        44: [2, 10],
                        47: [2, 10],
                        48: [2, 10],
                        51: [2, 10],
                        55: [2, 10],
                        60: [2, 10]
                    }, {
                        20: 45,
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        20: 46,
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        20: 47,
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        20: 41,
                        56: 48,
                        64: 42,
                        65: [1, 43],
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        33: [2, 78],
                        49: 49,
                        65: [2, 78],
                        72: [2, 78],
                        80: [2, 78],
                        81: [2, 78],
                        82: [2, 78],
                        83: [2, 78],
                        84: [2, 78],
                        85: [2, 78]
                    }, {
                        23: [2, 33],
                        33: [2, 33],
                        54: [2, 33],
                        65: [2, 33],
                        68: [2, 33],
                        72: [2, 33],
                        75: [2, 33],
                        80: [2, 33],
                        81: [2, 33],
                        82: [2, 33],
                        83: [2, 33],
                        84: [2, 33],
                        85: [2, 33]
                    }, {
                        23: [2, 34],
                        33: [2, 34],
                        54: [2, 34],
                        65: [2, 34],
                        68: [2, 34],
                        72: [2, 34],
                        75: [2, 34],
                        80: [2, 34],
                        81: [2, 34],
                        82: [2, 34],
                        83: [2, 34],
                        84: [2, 34],
                        85: [2, 34]
                    }, {
                        23: [2, 35],
                        33: [2, 35],
                        54: [2, 35],
                        65: [2, 35],
                        68: [2, 35],
                        72: [2, 35],
                        75: [2, 35],
                        80: [2, 35],
                        81: [2, 35],
                        82: [2, 35],
                        83: [2, 35],
                        84: [2, 35],
                        85: [2, 35]
                    }, {
                        23: [2, 36],
                        33: [2, 36],
                        54: [2, 36],
                        65: [2, 36],
                        68: [2, 36],
                        72: [2, 36],
                        75: [2, 36],
                        80: [2, 36],
                        81: [2, 36],
                        82: [2, 36],
                        83: [2, 36],
                        84: [2, 36],
                        85: [2, 36]
                    }, {
                        23: [2, 37],
                        33: [2, 37],
                        54: [2, 37],
                        65: [2, 37],
                        68: [2, 37],
                        72: [2, 37],
                        75: [2, 37],
                        80: [2, 37],
                        81: [2, 37],
                        82: [2, 37],
                        83: [2, 37],
                        84: [2, 37],
                        85: [2, 37]
                    }, {
                        23: [2, 38],
                        33: [2, 38],
                        54: [2, 38],
                        65: [2, 38],
                        68: [2, 38],
                        72: [2, 38],
                        75: [2, 38],
                        80: [2, 38],
                        81: [2, 38],
                        82: [2, 38],
                        83: [2, 38],
                        84: [2, 38],
                        85: [2, 38]
                    }, {
                        23: [2, 39],
                        33: [2, 39],
                        54: [2, 39],
                        65: [2, 39],
                        68: [2, 39],
                        72: [2, 39],
                        75: [2, 39],
                        80: [2, 39],
                        81: [2, 39],
                        82: [2, 39],
                        83: [2, 39],
                        84: [2, 39],
                        85: [2, 39]
                    }, {
                        23: [2, 43],
                        33: [2, 43],
                        54: [2, 43],
                        65: [2, 43],
                        68: [2, 43],
                        72: [2, 43],
                        75: [2, 43],
                        80: [2, 43],
                        81: [2, 43],
                        82: [2, 43],
                        83: [2, 43],
                        84: [2, 43],
                        85: [2, 43],
                        87: [1, 50]
                    }, {
                        72: [1, 35],
                        86: 51
                    }, {
                        23: [2, 45],
                        33: [2, 45],
                        54: [2, 45],
                        65: [2, 45],
                        68: [2, 45],
                        72: [2, 45],
                        75: [2, 45],
                        80: [2, 45],
                        81: [2, 45],
                        82: [2, 45],
                        83: [2, 45],
                        84: [2, 45],
                        85: [2, 45],
                        87: [2, 45]
                    }, {
                        52: 52,
                        54: [2, 82],
                        65: [2, 82],
                        72: [2, 82],
                        80: [2, 82],
                        81: [2, 82],
                        82: [2, 82],
                        83: [2, 82],
                        84: [2, 82],
                        85: [2, 82]
                    }, {
                        25: 53,
                        38: 55,
                        39: [1, 57],
                        43: 56,
                        44: [1, 58],
                        45: 54,
                        47: [2, 54]
                    }, {
                        28: 59,
                        43: 60,
                        44: [1, 58],
                        47: [2, 56]
                    }, {
                        13: 62,
                        15: [1, 20],
                        18: [1, 61]
                    }, {
                        33: [2, 86],
                        57: 63,
                        65: [2, 86],
                        72: [2, 86],
                        80: [2, 86],
                        81: [2, 86],
                        82: [2, 86],
                        83: [2, 86],
                        84: [2, 86],
                        85: [2, 86]
                    }, {
                        33: [2, 40],
                        65: [2, 40],
                        72: [2, 40],
                        80: [2, 40],
                        81: [2, 40],
                        82: [2, 40],
                        83: [2, 40],
                        84: [2, 40],
                        85: [2, 40]
                    }, {
                        33: [2, 41],
                        65: [2, 41],
                        72: [2, 41],
                        80: [2, 41],
                        81: [2, 41],
                        82: [2, 41],
                        83: [2, 41],
                        84: [2, 41],
                        85: [2, 41]
                    }, {
                        20: 64,
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        26: 65,
                        47: [1, 66]
                    }, {
                        30: 67,
                        33: [2, 58],
                        65: [2, 58],
                        72: [2, 58],
                        75: [2, 58],
                        80: [2, 58],
                        81: [2, 58],
                        82: [2, 58],
                        83: [2, 58],
                        84: [2, 58],
                        85: [2, 58]
                    }, {
                        33: [2, 64],
                        35: 68,
                        65: [2, 64],
                        72: [2, 64],
                        75: [2, 64],
                        80: [2, 64],
                        81: [2, 64],
                        82: [2, 64],
                        83: [2, 64],
                        84: [2, 64],
                        85: [2, 64]
                    }, {
                        21: 69,
                        23: [2, 50],
                        65: [2, 50],
                        72: [2, 50],
                        80: [2, 50],
                        81: [2, 50],
                        82: [2, 50],
                        83: [2, 50],
                        84: [2, 50],
                        85: [2, 50]
                    }, {
                        33: [2, 90],
                        61: 70,
                        65: [2, 90],
                        72: [2, 90],
                        80: [2, 90],
                        81: [2, 90],
                        82: [2, 90],
                        83: [2, 90],
                        84: [2, 90],
                        85: [2, 90]
                    }, {
                        20: 74,
                        33: [2, 80],
                        50: 71,
                        63: 72,
                        64: 75,
                        65: [1, 43],
                        69: 73,
                        70: 76,
                        71: 77,
                        72: [1, 78],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        72: [1, 79]
                    }, {
                        23: [2, 42],
                        33: [2, 42],
                        54: [2, 42],
                        65: [2, 42],
                        68: [2, 42],
                        72: [2, 42],
                        75: [2, 42],
                        80: [2, 42],
                        81: [2, 42],
                        82: [2, 42],
                        83: [2, 42],
                        84: [2, 42],
                        85: [2, 42],
                        87: [1, 50]
                    }, {
                        20: 74,
                        53: 80,
                        54: [2, 84],
                        63: 81,
                        64: 75,
                        65: [1, 43],
                        69: 82,
                        70: 76,
                        71: 77,
                        72: [1, 78],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        26: 83,
                        47: [1, 66]
                    }, {
                        47: [2, 55]
                    }, {
                        4: 84,
                        6: 3,
                        14: [2, 46],
                        15: [2, 46],
                        19: [2, 46],
                        29: [2, 46],
                        34: [2, 46],
                        39: [2, 46],
                        44: [2, 46],
                        47: [2, 46],
                        48: [2, 46],
                        51: [2, 46],
                        55: [2, 46],
                        60: [2, 46]
                    }, {
                        47: [2, 20]
                    }, {
                        20: 85,
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        4: 86,
                        6: 3,
                        14: [2, 46],
                        15: [2, 46],
                        19: [2, 46],
                        29: [2, 46],
                        34: [2, 46],
                        47: [2, 46],
                        48: [2, 46],
                        51: [2, 46],
                        55: [2, 46],
                        60: [2, 46]
                    }, {
                        26: 87,
                        47: [1, 66]
                    }, {
                        47: [2, 57]
                    }, {
                        5: [2, 11],
                        14: [2, 11],
                        15: [2, 11],
                        19: [2, 11],
                        29: [2, 11],
                        34: [2, 11],
                        39: [2, 11],
                        44: [2, 11],
                        47: [2, 11],
                        48: [2, 11],
                        51: [2, 11],
                        55: [2, 11],
                        60: [2, 11]
                    }, {
                        15: [2, 49],
                        18: [2, 49]
                    }, {
                        20: 74,
                        33: [2, 88],
                        58: 88,
                        63: 89,
                        64: 75,
                        65: [1, 43],
                        69: 90,
                        70: 76,
                        71: 77,
                        72: [1, 78],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        65: [2, 94],
                        66: 91,
                        68: [2, 94],
                        72: [2, 94],
                        80: [2, 94],
                        81: [2, 94],
                        82: [2, 94],
                        83: [2, 94],
                        84: [2, 94],
                        85: [2, 94]
                    }, {
                        5: [2, 25],
                        14: [2, 25],
                        15: [2, 25],
                        19: [2, 25],
                        29: [2, 25],
                        34: [2, 25],
                        39: [2, 25],
                        44: [2, 25],
                        47: [2, 25],
                        48: [2, 25],
                        51: [2, 25],
                        55: [2, 25],
                        60: [2, 25]
                    }, {
                        20: 92,
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        20: 74,
                        31: 93,
                        33: [2, 60],
                        63: 94,
                        64: 75,
                        65: [1, 43],
                        69: 95,
                        70: 76,
                        71: 77,
                        72: [1, 78],
                        75: [2, 60],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        20: 74,
                        33: [2, 66],
                        36: 96,
                        63: 97,
                        64: 75,
                        65: [1, 43],
                        69: 98,
                        70: 76,
                        71: 77,
                        72: [1, 78],
                        75: [2, 66],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        20: 74,
                        22: 99,
                        23: [2, 52],
                        63: 100,
                        64: 75,
                        65: [1, 43],
                        69: 101,
                        70: 76,
                        71: 77,
                        72: [1, 78],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        20: 74,
                        33: [2, 92],
                        62: 102,
                        63: 103,
                        64: 75,
                        65: [1, 43],
                        69: 104,
                        70: 76,
                        71: 77,
                        72: [1, 78],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        33: [1, 105]
                    }, {
                        33: [2, 79],
                        65: [2, 79],
                        72: [2, 79],
                        80: [2, 79],
                        81: [2, 79],
                        82: [2, 79],
                        83: [2, 79],
                        84: [2, 79],
                        85: [2, 79]
                    }, {
                        33: [2, 81]
                    }, {
                        23: [2, 27],
                        33: [2, 27],
                        54: [2, 27],
                        65: [2, 27],
                        68: [2, 27],
                        72: [2, 27],
                        75: [2, 27],
                        80: [2, 27],
                        81: [2, 27],
                        82: [2, 27],
                        83: [2, 27],
                        84: [2, 27],
                        85: [2, 27]
                    }, {
                        23: [2, 28],
                        33: [2, 28],
                        54: [2, 28],
                        65: [2, 28],
                        68: [2, 28],
                        72: [2, 28],
                        75: [2, 28],
                        80: [2, 28],
                        81: [2, 28],
                        82: [2, 28],
                        83: [2, 28],
                        84: [2, 28],
                        85: [2, 28]
                    }, {
                        23: [2, 30],
                        33: [2, 30],
                        54: [2, 30],
                        68: [2, 30],
                        71: 106,
                        72: [1, 107],
                        75: [2, 30]
                    }, {
                        23: [2, 98],
                        33: [2, 98],
                        54: [2, 98],
                        68: [2, 98],
                        72: [2, 98],
                        75: [2, 98]
                    }, {
                        23: [2, 45],
                        33: [2, 45],
                        54: [2, 45],
                        65: [2, 45],
                        68: [2, 45],
                        72: [2, 45],
                        73: [1, 108],
                        75: [2, 45],
                        80: [2, 45],
                        81: [2, 45],
                        82: [2, 45],
                        83: [2, 45],
                        84: [2, 45],
                        85: [2, 45],
                        87: [2, 45]
                    }, {
                        23: [2, 44],
                        33: [2, 44],
                        54: [2, 44],
                        65: [2, 44],
                        68: [2, 44],
                        72: [2, 44],
                        75: [2, 44],
                        80: [2, 44],
                        81: [2, 44],
                        82: [2, 44],
                        83: [2, 44],
                        84: [2, 44],
                        85: [2, 44],
                        87: [2, 44]
                    }, {
                        54: [1, 109]
                    }, {
                        54: [2, 83],
                        65: [2, 83],
                        72: [2, 83],
                        80: [2, 83],
                        81: [2, 83],
                        82: [2, 83],
                        83: [2, 83],
                        84: [2, 83],
                        85: [2, 83]
                    }, {
                        54: [2, 85]
                    }, {
                        5: [2, 13],
                        14: [2, 13],
                        15: [2, 13],
                        19: [2, 13],
                        29: [2, 13],
                        34: [2, 13],
                        39: [2, 13],
                        44: [2, 13],
                        47: [2, 13],
                        48: [2, 13],
                        51: [2, 13],
                        55: [2, 13],
                        60: [2, 13]
                    }, {
                        38: 55,
                        39: [1, 57],
                        43: 56,
                        44: [1, 58],
                        45: 111,
                        46: 110,
                        47: [2, 76]
                    }, {
                        33: [2, 70],
                        40: 112,
                        65: [2, 70],
                        72: [2, 70],
                        75: [2, 70],
                        80: [2, 70],
                        81: [2, 70],
                        82: [2, 70],
                        83: [2, 70],
                        84: [2, 70],
                        85: [2, 70]
                    }, {
                        47: [2, 18]
                    }, {
                        5: [2, 14],
                        14: [2, 14],
                        15: [2, 14],
                        19: [2, 14],
                        29: [2, 14],
                        34: [2, 14],
                        39: [2, 14],
                        44: [2, 14],
                        47: [2, 14],
                        48: [2, 14],
                        51: [2, 14],
                        55: [2, 14],
                        60: [2, 14]
                    }, {
                        33: [1, 113]
                    }, {
                        33: [2, 87],
                        65: [2, 87],
                        72: [2, 87],
                        80: [2, 87],
                        81: [2, 87],
                        82: [2, 87],
                        83: [2, 87],
                        84: [2, 87],
                        85: [2, 87]
                    }, {
                        33: [2, 89]
                    }, {
                        20: 74,
                        63: 115,
                        64: 75,
                        65: [1, 43],
                        67: 114,
                        68: [2, 96],
                        69: 116,
                        70: 76,
                        71: 77,
                        72: [1, 78],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        33: [1, 117]
                    }, {
                        32: 118,
                        33: [2, 62],
                        74: 119,
                        75: [1, 120]
                    }, {
                        33: [2, 59],
                        65: [2, 59],
                        72: [2, 59],
                        75: [2, 59],
                        80: [2, 59],
                        81: [2, 59],
                        82: [2, 59],
                        83: [2, 59],
                        84: [2, 59],
                        85: [2, 59]
                    }, {
                        33: [2, 61],
                        75: [2, 61]
                    }, {
                        33: [2, 68],
                        37: 121,
                        74: 122,
                        75: [1, 120]
                    }, {
                        33: [2, 65],
                        65: [2, 65],
                        72: [2, 65],
                        75: [2, 65],
                        80: [2, 65],
                        81: [2, 65],
                        82: [2, 65],
                        83: [2, 65],
                        84: [2, 65],
                        85: [2, 65]
                    }, {
                        33: [2, 67],
                        75: [2, 67]
                    }, {
                        23: [1, 123]
                    }, {
                        23: [2, 51],
                        65: [2, 51],
                        72: [2, 51],
                        80: [2, 51],
                        81: [2, 51],
                        82: [2, 51],
                        83: [2, 51],
                        84: [2, 51],
                        85: [2, 51]
                    }, {
                        23: [2, 53]
                    }, {
                        33: [1, 124]
                    }, {
                        33: [2, 91],
                        65: [2, 91],
                        72: [2, 91],
                        80: [2, 91],
                        81: [2, 91],
                        82: [2, 91],
                        83: [2, 91],
                        84: [2, 91],
                        85: [2, 91]
                    }, {
                        33: [2, 93]
                    }, {
                        5: [2, 22],
                        14: [2, 22],
                        15: [2, 22],
                        19: [2, 22],
                        29: [2, 22],
                        34: [2, 22],
                        39: [2, 22],
                        44: [2, 22],
                        47: [2, 22],
                        48: [2, 22],
                        51: [2, 22],
                        55: [2, 22],
                        60: [2, 22]
                    }, {
                        23: [2, 99],
                        33: [2, 99],
                        54: [2, 99],
                        68: [2, 99],
                        72: [2, 99],
                        75: [2, 99]
                    }, {
                        73: [1, 108]
                    }, {
                        20: 74,
                        63: 125,
                        64: 75,
                        65: [1, 43],
                        72: [1, 35],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        5: [2, 23],
                        14: [2, 23],
                        15: [2, 23],
                        19: [2, 23],
                        29: [2, 23],
                        34: [2, 23],
                        39: [2, 23],
                        44: [2, 23],
                        47: [2, 23],
                        48: [2, 23],
                        51: [2, 23],
                        55: [2, 23],
                        60: [2, 23]
                    }, {
                        47: [2, 19]
                    }, {
                        47: [2, 77]
                    }, {
                        20: 74,
                        33: [2, 72],
                        41: 126,
                        63: 127,
                        64: 75,
                        65: [1, 43],
                        69: 128,
                        70: 76,
                        71: 77,
                        72: [1, 78],
                        75: [2, 72],
                        78: 26,
                        79: 27,
                        80: [1, 28],
                        81: [1, 29],
                        82: [1, 30],
                        83: [1, 31],
                        84: [1, 32],
                        85: [1, 34],
                        86: 33
                    }, {
                        5: [2, 24],
                        14: [2, 24],
                        15: [2, 24],
                        19: [2, 24],
                        29: [2, 24],
                        34: [2, 24],
                        39: [2, 24],
                        44: [2, 24],
                        47: [2, 24],
                        48: [2, 24],
                        51: [2, 24],
                        55: [2, 24],
                        60: [2, 24]
                    }, {
                        68: [1, 129]
                    }, {
                        65: [2, 95],
                        68: [2, 95],
                        72: [2, 95],
                        80: [2, 95],
                        81: [2, 95],
                        82: [2, 95],
                        83: [2, 95],
                        84: [2, 95],
                        85: [2, 95]
                    }, {
                        68: [2, 97]
                    }, {
                        5: [2, 21],
                        14: [2, 21],
                        15: [2, 21],
                        19: [2, 21],
                        29: [2, 21],
                        34: [2, 21],
                        39: [2, 21],
                        44: [2, 21],
                        47: [2, 21],
                        48: [2, 21],
                        51: [2, 21],
                        55: [2, 21],
                        60: [2, 21]
                    }, {
                        33: [1, 130]
                    }, {
                        33: [2, 63]
                    }, {
                        72: [1, 132],
                        76: 131
                    }, {
                        33: [1, 133]
                    }, {
                        33: [2, 69]
                    }, {
                        15: [2, 12],
                        18: [2, 12]
                    }, {
                        14: [2, 26],
                        15: [2, 26],
                        19: [2, 26],
                        29: [2, 26],
                        34: [2, 26],
                        47: [2, 26],
                        48: [2, 26],
                        51: [2, 26],
                        55: [2, 26],
                        60: [2, 26]
                    }, {
                        23: [2, 31],
                        33: [2, 31],
                        54: [2, 31],
                        68: [2, 31],
                        72: [2, 31],
                        75: [2, 31]
                    }, {
                        33: [2, 74],
                        42: 134,
                        74: 135,
                        75: [1, 120]
                    }, {
                        33: [2, 71],
                        65: [2, 71],
                        72: [2, 71],
                        75: [2, 71],
                        80: [2, 71],
                        81: [2, 71],
                        82: [2, 71],
                        83: [2, 71],
                        84: [2, 71],
                        85: [2, 71]
                    }, {
                        33: [2, 73],
                        75: [2, 73]
                    }, {
                        23: [2, 29],
                        33: [2, 29],
                        54: [2, 29],
                        65: [2, 29],
                        68: [2, 29],
                        72: [2, 29],
                        75: [2, 29],
                        80: [2, 29],
                        81: [2, 29],
                        82: [2, 29],
                        83: [2, 29],
                        84: [2, 29],
                        85: [2, 29]
                    }, {
                        14: [2, 15],
                        15: [2, 15],
                        19: [2, 15],
                        29: [2, 15],
                        34: [2, 15],
                        39: [2, 15],
                        44: [2, 15],
                        47: [2, 15],
                        48: [2, 15],
                        51: [2, 15],
                        55: [2, 15],
                        60: [2, 15]
                    }, {
                        72: [1, 137],
                        77: [1, 136]
                    }, {
                        72: [2, 100],
                        77: [2, 100]
                    }, {
                        14: [2, 16],
                        15: [2, 16],
                        19: [2, 16],
                        29: [2, 16],
                        34: [2, 16],
                        44: [2, 16],
                        47: [2, 16],
                        48: [2, 16],
                        51: [2, 16],
                        55: [2, 16],
                        60: [2, 16]
                    }, {
                        33: [1, 138]
                    }, {
                        33: [2, 75]
                    }, {
                        33: [2, 32]
                    }, {
                        72: [2, 101],
                        77: [2, 101]
                    }, {
                        14: [2, 17],
                        15: [2, 17],
                        19: [2, 17],
                        29: [2, 17],
                        34: [2, 17],
                        39: [2, 17],
                        44: [2, 17],
                        47: [2, 17],
                        48: [2, 17],
                        51: [2, 17],
                        55: [2, 17],
                        60: [2, 17]
                    }],
                    defaultActions: {
                        4: [2, 1],
                        54: [2, 55],
                        56: [2, 20],
                        60: [2, 57],
                        73: [2, 81],
                        82: [2, 85],
                        86: [2, 18],
                        90: [2, 89],
                        101: [2, 53],
                        104: [2, 93],
                        110: [2, 19],
                        111: [2, 77],
                        116: [2, 97],
                        119: [2, 63],
                        122: [2, 69],
                        135: [2, 75],
                        136: [2, 32]
                    },
                    parseError: function(a, b) {
                        throw new Error(a)
                    },
                    parse: function(a) {
                        function b() {
                            var a;
                            return a = c.lexer.lex() || 1, "number" != typeof a && (a = c.symbols_[a] || a), a
                        }
                        var c = this,
                            d = [0],
                            e = [null],
                            f = [],
                            g = this.table,
                            h = "",
                            i = 0,
                            j = 0,
                            k = 0;
                        this.lexer.setInput(a), this.lexer.yy = this.yy, this.yy.lexer = this.lexer, this.yy.parser = this, "undefined" == typeof this.lexer.yylloc && (this.lexer.yylloc = {});
                        var l = this.lexer.yylloc;
                        f.push(l);
                        var m = this.lexer.options && this.lexer.options.ranges;
                        "function" == typeof this.yy.parseError && (this.parseError = this.yy.parseError);
                        for (var n, o, p, q, r, s, t, u, v, w = {};;) {
                            if (p = d[d.length - 1], this.defaultActions[p] ? q = this.defaultActions[p] : (null !== n && "undefined" != typeof n || (n = b()), q = g[p] && g[p][n]), "undefined" == typeof q || !q.length || !q[0]) {
                                var x = "";
                                if (!k) {
                                    v = [];
                                    for (s in g[p]) this.terminals_[s] && s > 2 && v.push("'" + this.terminals_[s] + "'");
                                    x = this.lexer.showPosition ? "Parse error on line " + (i + 1) + ":\n" + this.lexer.showPosition() + "\nExpecting " + v.join(", ") + ", got '" + (this.terminals_[n] || n) + "'" : "Parse error on line " + (i + 1) + ": Unexpected " + (1 == n ? "end of input" : "'" + (this.terminals_[n] || n) + "'"), this.parseError(x, {
                                        text: this.lexer.match,
                                        token: this.terminals_[n] || n,
                                        line: this.lexer.yylineno,
                                        loc: l,
                                        expected: v
                                    })
                                }
                            }
                            if (q[0] instanceof Array && q.length > 1) throw new Error("Parse Error: multiple actions possible at state: " + p + ", token: " + n);
                            switch (q[0]) {
                                case 1:
                                    d.push(n), e.push(this.lexer.yytext), f.push(this.lexer.yylloc), d.push(q[1]), n = null, o ? (n = o, o = null) : (j = this.lexer.yyleng, h = this.lexer.yytext, i = this.lexer.yylineno, l = this.lexer.yylloc, k > 0 && k--);
                                    break;
                                case 2:
                                    if (t = this.productions_[q[1]][1], w.$ = e[e.length - t], w._$ = {
                                            first_line: f[f.length - (t || 1)].first_line,
                                            last_line: f[f.length - 1].last_line,
                                            first_column: f[f.length - (t || 1)].first_column,
                                            last_column: f[f.length - 1].last_column
                                        }, m && (w._$.range = [f[f.length - (t || 1)].range[0], f[f.length - 1].range[1]]), r = this.performAction.call(w, h, j, i, this.yy, q[1], e, f), "undefined" != typeof r) return r;
                                    t && (d = d.slice(0, -1 * t * 2), e = e.slice(0, -1 * t), f = f.slice(0, -1 * t)), d.push(this.productions_[q[1]][0]), e.push(w.$), f.push(w._$), u = g[d[d.length - 2]][d[d.length - 1]], d.push(u);
                                    break;
                                case 3:
                                    return !0
                            }
                        }
                        return !0
                    }
                },
                c = function() {
                    var a = {
                        EOF: 1,
                        parseError: function(a, b) {
                            if (!this.yy.parser) throw new Error(a);
                            this.yy.parser.parseError(a, b)
                        },
                        setInput: function(a) {
                            return this._input = a, this._more = this._less = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
                                first_line: 1,
                                first_column: 0,
                                last_line: 1,
                                last_column: 0
                            }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this
                        },
                        input: function() {
                            var a = this._input[0];
                            this.yytext += a, this.yyleng++, this.offset++, this.match += a, this.matched += a;
                            var b = a.match(/(?:\r\n?|\n).*/g);
                            return b ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), a
                        },
                        unput: function(a) {
                            var b = a.length,
                                c = a.split(/(?:\r\n?|\n)/g);
                            this._input = a + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - b - 1), this.offset -= b;
                            var d = this.match.split(/(?:\r\n?|\n)/g);
                            this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), c.length - 1 && (this.yylineno -= c.length - 1);
                            var e = this.yylloc.range;
                            return this.yylloc = {
                                first_line: this.yylloc.first_line,
                                last_line: this.yylineno + 1,
                                first_column: this.yylloc.first_column,
                                last_column: c ? (c.length === d.length ? this.yylloc.first_column : 0) + d[d.length - c.length].length - c[0].length : this.yylloc.first_column - b
                            }, this.options.ranges && (this.yylloc.range = [e[0], e[0] + this.yyleng - b]), this
                        },
                        more: function() {
                            return this._more = !0, this
                        },
                        less: function(a) {
                            this.unput(this.match.slice(a))
                        },
                        pastInput: function() {
                            var a = this.matched.substr(0, this.matched.length - this.match.length);
                            return (a.length > 20 ? "..." : "") + a.substr(-20).replace(/\n/g, "")
                        },
                        upcomingInput: function() {
                            var a = this.match;
                            return a.length < 20 && (a += this._input.substr(0, 20 - a.length)), (a.substr(0, 20) + (a.length > 20 ? "..." : "")).replace(/\n/g, "")
                        },
                        showPosition: function() {
                            var a = this.pastInput(),
                                b = new Array(a.length + 1).join("-");
                            return a + this.upcomingInput() + "\n" + b + "^"
                        },
                        next: function() {
                            if (this.done) return this.EOF;
                            this._input || (this.done = !0);
                            var a, b, c, d, e;
                            this._more || (this.yytext = "", this.match = "");
                            for (var f = this._currentRules(), g = 0; g < f.length && (c = this._input.match(this.rules[f[g]]), !c || b && !(c[0].length > b[0].length) || (b = c, d = g, this.options.flex)); g++);
                            return b ? (e = b[0].match(/(?:\r\n?|\n).*/g), e && (this.yylineno += e.length), this.yylloc = {
                                first_line: this.yylloc.last_line,
                                last_line: this.yylineno + 1,
                                first_column: this.yylloc.last_column,
                                last_column: e ? e[e.length - 1].length - e[e.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + b[0].length
                            }, this.yytext += b[0], this.match += b[0], this.matches = b, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._input = this._input.slice(b[0].length), this.matched += b[0], a = this.performAction.call(this, this.yy, this, f[d], this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), a ? a : void 0) : "" === this._input ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
                                text: "",
                                token: null,
                                line: this.yylineno
                            })
                        },
                        lex: function() {
                            var a = this.next();
                            return "undefined" != typeof a ? a : this.lex()
                        },
                        begin: function(a) {
                            this.conditionStack.push(a)
                        },
                        popState: function() {
                            return this.conditionStack.pop()
                        },
                        _currentRules: function() {
                            return this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules
                        },
                        topState: function() {
                            return this.conditionStack[this.conditionStack.length - 2]
                        },
                        pushState: function(a) {
                            this.begin(a)
                        }
                    };
                    return a.options = {}, a.performAction = function(a, b, c, d) {
                        function e(a, c) {
                            return b.yytext = b.yytext.substring(a, b.yyleng - c + a)
                        }
                        switch (c) {
                            case 0:
                                if ("\\\\" === b.yytext.slice(-2) ? (e(0, 1), this.begin("mu")) : "\\" === b.yytext.slice(-1) ? (e(0, 1), this.begin("emu")) : this.begin("mu"), b.yytext) return 15;
                                break;
                            case 1:
                                return 15;
                            case 2:
                                return this.popState(), 15;
                            case 3:
                                return this.begin("raw"), 15;
                            case 4:
                                return this.popState(), "raw" === this.conditionStack[this.conditionStack.length - 1] ? 15 : (e(5, 9), "END_RAW_BLOCK");
                            case 5:
                                return 15;
                            case 6:
                                return this.popState(), 14;
                            case 7:
                                return 65;
                            case 8:
                                return 68;
                            case 9:
                                return 19;
                            case 10:
                                return this.popState(), this.begin("raw"), 23;
                            case 11:
                                return 55;
                            case 12:
                                return 60;
                            case 13:
                                return 29;
                            case 14:
                                return 47;
                            case 15:
                                return this.popState(), 44;
                            case 16:
                                return this.popState(), 44;
                            case 17:
                                return 34;
                            case 18:
                                return 39;
                            case 19:
                                return 51;
                            case 20:
                                return 48;
                            case 21:
                                this.unput(b.yytext), this.popState(), this.begin("com");
                                break;
                            case 22:
                                return this.popState(), 14;
                            case 23:
                                return 48;
                            case 24:
                                return 73;
                            case 25:
                                return 72;
                            case 26:
                                return 72;
                            case 27:
                                return 87;
                            case 28:
                                break;
                            case 29:
                                return this.popState(), 54;
                            case 30:
                                return this.popState(), 33;
                            case 31:
                                return b.yytext = e(1, 2).replace(/\\"/g, '"'), 80;
                            case 32:
                                return b.yytext = e(1, 2).replace(/\\'/g, "'"), 80;
                            case 33:
                                return 85;
                            case 34:
                                return 82;
                            case 35:
                                return 82;
                            case 36:
                                return 83;
                            case 37:
                                return 84;
                            case 38:
                                return 81;
                            case 39:
                                return 75;
                            case 40:
                                return 77;
                            case 41:
                                return 72;
                            case 42:
                                return b.yytext = b.yytext.replace(/\\([\\\]])/g, "$1"), 72;
                            case 43:
                                return "INVALID";
                            case 44:
                                return 5
                        }
                    }, a.rules = [/^(?:[^\x00]*?(?=(\{\{)))/, /^(?:[^\x00]+)/, /^(?:[^\x00]{2,}?(?=(\{\{|\\\{\{|\\\\\{\{|$)))/, /^(?:\{\{\{\{(?=[^/]))/, /^(?:\{\{\{\{\/[^\s!"#%-,\.\/;->@\[-\^`\{-~]+(?=[=}\s\/.])\}\}\}\})/, /^(?:[^\x00]+?(?=(\{\{\{\{)))/, /^(?:[\s\S]*?--(~)?\}\})/, /^(?:\()/, /^(?:\))/, /^(?:\{\{\{\{)/, /^(?:\}\}\}\})/, /^(?:\{\{(~)?>)/, /^(?:\{\{(~)?#>)/, /^(?:\{\{(~)?#\*?)/, /^(?:\{\{(~)?\/)/, /^(?:\{\{(~)?\^\s*(~)?\}\})/, /^(?:\{\{(~)?\s*else\s*(~)?\}\})/, /^(?:\{\{(~)?\^)/, /^(?:\{\{(~)?\s*else\b)/, /^(?:\{\{(~)?\{)/, /^(?:\{\{(~)?&)/, /^(?:\{\{(~)?!--)/, /^(?:\{\{(~)?![\s\S]*?\}\})/, /^(?:\{\{(~)?\*?)/, /^(?:=)/, /^(?:\.\.)/, /^(?:\.(?=([=~}\s\/.)|])))/, /^(?:[\/.])/, /^(?:\s+)/, /^(?:\}(~)?\}\})/, /^(?:(~)?\}\})/, /^(?:"(\\["]|[^"])*")/, /^(?:'(\\[']|[^'])*')/, /^(?:@)/, /^(?:true(?=([~}\s)])))/, /^(?:false(?=([~}\s)])))/, /^(?:undefined(?=([~}\s)])))/, /^(?:null(?=([~}\s)])))/, /^(?:-?[0-9]+(?:\.[0-9]+)?(?=([~}\s)])))/, /^(?:as\s+\|)/, /^(?:\|)/, /^(?:([^\s!"#%-,\.\/;->@\[-\^`\{-~]+(?=([=~}\s\/.)|]))))/, /^(?:\[(\\\]|[^\]])*\])/, /^(?:.)/, /^(?:$)/], a.conditions = {
                        mu: {
                            rules: [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44],
                            inclusive: !1
                        },
                        emu: {
                            rules: [2],
                            inclusive: !1
                        },
                        com: {
                            rules: [6],
                            inclusive: !1
                        },
                        raw: {
                            rules: [3, 4, 5],
                            inclusive: !1
                        },
                        INITIAL: {
                            rules: [0, 1, 44],
                            inclusive: !0
                        }
                    }, a
                }();
            return b.lexer = c, a.prototype = b, b.Parser = a, new a
        }();
        b["default"] = c, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";

        function d() {
            var a = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0];
            this.options = a
        }

        function e(a, b, c) {
            void 0 === b && (b = a.length);
            var d = a[b - 1],
                e = a[b - 2];
            return d ? "ContentStatement" === d.type ? (e || !c ? /\r?\n\s*?$/ : /(^|\r?\n)\s*?$/).test(d.original) : void 0 : c
        }

        function f(a, b, c) {
            void 0 === b && (b = -1);
            var d = a[b + 1],
                e = a[b + 2];
            return d ? "ContentStatement" === d.type ? (e || !c ? /^\s*?\r?\n/ : /^\s*?(\r?\n|$)/).test(d.original) : void 0 : c
        }

        function g(a, b, c) {
            var d = a[null == b ? 0 : b + 1];
            if (d && "ContentStatement" === d.type && (c || !d.rightStripped)) {
                var e = d.value;
                d.value = d.value.replace(c ? /^\s+/ : /^[ \t]*\r?\n?/, ""), d.rightStripped = d.value !== e
            }
        }

        function h(a, b, c) {
            var d = a[null == b ? a.length - 1 : b - 1];
            if (d && "ContentStatement" === d.type && (c || !d.leftStripped)) {
                var e = d.value;
                return d.value = d.value.replace(c ? /\s+$/ : /[ \t]+$/, ""), d.leftStripped = d.value !== e, d.leftStripped
            }
        }
        var i = c(1)["default"];
        b.__esModule = !0;
        var j = c(88),
            k = i(j);
        d.prototype = new k["default"], d.prototype.Program = function(a) {
            var b = !this.options.ignoreStandalone,
                c = !this.isRootSeen;
            this.isRootSeen = !0;
            for (var d = a.body, i = 0, j = d.length; i < j; i++) {
                var k = d[i],
                    l = this.accept(k);
                if (l) {
                    var m = e(d, i, c),
                        n = f(d, i, c),
                        o = l.openStandalone && m,
                        p = l.closeStandalone && n,
                        q = l.inlineStandalone && m && n;
                    l.close && g(d, i, !0), l.open && h(d, i, !0), b && q && (g(d, i), h(d, i) && "PartialStatement" === k.type && (k.indent = /([ \t]+$)/.exec(d[i - 1].original)[1])), b && o && (g((k.program || k.inverse).body), h(d, i)), b && p && (g(d, i), h((k.inverse || k.program).body))
                }
            }
            return a
        }, d.prototype.BlockStatement = d.prototype.DecoratorBlock = d.prototype.PartialBlockStatement = function(a) {
            this.accept(a.program), this.accept(a.inverse);
            var b = a.program || a.inverse,
                c = a.program && a.inverse,
                d = c,
                i = c;
            if (c && c.chained)
                for (d = c.body[0].program; i.chained;) i = i.body[i.body.length - 1].program;
            var j = {
                open: a.openStrip.open,
                close: a.closeStrip.close,
                openStandalone: f(b.body),
                closeStandalone: e((d || b).body)
            };
            if (a.openStrip.close && g(b.body, null, !0), c) {
                var k = a.inverseStrip;
                k.open && h(b.body, null, !0), k.close && g(d.body, null, !0), a.closeStrip.open && h(i.body, null, !0), !this.options.ignoreStandalone && e(b.body) && f(d.body) && (h(b.body), g(d.body))
            } else a.closeStrip.open && h(b.body, null, !0);
            return j
        }, d.prototype.Decorator = d.prototype.MustacheStatement = function(a) {
            return a.strip
        }, d.prototype.PartialStatement = d.prototype.CommentStatement = function(a) {
            var b = a.strip || {};
            return {
                inlineStandalone: !0,
                open: b.open,
                close: b.close
            }
        }, b["default"] = d, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";

        function d() {
            this.parents = []
        }

        function e(a) {
            this.acceptRequired(a, "path"), this.acceptArray(a.params), this.acceptKey(a, "hash")
        }

        function f(a) {
            e.call(this, a), this.acceptKey(a, "program"), this.acceptKey(a, "inverse")
        }

        function g(a) {
            this.acceptRequired(a, "name"), this.acceptArray(a.params), this.acceptKey(a, "hash")
        }
        var h = c(1)["default"];
        b.__esModule = !0;
        var i = c(6),
            j = h(i);
        d.prototype = {
            constructor: d,
            mutating: !1,
            acceptKey: function(a, b) {
                var c = this.accept(a[b]);
                if (this.mutating) {
                    if (c && !d.prototype[c.type]) throw new j["default"]('Unexpected node type "' + c.type + '" found when accepting ' + b + " on " + a.type);
                    a[b] = c
                }
            },
            acceptRequired: function(a, b) {
                if (this.acceptKey(a, b), !a[b]) throw new j["default"](a.type + " requires " + b)
            },
            acceptArray: function(a) {
                for (var b = 0, c = a.length; b < c; b++) this.acceptKey(a, b), a[b] || (a.splice(b, 1), b--, c--)
            },
            accept: function(a) {
                if (a) {
                    if (!this[a.type]) throw new j["default"]("Unknown type: " + a.type, a);
                    this.current && this.parents.unshift(this.current), this.current = a;
                    var b = this[a.type](a);
                    return this.current = this.parents.shift(), !this.mutating || b ? b : b !== !1 ? a : void 0
                }
            },
            Program: function(a) {
                this.acceptArray(a.body)
            },
            MustacheStatement: e,
            Decorator: e,
            BlockStatement: f,
            DecoratorBlock: f,
            PartialStatement: g,
            PartialBlockStatement: function(a) {
                g.call(this, a), this.acceptKey(a, "program")
            },
            ContentStatement: function() {},
            CommentStatement: function() {},
            SubExpression: e,
            PathExpression: function() {},
            StringLiteral: function() {},
            NumberLiteral: function() {},
            BooleanLiteral: function() {},
            UndefinedLiteral: function() {},
            NullLiteral: function() {},
            Hash: function(a) {
                this.acceptArray(a.pairs)
            },
            HashPair: function(a) {
                this.acceptRequired(a, "value")
            }
        }, b["default"] = d, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";

        function d(a, b) {
            if (b = b.path ? b.path.original : b, a.path.original !== b) {
                var c = {
                    loc: a.path.loc
                };
                throw new q["default"](a.path.original + " doesn't match " + b, c)
            }
        }

        function e(a, b) {
            this.source = a, this.start = {
                line: b.first_line,
                column: b.first_column
            }, this.end = {
                line: b.last_line,
                column: b.last_column
            }
        }

        function f(a) {
            return /^\[.*\]$/.test(a) ? a.substring(1, a.length - 1) : a
        }

        function g(a, b) {
            return {
                open: "~" === a.charAt(2),
                close: "~" === b.charAt(b.length - 3)
            }
        }

        function h(a) {
            return a.replace(/^\{\{~?!-?-?/, "").replace(/-?-?~?\}\}$/, "")
        }

        function i(a, b, c) {
            c = this.locInfo(c);
            for (var d = a ? "@" : "", e = [], f = 0, g = 0, h = b.length; g < h; g++) {
                var i = b[g].part,
                    j = b[g].original !== i;
                if (d += (b[g].separator || "") + i, j || ".." !== i && "." !== i && "this" !== i) e.push(i);
                else {
                    if (e.length > 0) throw new q["default"]("Invalid path: " + d, {
                        loc: c
                    });
                    ".." === i && f++
                }
            }
            return {
                type: "PathExpression",
                data: a,
                depth: f,
                parts: e,
                original: d,
                loc: c
            }
        }

        function j(a, b, c, d, e, f) {
            var g = d.charAt(3) || d.charAt(2),
                h = "{" !== g && "&" !== g,
                i = /\*/.test(d);
            return {
                type: i ? "Decorator" : "MustacheStatement",
                path: a,
                params: b,
                hash: c,
                escaped: h,
                strip: e,
                loc: this.locInfo(f)
            }
        }

        function k(a, b, c, e) {
            d(a, c), e = this.locInfo(e);
            var f = {
                type: "Program",
                body: b,
                strip: {},
                loc: e
            };
            return {
                type: "BlockStatement",
                path: a.path,
                params: a.params,
                hash: a.hash,
                program: f,
                openStrip: {},
                inverseStrip: {},
                closeStrip: {},
                loc: e
            }
        }

        function l(a, b, c, e, f, g) {
            e && e.path && d(a, e);
            var h = /\*/.test(a.open);
            b.blockParams = a.blockParams;
            var i = void 0,
                j = void 0;
            if (c) {
                if (h) throw new q["default"]("Unexpected inverse block on decorator", c);
                c.chain && (c.program.body[0].closeStrip = e.strip), j = c.strip, i = c.program
            }
            return f && (f = i, i = b, b = f), {
                type: h ? "DecoratorBlock" : "BlockStatement",
                path: a.path,
                params: a.params,
                hash: a.hash,
                program: b,
                inverse: i,
                openStrip: a.strip,
                inverseStrip: j,
                closeStrip: e && e.strip,
                loc: this.locInfo(g)
            }
        }

        function m(a, b) {
            if (!b && a.length) {
                var c = a[0].loc,
                    d = a[a.length - 1].loc;
                c && d && (b = {
                    source: c.source,
                    start: {
                        line: c.start.line,
                        column: c.start.column
                    },
                    end: {
                        line: d.end.line,
                        column: d.end.column
                    }
                })
            }
            return {
                type: "Program",
                body: a,
                strip: {},
                loc: b
            }
        }

        function n(a, b, c, e) {
            return d(a, c), {
                type: "PartialBlockStatement",
                name: a.path,
                params: a.params,
                hash: a.hash,
                program: b,
                openStrip: a.strip,
                closeStrip: c && c.strip,
                loc: this.locInfo(e)
            }
        }
        var o = c(1)["default"];
        b.__esModule = !0, b.SourceLocation = e, b.id = f, b.stripFlags = g, b.stripComment = h, b.preparePath = i, b.prepareMustache = j, b.prepareRawBlock = k, b.prepareBlock = l, b.prepareProgram = m, b.preparePartialBlock = n;
        var p = c(6),
            q = o(p)
    }, function(a, b, c) {
        "use strict";

        function d() {}

        function e(a, b, c) {
            if (null == a || "string" != typeof a && "Program" !== a.type) throw new l["default"]("You must pass a string or Handlebars AST to Handlebars.precompile. You passed " + a);
            b = b || {}, "data" in b || (b.data = !0), b.compat && (b.useDepths = !0);
            var d = c.parse(a, b),
                e = (new c.Compiler).compile(d, b);
            return (new c.JavaScriptCompiler).compile(e, b)
        }

        function f(a, b, c) {
            function d() {
                var d = c.parse(a, b),
                    e = (new c.Compiler).compile(d, b),
                    f = (new c.JavaScriptCompiler).compile(e, b, void 0, !0);
                return c.template(f)
            }

            function e(a, b) {
                return f || (f = d()), f.call(this, a, b)
            }
            if (void 0 === b && (b = {}), null == a || "string" != typeof a && "Program" !== a.type) throw new l["default"]("You must pass a string or Handlebars AST to Handlebars.compile. You passed " + a);
            b = m.extend({}, b), "data" in b || (b.data = !0), b.compat && (b.useDepths = !0);
            var f = void 0;
            return e._setup = function(a) {
                return f || (f = d()), f._setup(a)
            }, e._child = function(a, b, c, e) {
                return f || (f = d()), f._child(a, b, c, e)
            }, e
        }

        function g(a, b) {
            if (a === b) return !0;
            if (m.isArray(a) && m.isArray(b) && a.length === b.length) {
                for (var c = 0; c < a.length; c++)
                    if (!g(a[c], b[c])) return !1;
                return !0
            }
        }

        function h(a) {
            if (!a.path.parts) {
                var b = a.path;
                a.path = {
                    type: "PathExpression",
                    data: !1,
                    depth: 0,
                    parts: [b.original + ""],
                    original: b.original + "",
                    loc: b.loc
                }
            }
        }
        var i = c(74)["default"],
            j = c(1)["default"];
        b.__esModule = !0, b.Compiler = d, b.precompile = e, b.compile = f;
        var k = c(6),
            l = j(k),
            m = c(5),
            n = c(84),
            o = j(n),
            p = [].slice;
        d.prototype = {
            compiler: d,
            equals: function(a) {
                var b = this.opcodes.length;
                if (a.opcodes.length !== b) return !1;
                for (var c = 0; c < b; c++) {
                    var d = this.opcodes[c],
                        e = a.opcodes[c];
                    if (d.opcode !== e.opcode || !g(d.args, e.args)) return !1
                }
                b = this.children.length;
                for (var c = 0; c < b; c++)
                    if (!this.children[c].equals(a.children[c])) return !1;
                return !0
            },
            guid: 0,
            compile: function(a, b) {
                return this.sourceNode = [], this.opcodes = [], this.children = [], this.options = b, this.stringParams = b.stringParams, this.trackIds = b.trackIds, b.blockParams = b.blockParams || [], b.knownHelpers = m.extend(i(null), {
                    helperMissing: !0,
                    blockHelperMissing: !0,
                    each: !0,
                    "if": !0,
                    unless: !0,
                    "with": !0,
                    log: !0,
                    lookup: !0
                }, b.knownHelpers), this.accept(a)
            },
            compileProgram: function(a) {
                var b = new this.compiler,
                    c = b.compile(a, this.options),
                    d = this.guid++;
                return this.usePartial = this.usePartial || c.usePartial, this.children[d] = c, this.useDepths = this.useDepths || c.useDepths, d
            },
            accept: function(a) {
                if (!this[a.type]) throw new l["default"]("Unknown type: " + a.type, a);
                this.sourceNode.unshift(a);
                var b = this[a.type](a);
                return this.sourceNode.shift(), b
            },
            Program: function(a) {
                this.options.blockParams.unshift(a.blockParams);
                for (var b = a.body, c = b.length, d = 0; d < c; d++) this.accept(b[d]);
                return this.options.blockParams.shift(), this.isSimple = 1 === c, this.blockParams = a.blockParams ? a.blockParams.length : 0, this
            },
            BlockStatement: function(a) {
                h(a);
                var b = a.program,
                    c = a.inverse;
                b = b && this.compileProgram(b), c = c && this.compileProgram(c);
                var d = this.classifySexpr(a);
                "helper" === d ? this.helperSexpr(a, b, c) : "simple" === d ? (this.simpleSexpr(a), this.opcode("pushProgram", b), this.opcode("pushProgram", c), this.opcode("emptyHash"), this.opcode("blockValue", a.path.original)) : (this.ambiguousSexpr(a, b, c), this.opcode("pushProgram", b), this.opcode("pushProgram", c), this.opcode("emptyHash"), this.opcode("ambiguousBlockValue")), this.opcode("append")
            },
            DecoratorBlock: function(a) {
                var b = a.program && this.compileProgram(a.program),
                    c = this.setupFullMustacheParams(a, b, void 0),
                    d = a.path;
                this.useDecorators = !0, this.opcode("registerDecorator", c.length, d.original)
            },
            PartialStatement: function(a) {
                this.usePartial = !0;
                var b = a.program;
                b && (b = this.compileProgram(a.program));
                var c = a.params;
                if (c.length > 1) throw new l["default"]("Unsupported number of partial arguments: " + c.length, a);
                c.length || (this.options.explicitPartialContext ? this.opcode("pushLiteral", "undefined") : c.push({
                    type: "PathExpression",
                    parts: [],
                    depth: 0
                }));
                var d = a.name.original,
                    e = "SubExpression" === a.name.type;
                e && this.accept(a.name), this.setupFullMustacheParams(a, b, void 0, !0);
                var f = a.indent || "";
                this.options.preventIndent && f && (this.opcode("appendContent", f), f = ""), this.opcode("invokePartial", e, d, f), this.opcode("append")
            },
            PartialBlockStatement: function(a) {
                this.PartialStatement(a)
            },
            MustacheStatement: function(a) {
                this.SubExpression(a), a.escaped && !this.options.noEscape ? this.opcode("appendEscaped") : this.opcode("append")
            },
            Decorator: function(a) {
                this.DecoratorBlock(a)
            },
            ContentStatement: function(a) {
                a.value && this.opcode("appendContent", a.value)
            },
            CommentStatement: function() {},
            SubExpression: function(a) {
                h(a);
                var b = this.classifySexpr(a);
                "simple" === b ? this.simpleSexpr(a) : "helper" === b ? this.helperSexpr(a) : this.ambiguousSexpr(a)
            },
            ambiguousSexpr: function(a, b, c) {
                var d = a.path,
                    e = d.parts[0],
                    f = null != b || null != c;
                this.opcode("getContext", d.depth), this.opcode("pushProgram", b), this.opcode("pushProgram", c), d.strict = !0, this.accept(d), this.opcode("invokeAmbiguous", e, f)
            },
            simpleSexpr: function(a) {
                var b = a.path;
                b.strict = !0, this.accept(b), this.opcode("resolvePossibleLambda")
            },
            helperSexpr: function(a, b, c) {
                var d = this.setupFullMustacheParams(a, b, c),
                    e = a.path,
                    f = e.parts[0];
                if (this.options.knownHelpers[f]) this.opcode("invokeKnownHelper", d.length, f);
                else {
                    if (this.options.knownHelpersOnly) throw new l["default"]("You specified knownHelpersOnly, but used the unknown helper " + f, a);
                    e.strict = !0, e.falsy = !0, this.accept(e), this.opcode("invokeHelper", d.length, e.original, o["default"].helpers.simpleId(e))
                }
            },
            PathExpression: function(a) {
                this.addDepth(a.depth), this.opcode("getContext", a.depth);
                var b = a.parts[0],
                    c = o["default"].helpers.scopedId(a),
                    d = !a.depth && !c && this.blockParamIndex(b);
                d ? this.opcode("lookupBlockParam", d, a.parts) : b ? a.data ? (this.options.data = !0, this.opcode("lookupData", a.depth, a.parts, a.strict)) : this.opcode("lookupOnContext", a.parts, a.falsy, a.strict, c) : this.opcode("pushContext")
            },
            StringLiteral: function(a) {
                this.opcode("pushString", a.value)
            },
            NumberLiteral: function(a) {
                this.opcode("pushLiteral", a.value)
            },
            BooleanLiteral: function(a) {
                this.opcode("pushLiteral", a.value)
            },
            UndefinedLiteral: function() {
                this.opcode("pushLiteral", "undefined")
            },
            NullLiteral: function() {
                this.opcode("pushLiteral", "null")
            },
            Hash: function(a) {
                var b = a.pairs,
                    c = 0,
                    d = b.length;
                for (this.opcode("pushHash"); c < d; c++) this.pushParam(b[c].value);
                for (; c--;) this.opcode("assignToHash", b[c].key);
                this.opcode("popHash")
            },
            opcode: function(a) {
                this.opcodes.push({
                    opcode: a,
                    args: p.call(arguments, 1),
                    loc: this.sourceNode[0].loc
                })
            },
            addDepth: function(a) {
                a && (this.useDepths = !0)
            },
            classifySexpr: function(a) {
                var b = o["default"].helpers.simpleId(a.path),
                    c = b && !!this.blockParamIndex(a.path.parts[0]),
                    d = !c && o["default"].helpers.helperExpression(a),
                    e = !c && (d || b);
                if (e && !d) {
                    var f = a.path.parts[0],
                        g = this.options;
                    g.knownHelpers[f] ? d = !0 : g.knownHelpersOnly && (e = !1)
                }
                return d ? "helper" : e ? "ambiguous" : "simple"
            },
            pushParams: function(a) {
                for (var b = 0, c = a.length; b < c; b++) this.pushParam(a[b])
            },
            pushParam: function(a) {
                var b = null != a.value ? a.value : a.original || "";
                if (this.stringParams) b.replace && (b = b.replace(/^(\.?\.\/)*/g, "").replace(/\//g, ".")), a.depth && this.addDepth(a.depth), this.opcode("getContext", a.depth || 0), this.opcode("pushStringParam", b, a.type), "SubExpression" === a.type && this.accept(a);
                else {
                    if (this.trackIds) {
                        var c = void 0;
                        if (!a.parts || o["default"].helpers.scopedId(a) || a.depth || (c = this.blockParamIndex(a.parts[0])), c) {
                            var d = a.parts.slice(1).join(".");
                            this.opcode("pushId", "BlockParam", c, d)
                        } else b = a.original || b, b.replace && (b = b.replace(/^this(?:\.|$)/, "").replace(/^\.\//, "").replace(/^\.$/, "")), this.opcode("pushId", a.type, b)
                    }
                    this.accept(a)
                }
            },
            setupFullMustacheParams: function(a, b, c, d) {
                var e = a.params;
                return this.pushParams(e), this.opcode("pushProgram", b), this.opcode("pushProgram", c), a.hash ? this.accept(a.hash) : this.opcode("emptyHash", d), e
            },
            blockParamIndex: function(a) {
                for (var b = 0, c = this.options.blockParams.length; b < c; b++) {
                    var d = this.options.blockParams[b],
                        e = d && m.indexOf(d, a);
                    if (d && e >= 0) return [b, e]
                }
            }
        }
    }, function(a, b, c) {
        "use strict";

        function d(a) {
            this.value = a
        }

        function e() {}

        function f(a, b, c, d, e) {
            var f = b.popStack(),
                g = c.length;
            for (a && g--; d < g; d++) f = b.nameLookup(f, c[d], e);
            return a ? [b.aliasable("container.strict"), "(", f, ", ", b.quotedString(c[d]), ", ", JSON.stringify(b.source.currentLocation), " )"] : f
        }
        var g = c(60)["default"],
            h = c(1)["default"];
        b.__esModule = !0;
        var i = c(4),
            j = c(6),
            k = h(j),
            l = c(5),
            m = c(92),
            n = h(m);
        e.prototype = {
                nameLookup: function(a, b) {
                    return this.internalNameLookup(a, b)
                },
                depthedLookup: function(a) {
                    return [this.aliasable("container.lookup"), "(depths, ", JSON.stringify(a), ")"]
                },
                compilerInfo: function() {
                    var a = i.COMPILER_REVISION,
                        b = i.REVISION_CHANGES[a];
                    return [a, b]
                },
                appendToBuffer: function(a, b, c) {
                    return l.isArray(a) || (a = [a]), a = this.source.wrap(a, b), this.environment.isSimple ? ["return ", a, ";"] : c ? ["buffer += ", a, ";"] : (a.appendToBuffer = !0, a)
                },
                initializeBuffer: function() {
                    return this.quotedString("")
                },
                internalNameLookup: function(a, b) {
                    return this.lookupPropertyFunctionIsUsed = !0, ["lookupProperty(", a, ",", JSON.stringify(b), ")"]
                },
                lookupPropertyFunctionIsUsed: !1,
                compile: function(a, b, c, d) {
                    this.environment = a, this.options = b, this.stringParams = this.options.stringParams, this.trackIds = this.options.trackIds, this.precompile = !d, this.name = this.environment.name, this.isChild = !!c, this.context = c || {
                        decorators: [],
                        programs: [],
                        environments: []
                    }, this.preamble(), this.stackSlot = 0, this.stackVars = [], this.aliases = {}, this.registers = {
                        list: []
                    }, this.hashes = [], this.compileStack = [], this.inlineStack = [], this.blockParams = [], this.compileChildren(a, b), this.useDepths = this.useDepths || a.useDepths || a.useDecorators || this.options.compat, this.useBlockParams = this.useBlockParams || a.useBlockParams;
                    var e = a.opcodes,
                        f = void 0,
                        g = void 0,
                        h = void 0,
                        i = void 0;
                    for (h = 0, i = e.length; h < i; h++) f = e[h], this.source.currentLocation = f.loc, g = g || f.loc, this[f.opcode].apply(this, f.args);
                    if (this.source.currentLocation = g, this.pushSource(""), this.stackSlot || this.inlineStack.length || this.compileStack.length) throw new k["default"]("Compile completed with content left on stack");
                    this.decorators.isEmpty() ? this.decorators = void 0 : (this.useDecorators = !0, this.decorators.prepend(["var decorators = container.decorators, ", this.lookupPropertyFunctionVarDeclaration(), ";\n"]), this.decorators.push("return fn;"), d ? this.decorators = Function.apply(this, ["fn", "props", "container", "depth0", "data", "blockParams", "depths", this.decorators.merge()]) : (this.decorators.prepend("function(fn, props, container, depth0, data, blockParams, depths) {\n"), this.decorators.push("}\n"), this.decorators = this.decorators.merge()));
                    var j = this.createFunctionContext(d);
                    if (this.isChild) return j;
                    var l = {
                        compiler: this.compilerInfo(),
                        main: j
                    };
                    this.decorators && (l.main_d = this.decorators, l.useDecorators = !0);
                    var m = this.context,
                        n = m.programs,
                        o = m.decorators;
                    for (h = 0, i = n.length; h < i; h++) n[h] && (l[h] = n[h], o[h] && (l[h + "_d"] = o[h], l.useDecorators = !0));
                    return this.environment.usePartial && (l.usePartial = !0), this.options.data && (l.useData = !0), this.useDepths && (l.useDepths = !0), this.useBlockParams && (l.useBlockParams = !0), this.options.compat && (l.compat = !0), d ? l.compilerOptions = this.options : (l.compiler = JSON.stringify(l.compiler), this.source.currentLocation = {
                        start: {
                            line: 1,
                            column: 0
                        }
                    }, l = this.objectLiteral(l), b.srcName ? (l = l.toStringWithSourceMap({
                        file: b.destName
                    }), l.map = l.map && l.map.toString()) : l = l.toString()), l
                },
                preamble: function() {
                    this.lastContext = 0, this.source = new n["default"](this.options.srcName), this.decorators = new n["default"](this.options.srcName)
                },
                createFunctionContext: function(a) {
                    var b = this,
                        c = "",
                        d = this.stackVars.concat(this.registers.list);
                    d.length > 0 && (c += ", " + d.join(", "));
                    var e = 0;
                    g(this.aliases).forEach(function(a) {
                        var d = b.aliases[a];
                        d.children && d.referenceCount > 1 && (c += ", alias" + ++e + "=" + a, d.children[0] = "alias" + e)
                    }), this.lookupPropertyFunctionIsUsed && (c += ", " + this.lookupPropertyFunctionVarDeclaration());
                    var f = ["container", "depth0", "helpers", "partials", "data"];
                    (this.useBlockParams || this.useDepths) && f.push("blockParams"), this.useDepths && f.push("depths");
                    var h = this.mergeSource(c);
                    return a ? (f.push(h), Function.apply(this, f)) : this.source.wrap(["function(", f.join(","), ") {\n  ", h, "}"])
                },
                mergeSource: function(a) {
                    var b = this.environment.isSimple,
                        c = !this.forceBuffer,
                        d = void 0,
                        e = void 0,
                        f = void 0,
                        g = void 0;
                    return this.source.each(function(a) {
                        a.appendToBuffer ? (f ? a.prepend("  + ") : f = a, g = a) : (f && (e ? f.prepend("buffer += ") : d = !0, g.add(";"), f = g = void 0), e = !0, b || (c = !1))
                    }), c ? f ? (f.prepend("return "), g.add(";")) : e || this.source.push('return "";') : (a += ", buffer = " + (d ? "" : this.initializeBuffer()), f ? (f.prepend("return buffer + "), g.add(";")) : this.source.push("return buffer;")), a && this.source.prepend("var " + a.substring(2) + (d ? "" : ";\n")), this.source.merge()
                },
                lookupPropertyFunctionVarDeclaration: function() {
                    return "\n      lookupProperty = container.lookupProperty || function(parent, propertyName) {\n        if (Object.prototype.hasOwnProperty.call(parent, propertyName)) {\n          return parent[propertyName];\n        }\n        return undefined\n    }\n    ".trim()
                },
                blockValue: function(a) {
                    var b = this.aliasable("container.hooks.blockHelperMissing"),
                        c = [this.contextName(0)];
                    this.setupHelperArgs(a, 0, c);
                    var d = this.popStack();
                    c.splice(1, 0, d), this.push(this.source.functionCall(b, "call", c))
                },
                ambiguousBlockValue: function() {
                    var a = this.aliasable("container.hooks.blockHelperMissing"),
                        b = [this.contextName(0)];
                    this.setupHelperArgs("", 0, b, !0), this.flushInline();
                    var c = this.topStack();
                    b.splice(1, 0, c), this.pushSource(["if (!", this.lastHelper, ") { ", c, " = ", this.source.functionCall(a, "call", b), "}"])
                },
                appendContent: function(a) {
                    this.pendingContent ? a = this.pendingContent + a : this.pendingLocation = this.source.currentLocation, this.pendingContent = a
                },
                append: function() {
                    if (this.isInline()) this.replaceStack(function(a) {
                        return [" != null ? ", a, ' : ""']
                    }), this.pushSource(this.appendToBuffer(this.popStack()));
                    else {
                        var a = this.popStack();
                        this.pushSource(["if (", a, " != null) { ", this.appendToBuffer(a, void 0, !0), " }"]), this.environment.isSimple && this.pushSource(["else { ", this.appendToBuffer("''", void 0, !0), " }"])
                    }
                },
                appendEscaped: function() {
                    this.pushSource(this.appendToBuffer([this.aliasable("container.escapeExpression"), "(", this.popStack(), ")"]))
                },
                getContext: function(a) {
                    this.lastContext = a
                },
                pushContext: function() {
                    this.pushStackLiteral(this.contextName(this.lastContext))
                },
                lookupOnContext: function(a, b, c, d) {
                    var e = 0;
                    d || !this.options.compat || this.lastContext ? this.pushContext() : this.push(this.depthedLookup(a[e++])), this.resolvePath("context", a, e, b, c)
                },
                lookupBlockParam: function(a, b) {
                    this.useBlockParams = !0, this.push(["blockParams[", a[0], "][", a[1], "]"]), this.resolvePath("context", b, 1)
                },
                lookupData: function(a, b, c) {
                    a ? this.pushStackLiteral("container.data(data, " + a + ")") : this.pushStackLiteral("data"), this.resolvePath("data", b, 0, !0, c)
                },
                resolvePath: function(a, b, c, d, e) {
                    var g = this;
                    if (this.options.strict || this.options.assumeObjects) return void this.push(f(this.options.strict && e, this, b, c, a));
                    for (var h = b.length; c < h; c++) this.replaceStack(function(e) {
                        var f = g.nameLookup(e, b[c], a);
                        return d ? [" && ", f] : [" != null ? ", f, " : ", e]
                    })
                },
                resolvePossibleLambda: function() {
                    this.push([this.aliasable("container.lambda"), "(", this.popStack(), ", ", this.contextName(0), ")"])
                },
                pushStringParam: function(a, b) {
                    this.pushContext(), this.pushString(b), "SubExpression" !== b && ("string" == typeof a ? this.pushString(a) : this.pushStackLiteral(a))
                },
                emptyHash: function(a) {
                    this.trackIds && this.push("{}"), this.stringParams && (this.push("{}"), this.push("{}")), this.pushStackLiteral(a ? "undefined" : "{}")
                },
                pushHash: function() {
                    this.hash && this.hashes.push(this.hash), this.hash = {
                        values: {},
                        types: [],
                        contexts: [],
                        ids: []
                    }
                },
                popHash: function() {
                    var a = this.hash;
                    this.hash = this.hashes.pop(), this.trackIds && this.push(this.objectLiteral(a.ids)), this.stringParams && (this.push(this.objectLiteral(a.contexts)), this.push(this.objectLiteral(a.types))), this.push(this.objectLiteral(a.values))
                },
                pushString: function(a) {
                    this.pushStackLiteral(this.quotedString(a))
                },
                pushLiteral: function(a) {
                    this.pushStackLiteral(a)
                },
                pushProgram: function(a) {
                    null != a ? this.pushStackLiteral(this.programExpression(a)) : this.pushStackLiteral(null)
                },
                registerDecorator: function(a, b) {
                    var c = this.nameLookup("decorators", b, "decorator"),
                        d = this.setupHelperArgs(b, a);
                    this.decorators.push(["fn = ", this.decorators.functionCall(c, "", ["fn", "props", "container", d]), " || fn;"])
                },
                invokeHelper: function(a, b, c) {
                    var d = this.popStack(),
                        e = this.setupHelper(a, b),
                        f = [];
                    c && f.push(e.name), f.push(d), this.options.strict || f.push(this.aliasable("container.hooks.helperMissing"));
                    var g = ["(", this.itemsSeparatedBy(f, "||"), ")"],
                        h = this.source.functionCall(g, "call", e.callParams);
                    this.push(h)
                },
                itemsSeparatedBy: function(a, b) {
                    var c = [];
                    c.push(a[0]);
                    for (var d = 1; d < a.length; d++) c.push(b, a[d]);
                    return c
                },
                invokeKnownHelper: function(a, b) {
                    var c = this.setupHelper(a, b);
                    this.push(this.source.functionCall(c.name, "call", c.callParams))
                },
                invokeAmbiguous: function(a, b) {
                    this.useRegister("helper");
                    var c = this.popStack();
                    this.emptyHash();
                    var d = this.setupHelper(0, a, b),
                        e = this.lastHelper = this.nameLookup("helpers", a, "helper"),
                        f = ["(", "(helper = ", e, " || ", c, ")"];
                    this.options.strict || (f[0] = "(helper = ", f.push(" != null ? helper : ", this.aliasable("container.hooks.helperMissing"))), this.push(["(", f, d.paramsInit ? ["),(", d.paramsInit] : [], "),", "(typeof helper === ", this.aliasable('"function"'), " ? ", this.source.functionCall("helper", "call", d.callParams), " : helper))"])
                },
                invokePartial: function(a, b, c) {
                    var d = [],
                        e = this.setupParams(b, 1, d);
                    a && (b = this.popStack(), delete e.name), c && (e.indent = JSON.stringify(c)), e.helpers = "helpers", e.partials = "partials", e.decorators = "container.decorators", a ? d.unshift(b) : d.unshift(this.nameLookup("partials", b, "partial")), this.options.compat && (e.depths = "depths"), e = this.objectLiteral(e), d.push(e), this.push(this.source.functionCall("container.invokePartial", "", d))
                },
                assignToHash: function(a) {
                    var b = this.popStack(),
                        c = void 0,
                        d = void 0,
                        e = void 0;
                    this.trackIds && (e = this.popStack()), this.stringParams && (d = this.popStack(), c = this.popStack());
                    var f = this.hash;
                    c && (f.contexts[a] = c), d && (f.types[a] = d), e && (f.ids[a] = e), f.values[a] = b
                },
                pushId: function(a, b, c) {
                    "BlockParam" === a ? this.pushStackLiteral("blockParams[" + b[0] + "].path[" + b[1] + "]" + (c ? " + " + JSON.stringify("." + c) : "")) : "PathExpression" === a ? this.pushString(b) : "SubExpression" === a ? this.pushStackLiteral("true") : this.pushStackLiteral("null")
                },
                compiler: e,
                compileChildren: function(a, b) {
                    for (var c = a.children, d = void 0, e = void 0, f = 0, g = c.length; f < g; f++) {
                        d = c[f], e = new this.compiler;
                        var h = this.matchExistingProgram(d);
                        if (null == h) {
                            this.context.programs.push("");
                            var i = this.context.programs.length;
                            d.index = i, d.name = "program" + i, this.context.programs[i] = e.compile(d, b, this.context, !this.precompile), this.context.decorators[i] = e.decorators, this.context.environments[i] = d, this.useDepths = this.useDepths || e.useDepths, this.useBlockParams = this.useBlockParams || e.useBlockParams, d.useDepths = this.useDepths, d.useBlockParams = this.useBlockParams
                        } else d.index = h.index, d.name = "program" + h.index, this.useDepths = this.useDepths || h.useDepths, this.useBlockParams = this.useBlockParams || h.useBlockParams
                    }
                },
                matchExistingProgram: function(a) {
                    for (var b = 0, c = this.context.environments.length; b < c; b++) {
                        var d = this.context.environments[b];
                        if (d && d.equals(a)) return d
                    }
                },
                programExpression: function(a) {
                    var b = this.environment.children[a],
                        c = [b.index, "data", b.blockParams];
                    return (this.useBlockParams || this.useDepths) && c.push("blockParams"), this.useDepths && c.push("depths"), "container.program(" + c.join(", ") + ")"
                },
                useRegister: function(a) {
                    this.registers[a] || (this.registers[a] = !0, this.registers.list.push(a))
                },
                push: function(a) {
                    return a instanceof d || (a = this.source.wrap(a)), this.inlineStack.push(a), a
                },
                pushStackLiteral: function(a) {
                    this.push(new d(a))
                },
                pushSource: function(a) {
                    this.pendingContent && (this.source.push(this.appendToBuffer(this.source.quotedString(this.pendingContent), this.pendingLocation)), this.pendingContent = void 0), a && this.source.push(a)
                },
                replaceStack: function(a) {
                    var b = ["("],
                        c = void 0,
                        e = void 0,
                        f = void 0;
                    if (!this.isInline()) throw new k["default"]("replaceStack on non-inline");
                    var g = this.popStack(!0);
                    if (g instanceof d) c = [g.value], b = ["(", c], f = !0;
                    else {
                        e = !0;
                        var h = this.incrStack();
                        b = ["((", this.push(h), " = ", g, ")"], c = this.topStack()
                    }
                    var i = a.call(this, c);
                    f || this.popStack(), e && this.stackSlot--, this.push(b.concat(i, ")"))
                },
                incrStack: function() {
                    return this.stackSlot++, this.stackSlot > this.stackVars.length && this.stackVars.push("stack" + this.stackSlot), this.topStackName()
                },
                topStackName: function() {
                    return "stack" + this.stackSlot
                },
                flushInline: function() {
                    var a = this.inlineStack;
                    this.inlineStack = [];
                    for (var b = 0, c = a.length; b < c; b++) {
                        var e = a[b];
                        if (e instanceof d) this.compileStack.push(e);
                        else {
                            var f = this.incrStack();
                            this.pushSource([f, " = ", e, ";"]), this.compileStack.push(f)
                        }
                    }
                },
                isInline: function() {
                    return this.inlineStack.length
                },
                popStack: function(a) {
                    var b = this.isInline(),
                        c = (b ? this.inlineStack : this.compileStack).pop();
                    if (!a && c instanceof d) return c.value;
                    if (!b) {
                        if (!this.stackSlot) throw new k["default"]("Invalid stack pop");
                        this.stackSlot--
                    }
                    return c
                },
                topStack: function() {
                    var a = this.isInline() ? this.inlineStack : this.compileStack,
                        b = a[a.length - 1];
                    return b instanceof d ? b.value : b
                },
                contextName: function(a) {
                    return this.useDepths && a ? "depths[" + a + "]" : "depth" + a
                },
                quotedString: function(a) {
                    return this.source.quotedString(a)
                },
                objectLiteral: function(a) {
                    return this.source.objectLiteral(a)
                },
                aliasable: function(a) {
                    var b = this.aliases[a];
                    return b ? (b.referenceCount++, b) : (b = this.aliases[a] = this.source.wrap(a), b.aliasable = !0, b.referenceCount = 1, b)
                },
                setupHelper: function(a, b, c) {
                    var d = [],
                        e = this.setupHelperArgs(b, a, d, c),
                        f = this.nameLookup("helpers", b, "helper"),
                        g = this.aliasable(this.contextName(0) + " != null ? " + this.contextName(0) + " : (container.nullContext || {})");
                    return {
                        params: d,
                        paramsInit: e,
                        name: f,
                        callParams: [g].concat(d)
                    }
                },
                setupParams: function(a, b, c) {
                    var d = {},
                        e = [],
                        f = [],
                        g = [],
                        h = !c,
                        i = void 0;
                    h && (c = []), d.name = this.quotedString(a), d.hash = this.popStack(), this.trackIds && (d.hashIds = this.popStack()), this.stringParams && (d.hashTypes = this.popStack(), d.hashContexts = this.popStack());
                    var j = this.popStack(),
                        k = this.popStack();
                    (k || j) && (d.fn = k || "container.noop", d.inverse = j || "container.noop");
                    for (var l = b; l--;) i = this.popStack(), c[l] = i, this.trackIds && (g[l] = this.popStack()), this.stringParams && (f[l] = this.popStack(), e[l] = this.popStack());
                    return h && (d.args = this.source.generateArray(c)), this.trackIds && (d.ids = this.source.generateArray(g)), this.stringParams && (d.types = this.source.generateArray(f), d.contexts = this.source.generateArray(e)), this.options.data && (d.data = "data"), this.useBlockParams && (d.blockParams = "blockParams"), d
                },
                setupHelperArgs: function(a, b, c, d) {
                    var e = this.setupParams(a, b, c);
                    return e.loc = JSON.stringify(this.source.currentLocation), e = this.objectLiteral(e), d ? (this.useRegister("options"), c.push("options"), ["options=", e]) : c ? (c.push(e), "") : e
                }
            },
            function() {
                for (var a = "break else new var case finally return void catch for switch while continue function this with default if throw delete in try do instanceof typeof abstract enum int short boolean export interface static byte extends long super char final native synchronized class float package throws const goto private transient debugger implements protected volatile double import public let yield await null true false".split(" "), b = e.RESERVED_WORDS = {}, c = 0, d = a.length; c < d; c++) b[a[c]] = !0
            }(), e.isValidJavaScriptVariableName = function(a) {
                return !e.RESERVED_WORDS[a] && /^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(a)
            }, b["default"] = e, a.exports = b["default"]
    }, function(a, b, c) {
        "use strict";

        function d(a, b, c) {
            if (g.isArray(a)) {
                for (var d = [], e = 0, f = a.length; e < f; e++) d.push(b.wrap(a[e], c));
                return d
            }
            return "boolean" == typeof a || "number" == typeof a ? a + "" : a
        }

        function e(a) {
            this.srcFile = a, this.source = []
        }
        var f = c(60)["default"];
        b.__esModule = !0;
        var g = c(5),
            h = void 0;
        try {} catch (i) {}
        h || (h = function(a, b, c, d) {
            this.src = "", d && this.add(d)
        }, h.prototype = {
            add: function(a) {
                g.isArray(a) && (a = a.join("")), this.src += a
            },
            prepend: function(a) {
                g.isArray(a) && (a = a.join("")), this.src = a + this.src
            },
            toStringWithSourceMap: function() {
                return {
                    code: this.toString()
                }
            },
            toString: function() {
                return this.src
            }
        }), e.prototype = {
            isEmpty: function() {
                return !this.source.length
            },
            prepend: function(a, b) {
                this.source.unshift(this.wrap(a, b))
            },
            push: function(a, b) {
                this.source.push(this.wrap(a, b))
            },
            merge: function() {
                var a = this.empty();
                return this.each(function(b) {
                    a.add(["  ", b, "\n"])
                }), a
            },
            each: function(a) {
                for (var b = 0, c = this.source.length; b < c; b++) a(this.source[b])
            },
            empty: function() {
                var a = this.currentLocation || {
                    start: {}
                };
                return new h(a.start.line, a.start.column, this.srcFile)
            },
            wrap: function(a) {
                var b = arguments.length <= 1 || void 0 === arguments[1] ? this.currentLocation || {
                    start: {}
                } : arguments[1];
                return a instanceof h ? a : (a = d(a, this, b), new h(b.start.line, b.start.column, this.srcFile, a))
            },
            functionCall: function(a, b, c) {
                return c = this.generateList(c), this.wrap([a, b ? "." + b + "(" : "(", c, ")"])
            },
            quotedString: function(a) {
                return '"' + (a + "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029") + '"'
            },
            objectLiteral: function(a) {
                var b = this,
                    c = [];
                f(a).forEach(function(e) {
                    var f = d(a[e], b);
                    "undefined" !== f && c.push([b.quotedString(e), ":", f])
                });
                var e = this.generateList(c);
                return e.prepend("{"), e.add("}"), e
            },
            generateList: function(a) {
                for (var b = this.empty(), c = 0, e = a.length; c < e; c++) c && b.add(","), b.add(d(a[c], this));
                return b
            },
            generateArray: function(a) {
                var b = this.generateList(a);
                return b.prepend("["), b.add("]"), b
            }
        }, b["default"] = e, a.exports = b["default"]
    }])
});

// underscore 1.13.6
! function(n, r) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = r() : "function" == typeof define && define.amd ? define("underscore", r) : (n = "undefined" != typeof globalThis ? globalThis : n || self, function() {
        var t = n._,
            e = n._ = r();
        e.noConflict = function() {
            return n._ = t, e
        }
    }())
}(this, (function() {
    var n = "1.13.6",
        r = "object" == typeof self && self.self === self && self || "object" == typeof global && global.global === global && global || Function("return this")() || {},
        t = Array.prototype,
        e = Object.prototype,
        u = "undefined" != typeof Symbol ? Symbol.prototype : null,
        o = t.push,
        i = t.slice,
        a = e.toString,
        f = e.hasOwnProperty,
        c = "undefined" != typeof ArrayBuffer,
        l = "undefined" != typeof DataView,
        s = Array.isArray,
        p = Object.keys,
        v = Object.create,
        h = c && ArrayBuffer.isView,
        y = isNaN,
        d = isFinite,
        g = !{
            toString: null
        }.propertyIsEnumerable("toString"),
        b = ["valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString"],
        m = Math.pow(2, 53) - 1;

    function j(n, r) {
        return r = null == r ? n.length - 1 : +r,
            function() {
                for (var t = Math.max(arguments.length - r, 0), e = Array(t), u = 0; u < t; u++) e[u] = arguments[u + r];
                switch (r) {
                    case 0:
                        return n.call(this, e);
                    case 1:
                        return n.call(this, arguments[0], e);
                    case 2:
                        return n.call(this, arguments[0], arguments[1], e)
                }
                var o = Array(r + 1);
                for (u = 0; u < r; u++) o[u] = arguments[u];
                return o[r] = e, n.apply(this, o)
            }
    }

    function _(n) {
        var r = typeof n;
        return "function" === r || "object" === r && !!n
    }

    function w(n) {
        return void 0 === n
    }

    function A(n) {
        return !0 === n || !1 === n || "[object Boolean]" === a.call(n)
    }

    function x(n) {
        var r = "[object " + n + "]";
        return function(n) {
            return a.call(n) === r
        }
    }
    var S = x("String"),
        O = x("Number"),
        M = x("Date"),
        E = x("RegExp"),
        B = x("Error"),
        N = x("Symbol"),
        I = x("ArrayBuffer"),
        T = x("Function"),
        k = r.document && r.document.childNodes;
    "function" != typeof /./ && "object" != typeof Int8Array && "function" != typeof k && (T = function(n) {
        return "function" == typeof n || !1
    });
    var D = T,
        R = x("Object"),
        F = l && R(new DataView(new ArrayBuffer(8))),
        V = "undefined" != typeof Map && R(new Map),
        P = x("DataView");
    var q = F ? function(n) {
            return null != n && D(n.getInt8) && I(n.buffer)
        } : P,
        U = s || x("Array");

    function W(n, r) {
        return null != n && f.call(n, r)
    }
    var z = x("Arguments");
    ! function() {
        z(arguments) || (z = function(n) {
            return W(n, "callee")
        })
    }();
    var L = z;

    function $(n) {
        return O(n) && y(n)
    }

    function C(n) {
        return function() {
            return n
        }
    }

    function K(n) {
        return function(r) {
            var t = n(r);
            return "number" == typeof t && t >= 0 && t <= m
        }
    }

    function J(n) {
        return function(r) {
            return null == r ? void 0 : r[n]
        }
    }
    var G = J("byteLength"),
        H = K(G),
        Q = /\[object ((I|Ui)nt(8|16|32)|Float(32|64)|Uint8Clamped|Big(I|Ui)nt64)Array\]/;
    var X = c ? function(n) {
            return h ? h(n) && !q(n) : H(n) && Q.test(a.call(n))
        } : C(!1),
        Y = J("length");

    function Z(n, r) {
        r = function(n) {
            for (var r = {}, t = n.length, e = 0; e < t; ++e) r[n[e]] = !0;
            return {
                contains: function(n) {
                    return !0 === r[n]
                },
                push: function(t) {
                    return r[t] = !0, n.push(t)
                }
            }
        }(r);
        var t = b.length,
            u = n.constructor,
            o = D(u) && u.prototype || e,
            i = "constructor";
        for (W(n, i) && !r.contains(i) && r.push(i); t--;)(i = b[t]) in n && n[i] !== o[i] && !r.contains(i) && r.push(i)
    }

    function nn(n) {
        if (!_(n)) return [];
        if (p) return p(n);
        var r = [];
        for (var t in n) W(n, t) && r.push(t);
        return g && Z(n, r), r
    }

    function rn(n, r) {
        var t = nn(r),
            e = t.length;
        if (null == n) return !e;
        for (var u = Object(n), o = 0; o < e; o++) {
            var i = t[o];
            if (r[i] !== u[i] || !(i in u)) return !1
        }
        return !0
    }

    function tn(n) {
        return n instanceof tn ? n : this instanceof tn ? void(this._wrapped = n) : new tn(n)
    }

    function en(n) {
        return new Uint8Array(n.buffer || n, n.byteOffset || 0, G(n))
    }
    tn.VERSION = n, tn.prototype.value = function() {
        return this._wrapped
    }, tn.prototype.valueOf = tn.prototype.toJSON = tn.prototype.value, tn.prototype.toString = function() {
        return String(this._wrapped)
    };
    var un = "[object DataView]";

    function on(n, r, t, e) {
        if (n === r) return 0 !== n || 1 / n == 1 / r;
        if (null == n || null == r) return !1;
        if (n != n) return r != r;
        var o = typeof n;
        return ("function" === o || "object" === o || "object" == typeof r) && function n(r, t, e, o) {
            r instanceof tn && (r = r._wrapped);
            t instanceof tn && (t = t._wrapped);
            var i = a.call(r);
            if (i !== a.call(t)) return !1;
            if (F && "[object Object]" == i && q(r)) {
                if (!q(t)) return !1;
                i = un
            }
            switch (i) {
                case "[object RegExp]":
                case "[object String]":
                    return "" + r == "" + t;
                case "[object Number]":
                    return +r != +r ? +t != +t : 0 == +r ? 1 / +r == 1 / t : +r == +t;
                case "[object Date]":
                case "[object Boolean]":
                    return +r == +t;
                case "[object Symbol]":
                    return u.valueOf.call(r) === u.valueOf.call(t);
                case "[object ArrayBuffer]":
                case un:
                    return n(en(r), en(t), e, o)
            }
            var f = "[object Array]" === i;
            if (!f && X(r)) {
                if (G(r) !== G(t)) return !1;
                if (r.buffer === t.buffer && r.byteOffset === t.byteOffset) return !0;
                f = !0
            }
            if (!f) {
                if ("object" != typeof r || "object" != typeof t) return !1;
                var c = r.constructor,
                    l = t.constructor;
                if (c !== l && !(D(c) && c instanceof c && D(l) && l instanceof l) && "constructor" in r && "constructor" in t) return !1
            }
            o = o || [];
            var s = (e = e || []).length;
            for (; s--;)
                if (e[s] === r) return o[s] === t;
            if (e.push(r), o.push(t), f) {
                if ((s = r.length) !== t.length) return !1;
                for (; s--;)
                    if (!on(r[s], t[s], e, o)) return !1
            } else {
                var p, v = nn(r);
                if (s = v.length, nn(t).length !== s) return !1;
                for (; s--;)
                    if (p = v[s], !W(t, p) || !on(r[p], t[p], e, o)) return !1
            }
            return e.pop(), o.pop(), !0
        }(n, r, t, e)
    }

    function an(n) {
        if (!_(n)) return [];
        var r = [];
        for (var t in n) r.push(t);
        return g && Z(n, r), r
    }

    function fn(n) {
        var r = Y(n);
        return function(t) {
            if (null == t) return !1;
            var e = an(t);
            if (Y(e)) return !1;
            for (var u = 0; u < r; u++)
                if (!D(t[n[u]])) return !1;
            return n !== hn || !D(t[cn])
        }
    }
    var cn = "forEach",
        ln = "has",
        sn = ["clear", "delete"],
        pn = ["get", ln, "set"],
        vn = sn.concat(cn, pn),
        hn = sn.concat(pn),
        yn = ["add"].concat(sn, cn, ln),
        dn = V ? fn(vn) : x("Map"),
        gn = V ? fn(hn) : x("WeakMap"),
        bn = V ? fn(yn) : x("Set"),
        mn = x("WeakSet");

    function jn(n) {
        for (var r = nn(n), t = r.length, e = Array(t), u = 0; u < t; u++) e[u] = n[r[u]];
        return e
    }

    function _n(n) {
        for (var r = {}, t = nn(n), e = 0, u = t.length; e < u; e++) r[n[t[e]]] = t[e];
        return r
    }

    function wn(n) {
        var r = [];
        for (var t in n) D(n[t]) && r.push(t);
        return r.sort()
    }

    function An(n, r) {
        return function(t) {
            var e = arguments.length;
            if (r && (t = Object(t)), e < 2 || null == t) return t;
            for (var u = 1; u < e; u++)
                for (var o = arguments[u], i = n(o), a = i.length, f = 0; f < a; f++) {
                    var c = i[f];
                    r && void 0 !== t[c] || (t[c] = o[c])
                }
            return t
        }
    }
    var xn = An(an),
        Sn = An(nn),
        On = An(an, !0);

    function Mn(n) {
        if (!_(n)) return {};
        if (v) return v(n);
        var r = function() {};
        r.prototype = n;
        var t = new r;
        return r.prototype = null, t
    }

    function En(n) {
        return U(n) ? n : [n]
    }

    function Bn(n) {
        return tn.toPath(n)
    }

    function Nn(n, r) {
        for (var t = r.length, e = 0; e < t; e++) {
            if (null == n) return;
            n = n[r[e]]
        }
        return t ? n : void 0
    }

    function In(n, r, t) {
        var e = Nn(n, Bn(r));
        return w(e) ? t : e
    }

    function Tn(n) {
        return n
    }

    function kn(n) {
        return n = Sn({}, n),
            function(r) {
                return rn(r, n)
            }
    }

    function Dn(n) {
        return n = Bn(n),
            function(r) {
                return Nn(r, n)
            }
    }

    function Rn(n, r, t) {
        if (void 0 === r) return n;
        switch (null == t ? 3 : t) {
            case 1:
                return function(t) {
                    return n.call(r, t)
                };
            case 3:
                return function(t, e, u) {
                    return n.call(r, t, e, u)
                };
            case 4:
                return function(t, e, u, o) {
                    return n.call(r, t, e, u, o)
                }
        }
        return function() {
            return n.apply(r, arguments)
        }
    }

    function Fn(n, r, t) {
        return null == n ? Tn : D(n) ? Rn(n, r, t) : _(n) && !U(n) ? kn(n) : Dn(n)
    }

    function Vn(n, r) {
        return Fn(n, r, 1 / 0)
    }

    function Pn(n, r, t) {
        return tn.iteratee !== Vn ? tn.iteratee(n, r) : Fn(n, r, t)
    }

    function qn() {}

    function Un(n, r) {
        return null == r && (r = n, n = 0), n + Math.floor(Math.random() * (r - n + 1))
    }
    tn.toPath = En, tn.iteratee = Vn;
    var Wn = Date.now || function() {
        return (new Date).getTime()
    };

    function zn(n) {
        var r = function(r) {
                return n[r]
            },
            t = "(?:" + nn(n).join("|") + ")",
            e = RegExp(t),
            u = RegExp(t, "g");
        return function(n) {
            return n = null == n ? "" : "" + n, e.test(n) ? n.replace(u, r) : n
        }
    }
    var Ln = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#x27;",
            "`": "&#x60;"
        },
        $n = zn(Ln),
        Cn = zn(_n(Ln)),
        Kn = tn.templateSettings = {
            evaluate: /<%([\s\S]+?)%>/g,
            interpolate: /<%=([\s\S]+?)%>/g,
            escape: /<%-([\s\S]+?)%>/g
        },
        Jn = /(.)^/,
        Gn = {
            "'": "'",
            "\\": "\\",
            "\r": "r",
            "\n": "n",
            "\u2028": "u2028",
            "\u2029": "u2029"
        },
        Hn = /\\|'|\r|\n|\u2028|\u2029/g;

    function Qn(n) {
        return "\\" + Gn[n]
    }
    var Xn = /^\s*(\w|\$)+\s*$/;
    var Yn = 0;

    function Zn(n, r, t, e, u) {
        if (!(e instanceof r)) return n.apply(t, u);
        var o = Mn(n.prototype),
            i = n.apply(o, u);
        return _(i) ? i : o
    }
    var nr = j((function(n, r) {
        var t = nr.placeholder,
            e = function() {
                for (var u = 0, o = r.length, i = Array(o), a = 0; a < o; a++) i[a] = r[a] === t ? arguments[u++] : r[a];
                for (; u < arguments.length;) i.push(arguments[u++]);
                return Zn(n, e, this, this, i)
            };
        return e
    }));
    nr.placeholder = tn;
    var rr = j((function(n, r, t) {
            if (!D(n)) throw new TypeError("Bind must be called on a function");
            var e = j((function(u) {
                return Zn(n, e, r, this, t.concat(u))
            }));
            return e
        })),
        tr = K(Y);

    function er(n, r, t, e) {
        if (e = e || [], r || 0 === r) {
            if (r <= 0) return e.concat(n)
        } else r = 1 / 0;
        for (var u = e.length, o = 0, i = Y(n); o < i; o++) {
            var a = n[o];
            if (tr(a) && (U(a) || L(a)))
                if (r > 1) er(a, r - 1, t, e), u = e.length;
                else
                    for (var f = 0, c = a.length; f < c;) e[u++] = a[f++];
            else t || (e[u++] = a)
        }
        return e
    }
    var ur = j((function(n, r) {
        var t = (r = er(r, !1, !1)).length;
        if (t < 1) throw new Error("bindAll must be passed function names");
        for (; t--;) {
            var e = r[t];
            n[e] = rr(n[e], n)
        }
        return n
    }));
    var or = j((function(n, r, t) {
            return setTimeout((function() {
                return n.apply(null, t)
            }), r)
        })),
        ir = nr(or, tn, 1);

    function ar(n) {
        return function() {
            return !n.apply(this, arguments)
        }
    }

    function fr(n, r) {
        var t;
        return function() {
            return --n > 0 && (t = r.apply(this, arguments)), n <= 1 && (r = null), t
        }
    }
    var cr = nr(fr, 2);

    function lr(n, r, t) {
        r = Pn(r, t);
        for (var e, u = nn(n), o = 0, i = u.length; o < i; o++)
            if (r(n[e = u[o]], e, n)) return e
    }

    function sr(n) {
        return function(r, t, e) {
            t = Pn(t, e);
            for (var u = Y(r), o = n > 0 ? 0 : u - 1; o >= 0 && o < u; o += n)
                if (t(r[o], o, r)) return o;
            return -1
        }
    }
    var pr = sr(1),
        vr = sr(-1);

    function hr(n, r, t, e) {
        for (var u = (t = Pn(t, e, 1))(r), o = 0, i = Y(n); o < i;) {
            var a = Math.floor((o + i) / 2);
            t(n[a]) < u ? o = a + 1 : i = a
        }
        return o
    }

    function yr(n, r, t) {
        return function(e, u, o) {
            var a = 0,
                f = Y(e);
            if ("number" == typeof o) n > 0 ? a = o >= 0 ? o : Math.max(o + f, a) : f = o >= 0 ? Math.min(o + 1, f) : o + f + 1;
            else if (t && o && f) return e[o = t(e, u)] === u ? o : -1;
            if (u != u) return (o = r(i.call(e, a, f), $)) >= 0 ? o + a : -1;
            for (o = n > 0 ? a : f - 1; o >= 0 && o < f; o += n)
                if (e[o] === u) return o;
            return -1
        }
    }
    var dr = yr(1, pr, hr),
        gr = yr(-1, vr);

    function br(n, r, t) {
        var e = (tr(n) ? pr : lr)(n, r, t);
        if (void 0 !== e && -1 !== e) return n[e]
    }

    function mr(n, r, t) {
        var e, u;
        if (r = Rn(r, t), tr(n))
            for (e = 0, u = n.length; e < u; e++) r(n[e], e, n);
        else {
            var o = nn(n);
            for (e = 0, u = o.length; e < u; e++) r(n[o[e]], o[e], n)
        }
        return n
    }

    function jr(n, r, t) {
        r = Pn(r, t);
        for (var e = !tr(n) && nn(n), u = (e || n).length, o = Array(u), i = 0; i < u; i++) {
            var a = e ? e[i] : i;
            o[i] = r(n[a], a, n)
        }
        return o
    }

    function _r(n) {
        var r = function(r, t, e, u) {
            var o = !tr(r) && nn(r),
                i = (o || r).length,
                a = n > 0 ? 0 : i - 1;
            for (u || (e = r[o ? o[a] : a], a += n); a >= 0 && a < i; a += n) {
                var f = o ? o[a] : a;
                e = t(e, r[f], f, r)
            }
            return e
        };
        return function(n, t, e, u) {
            var o = arguments.length >= 3;
            return r(n, Rn(t, u, 4), e, o)
        }
    }
    var wr = _r(1),
        Ar = _r(-1);

    function xr(n, r, t) {
        var e = [];
        return r = Pn(r, t), mr(n, (function(n, t, u) {
            r(n, t, u) && e.push(n)
        })), e
    }

    function Sr(n, r, t) {
        r = Pn(r, t);
        for (var e = !tr(n) && nn(n), u = (e || n).length, o = 0; o < u; o++) {
            var i = e ? e[o] : o;
            if (!r(n[i], i, n)) return !1
        }
        return !0
    }

    function Or(n, r, t) {
        r = Pn(r, t);
        for (var e = !tr(n) && nn(n), u = (e || n).length, o = 0; o < u; o++) {
            var i = e ? e[o] : o;
            if (r(n[i], i, n)) return !0
        }
        return !1
    }

    function Mr(n, r, t, e) {
        return tr(n) || (n = jn(n)), ("number" != typeof t || e) && (t = 0), dr(n, r, t) >= 0
    }
    var Er = j((function(n, r, t) {
        var e, u;
        return D(r) ? u = r : (r = Bn(r), e = r.slice(0, -1), r = r[r.length - 1]), jr(n, (function(n) {
            var o = u;
            if (!o) {
                if (e && e.length && (n = Nn(n, e)), null == n) return;
                o = n[r]
            }
            return null == o ? o : o.apply(n, t)
        }))
    }));

    function Br(n, r) {
        return jr(n, Dn(r))
    }

    function Nr(n, r, t) {
        var e, u, o = -1 / 0,
            i = -1 / 0;
        if (null == r || "number" == typeof r && "object" != typeof n[0] && null != n)
            for (var a = 0, f = (n = tr(n) ? n : jn(n)).length; a < f; a++) null != (e = n[a]) && e > o && (o = e);
        else r = Pn(r, t), mr(n, (function(n, t, e) {
            ((u = r(n, t, e)) > i || u === -1 / 0 && o === -1 / 0) && (o = n, i = u)
        }));
        return o
    }
    var Ir = /[^\ud800-\udfff]|[\ud800-\udbff][\udc00-\udfff]|[\ud800-\udfff]/g;

    function Tr(n) {
        return n ? U(n) ? i.call(n) : S(n) ? n.match(Ir) : tr(n) ? jr(n, Tn) : jn(n) : []
    }

    function kr(n, r, t) {
        if (null == r || t) return tr(n) || (n = jn(n)), n[Un(n.length - 1)];
        var e = Tr(n),
            u = Y(e);
        r = Math.max(Math.min(r, u), 0);
        for (var o = u - 1, i = 0; i < r; i++) {
            var a = Un(i, o),
                f = e[i];
            e[i] = e[a], e[a] = f
        }
        return e.slice(0, r)
    }

    function Dr(n, r) {
        return function(t, e, u) {
            var o = r ? [
                [],
                []
            ] : {};
            return e = Pn(e, u), mr(t, (function(r, u) {
                var i = e(r, u, t);
                n(o, r, i)
            })), o
        }
    }
    var Rr = Dr((function(n, r, t) {
            W(n, t) ? n[t].push(r) : n[t] = [r]
        })),
        Fr = Dr((function(n, r, t) {
            n[t] = r
        })),
        Vr = Dr((function(n, r, t) {
            W(n, t) ? n[t]++ : n[t] = 1
        })),
        Pr = Dr((function(n, r, t) {
            n[t ? 0 : 1].push(r)
        }), !0);

    function qr(n, r, t) {
        return r in t
    }
    var Ur = j((function(n, r) {
            var t = {},
                e = r[0];
            if (null == n) return t;
            D(e) ? (r.length > 1 && (e = Rn(e, r[1])), r = an(n)) : (e = qr, r = er(r, !1, !1), n = Object(n));
            for (var u = 0, o = r.length; u < o; u++) {
                var i = r[u],
                    a = n[i];
                e(a, i, n) && (t[i] = a)
            }
            return t
        })),
        Wr = j((function(n, r) {
            var t, e = r[0];
            return D(e) ? (e = ar(e), r.length > 1 && (t = r[1])) : (r = jr(er(r, !1, !1), String), e = function(n, t) {
                return !Mr(r, t)
            }), Ur(n, e, t)
        }));

    function zr(n, r, t) {
        return i.call(n, 0, Math.max(0, n.length - (null == r || t ? 1 : r)))
    }

    function Lr(n, r, t) {
        return null == n || n.length < 1 ? null == r || t ? void 0 : [] : null == r || t ? n[0] : zr(n, n.length - r)
    }

    function $r(n, r, t) {
        return i.call(n, null == r || t ? 1 : r)
    }
    var Cr = j((function(n, r) {
            return r = er(r, !0, !0), xr(n, (function(n) {
                return !Mr(r, n)
            }))
        })),
        Kr = j((function(n, r) {
            return Cr(n, r)
        }));

    function Jr(n, r, t, e) {
        A(r) || (e = t, t = r, r = !1), null != t && (t = Pn(t, e));
        for (var u = [], o = [], i = 0, a = Y(n); i < a; i++) {
            var f = n[i],
                c = t ? t(f, i, n) : f;
            r && !t ? (i && o === c || u.push(f), o = c) : t ? Mr(o, c) || (o.push(c), u.push(f)) : Mr(u, f) || u.push(f)
        }
        return u
    }
    var Gr = j((function(n) {
        return Jr(er(n, !0, !0))
    }));

    function Hr(n) {
        for (var r = n && Nr(n, Y).length || 0, t = Array(r), e = 0; e < r; e++) t[e] = Br(n, e);
        return t
    }
    var Qr = j(Hr);

    function Xr(n, r) {
        return n._chain ? tn(r).chain() : r
    }

    function Yr(n) {
        return mr(wn(n), (function(r) {
            var t = tn[r] = n[r];
            tn.prototype[r] = function() {
                var n = [this._wrapped];
                return o.apply(n, arguments), Xr(this, t.apply(tn, n))
            }
        })), tn
    }
    mr(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], (function(n) {
        var r = t[n];
        tn.prototype[n] = function() {
            var t = this._wrapped;
            return null != t && (r.apply(t, arguments), "shift" !== n && "splice" !== n || 0 !== t.length || delete t[0]), Xr(this, t)
        }
    })), mr(["concat", "join", "slice"], (function(n) {
        var r = t[n];
        tn.prototype[n] = function() {
            var n = this._wrapped;
            return null != n && (n = r.apply(n, arguments)), Xr(this, n)
        }
    }));
    var Zr = Yr({
        __proto__: null,
        VERSION: n,
        restArguments: j,
        isObject: _,
        isNull: function(n) {
            return null === n
        },
        isUndefined: w,
        isBoolean: A,
        isElement: function(n) {
            return !(!n || 1 !== n.nodeType)
        },
        isString: S,
        isNumber: O,
        isDate: M,
        isRegExp: E,
        isError: B,
        isSymbol: N,
        isArrayBuffer: I,
        isDataView: q,
        isArray: U,
        isFunction: D,
        isArguments: L,
        isFinite: function(n) {
            return !N(n) && d(n) && !isNaN(parseFloat(n))
        },
        isNaN: $,
        isTypedArray: X,
        isEmpty: function(n) {
            if (null == n) return !0;
            var r = Y(n);
            return "number" == typeof r && (U(n) || S(n) || L(n)) ? 0 === r : 0 === Y(nn(n))
        },
        isMatch: rn,
        isEqual: function(n, r) {
            return on(n, r)
        },
        isMap: dn,
        isWeakMap: gn,
        isSet: bn,
        isWeakSet: mn,
        keys: nn,
        allKeys: an,
        values: jn,
        pairs: function(n) {
            for (var r = nn(n), t = r.length, e = Array(t), u = 0; u < t; u++) e[u] = [r[u], n[r[u]]];
            return e
        },
        invert: _n,
        functions: wn,
        methods: wn,
        extend: xn,
        extendOwn: Sn,
        assign: Sn,
        defaults: On,
        create: function(n, r) {
            var t = Mn(n);
            return r && Sn(t, r), t
        },
        clone: function(n) {
            return _(n) ? U(n) ? n.slice() : xn({}, n) : n
        },
        tap: function(n, r) {
            return r(n), n
        },
        get: In,
        has: function(n, r) {
            for (var t = (r = Bn(r)).length, e = 0; e < t; e++) {
                var u = r[e];
                if (!W(n, u)) return !1;
                n = n[u]
            }
            return !!t
        },
        mapObject: function(n, r, t) {
            r = Pn(r, t);
            for (var e = nn(n), u = e.length, o = {}, i = 0; i < u; i++) {
                var a = e[i];
                o[a] = r(n[a], a, n)
            }
            return o
        },
        identity: Tn,
        constant: C,
        noop: qn,
        toPath: En,
        property: Dn,
        propertyOf: function(n) {
            return null == n ? qn : function(r) {
                return In(n, r)
            }
        },
        matcher: kn,
        matches: kn,
        times: function(n, r, t) {
            var e = Array(Math.max(0, n));
            r = Rn(r, t, 1);
            for (var u = 0; u < n; u++) e[u] = r(u);
            return e
        },
        random: Un,
        now: Wn,
        escape: $n,
        unescape: Cn,
        templateSettings: Kn,
        template: function(n, r, t) {
            !r && t && (r = t), r = On({}, r, tn.templateSettings);
            var e = RegExp([(r.escape || Jn).source, (r.interpolate || Jn).source, (r.evaluate || Jn).source].join("|") + "|$", "g"),
                u = 0,
                o = "__p+='";
            n.replace(e, (function(r, t, e, i, a) {
                return o += n.slice(u, a).replace(Hn, Qn), u = a + r.length, t ? o += "'+\n((__t=(" + t + "))==null?'':_.escape(__t))+\n'" : e ? o += "'+\n((__t=(" + e + "))==null?'':__t)+\n'" : i && (o += "';\n" + i + "\n__p+='"), r
            })), o += "';\n";
            var i, a = r.variable;
            if (a) {
                if (!Xn.test(a)) throw new Error("variable is not a bare identifier: " + a)
            } else o = "with(obj||{}){\n" + o + "}\n", a = "obj";
            o = "var __t,__p='',__j=Array.prototype.join," + "print=function(){__p+=__j.call(arguments,'');};\n" + o + "return __p;\n";
            try {
                i = new Function(a, "_", o)
            } catch (n) {
                throw n.source = o, n
            }
            var f = function(n) {
                return i.call(this, n, tn)
            };
            return f.source = "function(" + a + "){\n" + o + "}", f
        },
        result: function(n, r, t) {
            var e = (r = Bn(r)).length;
            if (!e) return D(t) ? t.call(n) : t;
            for (var u = 0; u < e; u++) {
                var o = null == n ? void 0 : n[r[u]];
                void 0 === o && (o = t, u = e), n = D(o) ? o.call(n) : o
            }
            return n
        },
        uniqueId: function(n) {
            var r = ++Yn + "";
            return n ? n + r : r
        },
        chain: function(n) {
            var r = tn(n);
            return r._chain = !0, r
        },
        iteratee: Vn,
        partial: nr,
        bind: rr,
        bindAll: ur,
        memoize: function(n, r) {
            var t = function(e) {
                var u = t.cache,
                    o = "" + (r ? r.apply(this, arguments) : e);
                return W(u, o) || (u[o] = n.apply(this, arguments)), u[o]
            };
            return t.cache = {}, t
        },
        delay: or,
        defer: ir,
        throttle: function(n, r, t) {
            var e, u, o, i, a = 0;
            t || (t = {});
            var f = function() {
                    a = !1 === t.leading ? 0 : Wn(), e = null, i = n.apply(u, o), e || (u = o = null)
                },
                c = function() {
                    var c = Wn();
                    a || !1 !== t.leading || (a = c);
                    var l = r - (c - a);
                    return u = this, o = arguments, l <= 0 || l > r ? (e && (clearTimeout(e), e = null), a = c, i = n.apply(u, o), e || (u = o = null)) : e || !1 === t.trailing || (e = setTimeout(f, l)), i
                };
            return c.cancel = function() {
                clearTimeout(e), a = 0, e = u = o = null
            }, c
        },
        debounce: function(n, r, t) {
            var e, u, o, i, a, f = function() {
                    var c = Wn() - u;
                    r > c ? e = setTimeout(f, r - c) : (e = null, t || (i = n.apply(a, o)), e || (o = a = null))
                },
                c = j((function(c) {
                    return a = this, o = c, u = Wn(), e || (e = setTimeout(f, r), t && (i = n.apply(a, o))), i
                }));
            return c.cancel = function() {
                clearTimeout(e), e = o = a = null
            }, c
        },
        wrap: function(n, r) {
            return nr(r, n)
        },
        negate: ar,
        compose: function() {
            var n = arguments,
                r = n.length - 1;
            return function() {
                for (var t = r, e = n[r].apply(this, arguments); t--;) e = n[t].call(this, e);
                return e
            }
        },
        after: function(n, r) {
            return function() {
                if (--n < 1) return r.apply(this, arguments)
            }
        },
        before: fr,
        once: cr,
        findKey: lr,
        findIndex: pr,
        findLastIndex: vr,
        sortedIndex: hr,
        indexOf: dr,
        lastIndexOf: gr,
        find: br,
        detect: br,
        findWhere: function(n, r) {
            return br(n, kn(r))
        },
        each: mr,
        forEach: mr,
        map: jr,
        collect: jr,
        reduce: wr,
        foldl: wr,
        inject: wr,
        reduceRight: Ar,
        foldr: Ar,
        filter: xr,
        select: xr,
        reject: function(n, r, t) {
            return xr(n, ar(Pn(r)), t)
        },
        every: Sr,
        all: Sr,
        some: Or,
        any: Or,
        contains: Mr,
        includes: Mr,
        include: Mr,
        invoke: Er,
        pluck: Br,
        where: function(n, r) {
            return xr(n, kn(r))
        },
        max: Nr,
        min: function(n, r, t) {
            var e, u, o = 1 / 0,
                i = 1 / 0;
            if (null == r || "number" == typeof r && "object" != typeof n[0] && null != n)
                for (var a = 0, f = (n = tr(n) ? n : jn(n)).length; a < f; a++) null != (e = n[a]) && e < o && (o = e);
            else r = Pn(r, t), mr(n, (function(n, t, e) {
                ((u = r(n, t, e)) < i || u === 1 / 0 && o === 1 / 0) && (o = n, i = u)
            }));
            return o
        },
        shuffle: function(n) {
            return kr(n, 1 / 0)
        },
        sample: kr,
        sortBy: function(n, r, t) {
            var e = 0;
            return r = Pn(r, t), Br(jr(n, (function(n, t, u) {
                return {
                    value: n,
                    index: e++,
                    criteria: r(n, t, u)
                }
            })).sort((function(n, r) {
                var t = n.criteria,
                    e = r.criteria;
                if (t !== e) {
                    if (t > e || void 0 === t) return 1;
                    if (t < e || void 0 === e) return -1
                }
                return n.index - r.index
            })), "value")
        },
        groupBy: Rr,
        indexBy: Fr,
        countBy: Vr,
        partition: Pr,
        toArray: Tr,
        size: function(n) {
            return null == n ? 0 : tr(n) ? n.length : nn(n).length
        },
        pick: Ur,
        omit: Wr,
        first: Lr,
        head: Lr,
        take: Lr,
        initial: zr,
        last: function(n, r, t) {
            return null == n || n.length < 1 ? null == r || t ? void 0 : [] : null == r || t ? n[n.length - 1] : $r(n, Math.max(0, n.length - r))
        },
        rest: $r,
        tail: $r,
        drop: $r,
        compact: function(n) {
            return xr(n, Boolean)
        },
        flatten: function(n, r) {
            return er(n, r, !1)
        },
        without: Kr,
        uniq: Jr,
        unique: Jr,
        union: Gr,
        intersection: function(n) {
            for (var r = [], t = arguments.length, e = 0, u = Y(n); e < u; e++) {
                var o = n[e];
                if (!Mr(r, o)) {
                    var i;
                    for (i = 1; i < t && Mr(arguments[i], o); i++);
                    i === t && r.push(o)
                }
            }
            return r
        },
        difference: Cr,
        unzip: Hr,
        transpose: Hr,
        zip: Qr,
        object: function(n, r) {
            for (var t = {}, e = 0, u = Y(n); e < u; e++) r ? t[n[e]] = r[e] : t[n[e][0]] = n[e][1];
            return t
        },
        range: function(n, r, t) {
            null == r && (r = n || 0, n = 0), t || (t = r < n ? -1 : 1);
            for (var e = Math.max(Math.ceil((r - n) / t), 0), u = Array(e), o = 0; o < e; o++, n += t) u[o] = n;
            return u
        },
        chunk: function(n, r) {
            if (null == r || r < 1) return [];
            for (var t = [], e = 0, u = n.length; e < u;) t.push(i.call(n, e, e += r));
            return t
        },
        mixin: Yr,
        default: tn
    });
    return Zr._ = Zr, Zr
}));

// backbone 1.5.0
(function(r) {
    var n = typeof self == "object" && self.self === self && self || typeof global == "object" && global.global === global && global;
    if (typeof define === "function" && define.amd) {
        define(["underscore", "jquery", "exports"], function(t, e, i) {
            n.Backbone = r(n, i, t, e)
        })
    } else if (typeof exports !== "undefined") {
        var t = require("underscore"),
            e;
        try {
            e = require("jquery")
        } catch (t) {}
        r(n, exports, t, e)
    } else {
        n.Backbone = r(n, {}, n._, n.jQuery || n.Zepto || n.ender || n.$)
    }
})(function(t, h, x, e) {
    var i = t.Backbone;
    var a = Array.prototype.slice;
    h.VERSION = "1.5.0";
    h.$ = e;
    h.noConflict = function() {
        t.Backbone = i;
        return this
    };
    h.emulateHTTP = false;
    h.emulateJSON = false;
    var r = h.Events = {};
    var o = /\s+/;
    var l;
    var u = function(t, e, i, r, n) {
        var s = 0,
            a;
        if (i && typeof i === "object") {
            if (r !== void 0 && "context" in n && n.context === void 0) n.context = r;
            for (a = x.keys(i); s < a.length; s++) {
                e = u(t, e, a[s], i[a[s]], n)
            }
        } else if (i && o.test(i)) {
            for (a = i.split(o); s < a.length; s++) {
                e = t(e, a[s], r, n)
            }
        } else {
            e = t(e, i, r, n)
        }
        return e
    };
    r.on = function(t, e, i) {
        this._events = u(n, this._events || {}, t, e, {
            context: i,
            ctx: this,
            listening: l
        });
        if (l) {
            var r = this._listeners || (this._listeners = {});
            r[l.id] = l;
            l.interop = false
        }
        return this
    };
    r.listenTo = function(t, e, i) {
        if (!t) return this;
        var r = t._listenId || (t._listenId = x.uniqueId("l"));
        var n = this._listeningTo || (this._listeningTo = {});
        var s = l = n[r];
        if (!s) {
            this._listenId || (this._listenId = x.uniqueId("l"));
            s = l = n[r] = new p(this, t)
        }
        var a = c(t, e, i, this);
        l = void 0;
        if (a) throw a;
        if (s.interop) s.on(e, i);
        return this
    };
    var n = function(t, e, i, r) {
        if (i) {
            var n = t[e] || (t[e] = []);
            var s = r.context,
                a = r.ctx,
                o = r.listening;
            if (o) o.count++;
            n.push({
                callback: i,
                context: s,
                ctx: s || a,
                listening: o
            })
        }
        return t
    };
    var c = function(t, e, i, r) {
        try {
            t.on(e, i, r)
        } catch (t) {
            return t
        }
    };
    r.off = function(t, e, i) {
        if (!this._events) return this;
        this._events = u(s, this._events, t, e, {
            context: i,
            listeners: this._listeners
        });
        return this
    };
    r.stopListening = function(t, e, i) {
        var r = this._listeningTo;
        if (!r) return this;
        var n = t ? [t._listenId] : x.keys(r);
        for (var s = 0; s < n.length; s++) {
            var a = r[n[s]];
            if (!a) break;
            a.obj.off(e, i, this);
            if (a.interop) a.off(e, i)
        }
        if (x.isEmpty(r)) this._listeningTo = void 0;
        return this
    };
    var s = function(t, e, i, r) {
        if (!t) return;
        var n = r.context,
            s = r.listeners;
        var a = 0,
            o;
        if (!e && !n && !i) {
            for (o = x.keys(s); a < o.length; a++) {
                s[o[a]].cleanup()
            }
            return
        }
        o = e ? [e] : x.keys(t);
        for (; a < o.length; a++) {
            e = o[a];
            var h = t[e];
            if (!h) break;
            var l = [];
            for (var u = 0; u < h.length; u++) {
                var c = h[u];
                if (i && i !== c.callback && i !== c.callback._callback || n && n !== c.context) {
                    l.push(c)
                } else {
                    var f = c.listening;
                    if (f) f.off(e, i)
                }
            }
            if (l.length) {
                t[e] = l
            } else {
                delete t[e]
            }
        }
        return t
    };
    r.once = function(t, e, i) {
        var r = u(f, {}, t, e, this.off.bind(this));
        if (typeof t === "string" && i == null) e = void 0;
        return this.on(r, e, i)
    };
    r.listenToOnce = function(t, e, i) {
        var r = u(f, {}, e, i, this.stopListening.bind(this, t));
        return this.listenTo(t, r)
    };
    var f = function(t, e, i, r) {
        if (i) {
            var n = t[e] = x.once(function() {
                r(e, n);
                i.apply(this, arguments)
            });
            n._callback = i
        }
        return t
    };
    r.trigger = function(t) {
        if (!this._events) return this;
        var e = Math.max(0, arguments.length - 1);
        var i = Array(e);
        for (var r = 0; r < e; r++) i[r] = arguments[r + 1];
        u(d, this._events, t, void 0, i);
        return this
    };
    var d = function(t, e, i, r) {
        if (t) {
            var n = t[e];
            var s = t.all;
            if (n && s) s = s.slice();
            if (n) v(n, r);
            if (s) v(s, [e].concat(r))
        }
        return t
    };
    var v = function(t, e) {
        var i, r = -1,
            n = t.length,
            s = e[0],
            a = e[1],
            o = e[2];
        switch (e.length) {
            case 0:
                while (++r < n)(i = t[r]).callback.call(i.ctx);
                return;
            case 1:
                while (++r < n)(i = t[r]).callback.call(i.ctx, s);
                return;
            case 2:
                while (++r < n)(i = t[r]).callback.call(i.ctx, s, a);
                return;
            case 3:
                while (++r < n)(i = t[r]).callback.call(i.ctx, s, a, o);
                return;
            default:
                while (++r < n)(i = t[r]).callback.apply(i.ctx, e);
                return
        }
    };
    var p = function(t, e) {
        this.id = t._listenId;
        this.listener = t;
        this.obj = e;
        this.interop = true;
        this.count = 0;
        this._events = void 0
    };
    p.prototype.on = r.on;
    p.prototype.off = function(t, e) {
        var i;
        if (this.interop) {
            this._events = u(s, this._events, t, e, {
                context: void 0,
                listeners: void 0
            });
            i = !this._events
        } else {
            this.count--;
            i = this.count === 0
        }
        if (i) this.cleanup()
    };
    p.prototype.cleanup = function() {
        delete this.listener._listeningTo[this.obj._listenId];
        if (!this.interop) delete this.obj._listeners[this.id]
    };
    r.bind = r.on;
    r.unbind = r.off;
    x.extend(h, r);
    var g = h.Model = function(t, e) {
        var i = t || {};
        e || (e = {});
        this.preinitialize.apply(this, arguments);
        this.cid = x.uniqueId(this.cidPrefix);
        this.attributes = {};
        if (e.collection) this.collection = e.collection;
        if (e.parse) i = this.parse(i, e) || {};
        var r = x.result(this, "defaults");
        i = x.defaults(x.extend({}, r, i), r);
        this.set(i, e);
        this.changed = {};
        this.initialize.apply(this, arguments)
    };
    x.extend(g.prototype, r, {
        changed: null,
        validationError: null,
        idAttribute: "id",
        cidPrefix: "c",
        preinitialize: function() {},
        initialize: function() {},
        toJSON: function(t) {
            return x.clone(this.attributes)
        },
        sync: function() {
            return h.sync.apply(this, arguments)
        },
        get: function(t) {
            return this.attributes[t]
        },
        escape: function(t) {
            return x.escape(this.get(t))
        },
        has: function(t) {
            return this.get(t) != null
        },
        matches: function(t) {
            return !!x.iteratee(t, this)(this.attributes)
        },
        set: function(t, e, i) {
            if (t == null) return this;
            var r;
            if (typeof t === "object") {
                r = t;
                i = e
            } else {
                (r = {})[t] = e
            }
            i || (i = {});
            if (!this._validate(r, i)) return false;
            var n = i.unset;
            var s = i.silent;
            var a = [];
            var o = this._changing;
            this._changing = true;
            if (!o) {
                this._previousAttributes = x.clone(this.attributes);
                this.changed = {}
            }
            var h = this.attributes;
            var l = this.changed;
            var u = this._previousAttributes;
            for (var c in r) {
                e = r[c];
                if (!x.isEqual(h[c], e)) a.push(c);
                if (!x.isEqual(u[c], e)) {
                    l[c] = e
                } else {
                    delete l[c]
                }
                n ? delete h[c] : h[c] = e
            }
            if (this.idAttribute in r) {
                var f = this.id;
                this.id = this.get(this.idAttribute);
                this.trigger("changeId", this, f, i)
            }
            if (!s) {
                if (a.length) this._pending = i;
                for (var d = 0; d < a.length; d++) {
                    this.trigger("change:" + a[d], this, h[a[d]], i)
                }
            }
            if (o) return this;
            if (!s) {
                while (this._pending) {
                    i = this._pending;
                    this._pending = false;
                    this.trigger("change", this, i)
                }
            }
            this._pending = false;
            this._changing = false;
            return this
        },
        unset: function(t, e) {
            return this.set(t, void 0, x.extend({}, e, {
                unset: true
            }))
        },
        clear: function(t) {
            var e = {};
            for (var i in this.attributes) e[i] = void 0;
            return this.set(e, x.extend({}, t, {
                unset: true
            }))
        },
        hasChanged: function(t) {
            if (t == null) return !x.isEmpty(this.changed);
            return x.has(this.changed, t)
        },
        changedAttributes: function(t) {
            if (!t) return this.hasChanged() ? x.clone(this.changed) : false;
            var e = this._changing ? this._previousAttributes : this.attributes;
            var i = {};
            var r;
            for (var n in t) {
                var s = t[n];
                if (x.isEqual(e[n], s)) continue;
                i[n] = s;
                r = true
            }
            return r ? i : false
        },
        previous: function(t) {
            if (t == null || !this._previousAttributes) return null;
            return this._previousAttributes[t]
        },
        previousAttributes: function() {
            return x.clone(this._previousAttributes)
        },
        fetch: function(i) {
            i = x.extend({
                parse: true
            }, i);
            var r = this;
            var n = i.success;
            i.success = function(t) {
                var e = i.parse ? r.parse(t, i) : t;
                if (!r.set(e, i)) return false;
                if (n) n.call(i.context, r, t, i);
                r.trigger("sync", r, t, i)
            };
            G(this, i);
            return this.sync("read", this, i)
        },
        save: function(t, e, i) {
            var r;
            if (t == null || typeof t === "object") {
                r = t;
                i = e
            } else {
                (r = {})[t] = e
            }
            i = x.extend({
                validate: true,
                parse: true
            }, i);
            var n = i.wait;
            if (r && !n) {
                if (!this.set(r, i)) return false
            } else if (!this._validate(r, i)) {
                return false
            }
            var s = this;
            var a = i.success;
            var o = this.attributes;
            i.success = function(t) {
                s.attributes = o;
                var e = i.parse ? s.parse(t, i) : t;
                if (n) e = x.extend({}, r, e);
                if (e && !s.set(e, i)) return false;
                if (a) a.call(i.context, s, t, i);
                s.trigger("sync", s, t, i)
            };
            G(this, i);
            if (r && n) this.attributes = x.extend({}, o, r);
            var h = this.isNew() ? "create" : i.patch ? "patch" : "update";
            if (h === "patch" && !i.attrs) i.attrs = r;
            var l = this.sync(h, this, i);
            this.attributes = o;
            return l
        },
        destroy: function(e) {
            e = e ? x.clone(e) : {};
            var i = this;
            var r = e.success;
            var n = e.wait;
            var s = function() {
                i.stopListening();
                i.trigger("destroy", i, i.collection, e)
            };
            e.success = function(t) {
                if (n) s();
                if (r) r.call(e.context, i, t, e);
                if (!i.isNew()) i.trigger("sync", i, t, e)
            };
            var t = false;
            if (this.isNew()) {
                x.defer(e.success)
            } else {
                G(this, e);
                t = this.sync("delete", this, e)
            }
            if (!n) s();
            return t
        },
        url: function() {
            var t = x.result(this, "urlRoot") || x.result(this.collection, "url") || V();
            if (this.isNew()) return t;
            var e = this.get(this.idAttribute);
            return t.replace(/[^\/]$/, "$&/") + encodeURIComponent(e)
        },
        parse: function(t, e) {
            return t
        },
        clone: function() {
            return new this.constructor(this.attributes)
        },
        isNew: function() {
            return !this.has(this.idAttribute)
        },
        isValid: function(t) {
            return this._validate({}, x.extend({}, t, {
                validate: true
            }))
        },
        _validate: function(t, e) {
            if (!e.validate || !this.validate) return true;
            t = x.extend({}, this.attributes, t);
            var i = this.validationError = this.validate(t, e) || null;
            if (!i) return true;
            this.trigger("invalid", this, i, x.extend(e, {
                validationError: i
            }));
            return false
        }
    });
    var m = h.Collection = function(t, e) {
        e || (e = {});
        this.preinitialize.apply(this, arguments);
        if (e.model) this.model = e.model;
        if (e.comparator !== void 0) this.comparator = e.comparator;
        this._reset();
        this.initialize.apply(this, arguments);
        if (t) this.reset(t, x.extend({
            silent: true
        }, e))
    };
    var w = {
        add: true,
        remove: true,
        merge: true
    };
    var _ = {
        add: true,
        remove: false
    };
    var E = function(t, e, i) {
        i = Math.min(Math.max(i, 0), t.length);
        var r = Array(t.length - i);
        var n = e.length;
        var s;
        for (s = 0; s < r.length; s++) r[s] = t[s + i];
        for (s = 0; s < n; s++) t[s + i] = e[s];
        for (s = 0; s < r.length; s++) t[s + n + i] = r[s]
    };
    x.extend(m.prototype, r, {
        model: g,
        preinitialize: function() {},
        initialize: function() {},
        toJSON: function(e) {
            return this.map(function(t) {
                return t.toJSON(e)
            })
        },
        sync: function() {
            return h.sync.apply(this, arguments)
        },
        add: function(t, e) {
            return this.set(t, x.extend({
                merge: false
            }, e, _))
        },
        remove: function(t, e) {
            e = x.extend({}, e);
            var i = !x.isArray(t);
            t = i ? [t] : t.slice();
            var r = this._removeModels(t, e);
            if (!e.silent && r.length) {
                e.changes = {
                    added: [],
                    merged: [],
                    removed: r
                };
                this.trigger("update", this, e)
            }
            return i ? r[0] : r
        },
        set: function(t, e) {
            if (t == null) return;
            e = x.extend({}, w, e);
            if (e.parse && !this._isModel(t)) {
                t = this.parse(t, e) || []
            }
            var i = !x.isArray(t);
            t = i ? [t] : t.slice();
            var r = e.at;
            if (r != null) r = +r;
            if (r > this.length) r = this.length;
            if (r < 0) r += this.length + 1;
            var n = [];
            var s = [];
            var a = [];
            var o = [];
            var h = {};
            var l = e.add;
            var u = e.merge;
            var c = e.remove;
            var f = false;
            var d = this.comparator && r == null && e.sort !== false;
            var v = x.isString(this.comparator) ? this.comparator : null;
            var p, g;
            for (g = 0; g < t.length; g++) {
                p = t[g];
                var m = this.get(p);
                if (m) {
                    if (u && p !== m) {
                        var _ = this._isModel(p) ? p.attributes : p;
                        if (e.parse) _ = m.parse(_, e);
                        m.set(_, e);
                        a.push(m);
                        if (d && !f) f = m.hasChanged(v)
                    }
                    if (!h[m.cid]) {
                        h[m.cid] = true;
                        n.push(m)
                    }
                    t[g] = m
                } else if (l) {
                    p = t[g] = this._prepareModel(p, e);
                    if (p) {
                        s.push(p);
                        this._addReference(p, e);
                        h[p.cid] = true;
                        n.push(p)
                    }
                }
            }
            if (c) {
                for (g = 0; g < this.length; g++) {
                    p = this.models[g];
                    if (!h[p.cid]) o.push(p)
                }
                if (o.length) this._removeModels(o, e)
            }
            var y = false;
            var b = !d && l && c;
            if (n.length && b) {
                y = this.length !== n.length || x.some(this.models, function(t, e) {
                    return t !== n[e]
                });
                this.models.length = 0;
                E(this.models, n, 0);
                this.length = this.models.length
            } else if (s.length) {
                if (d) f = true;
                E(this.models, s, r == null ? this.length : r);
                this.length = this.models.length
            }
            if (f) this.sort({
                silent: true
            });
            if (!e.silent) {
                for (g = 0; g < s.length; g++) {
                    if (r != null) e.index = r + g;
                    p = s[g];
                    p.trigger("add", p, this, e)
                }
                if (f || y) this.trigger("sort", this, e);
                if (s.length || o.length || a.length) {
                    e.changes = {
                        added: s,
                        removed: o,
                        merged: a
                    };
                    this.trigger("update", this, e)
                }
            }
            return i ? t[0] : t
        },
        reset: function(t, e) {
            e = e ? x.clone(e) : {};
            for (var i = 0; i < this.models.length; i++) {
                this._removeReference(this.models[i], e)
            }
            e.previousModels = this.models;
            this._reset();
            t = this.add(t, x.extend({
                silent: true
            }, e));
            if (!e.silent) this.trigger("reset", this, e);
            return t
        },
        push: function(t, e) {
            return this.add(t, x.extend({
                at: this.length
            }, e))
        },
        pop: function(t) {
            var e = this.at(this.length - 1);
            return this.remove(e, t)
        },
        unshift: function(t, e) {
            return this.add(t, x.extend({
                at: 0
            }, e))
        },
        shift: function(t) {
            var e = this.at(0);
            return this.remove(e, t)
        },
        slice: function() {
            return a.apply(this.models, arguments)
        },
        get: function(t) {
            if (t == null) return void 0;
            return this._byId[t] || this._byId[this.modelId(this._isModel(t) ? t.attributes : t, t.idAttribute)] || t.cid && this._byId[t.cid]
        },
        has: function(t) {
            return this.get(t) != null
        },
        at: function(t) {
            if (t < 0) t += this.length;
            return this.models[t]
        },
        where: function(t, e) {
            return this[e ? "find" : "filter"](t)
        },
        findWhere: function(t) {
            return this.where(t, true)
        },
        sort: function(t) {
            var e = this.comparator;
            if (!e) throw new Error("Cannot sort a set without a comparator");
            t || (t = {});
            var i = e.length;
            if (x.isFunction(e)) e = e.bind(this);
            if (i === 1 || x.isString(e)) {
                this.models = this.sortBy(e)
            } else {
                this.models.sort(e)
            }
            if (!t.silent) this.trigger("sort", this, t);
            return this
        },
        pluck: function(t) {
            return this.map(t + "")
        },
        fetch: function(i) {
            i = x.extend({
                parse: true
            }, i);
            var r = i.success;
            var n = this;
            i.success = function(t) {
                var e = i.reset ? "reset" : "set";
                n[e](t, i);
                if (r) r.call(i.context, n, t, i);
                n.trigger("sync", n, t, i)
            };
            G(this, i);
            return this.sync("read", this, i)
        },
        create: function(t, e) {
            e = e ? x.clone(e) : {};
            var r = e.wait;
            t = this._prepareModel(t, e);
            if (!t) return false;
            if (!r) this.add(t, e);
            var n = this;
            var s = e.success;
            e.success = function(t, e, i) {
                if (r) {
                    t.off("error", this._forwardPristineError, this);
                    n.add(t, i)
                }
                if (s) s.call(i.context, t, e, i)
            };
            if (r) {
                t.once("error", this._forwardPristineError, this)
            }
            t.save(null, e);
            return t
        },
        parse: function(t, e) {
            return t
        },
        clone: function() {
            return new this.constructor(this.models, {
                model: this.model,
                comparator: this.comparator
            })
        },
        modelId: function(t, e) {
            return t[e || this.model.prototype.idAttribute || "id"]
        },
        values: function() {
            return new b(this, S)
        },
        keys: function() {
            return new b(this, I)
        },
        entries: function() {
            return new b(this, k)
        },
        _reset: function() {
            this.length = 0;
            this.models = [];
            this._byId = {}
        },
        _prepareModel: function(t, e) {
            if (this._isModel(t)) {
                if (!t.collection) t.collection = this;
                return t
            }
            e = e ? x.clone(e) : {};
            e.collection = this;
            var i;
            if (this.model.prototype) {
                i = new this.model(t, e)
            } else {
                i = this.model(t, e)
            }
            if (!i.validationError) return i;
            this.trigger("invalid", this, i.validationError, e);
            return false
        },
        _removeModels: function(t, e) {
            var i = [];
            for (var r = 0; r < t.length; r++) {
                var n = this.get(t[r]);
                if (!n) continue;
                var s = this.indexOf(n);
                this.models.splice(s, 1);
                this.length--;
                delete this._byId[n.cid];
                var a = this.modelId(n.attributes, n.idAttribute);
                if (a != null) delete this._byId[a];
                if (!e.silent) {
                    e.index = s;
                    n.trigger("remove", n, this, e)
                }
                i.push(n);
                this._removeReference(n, e)
            }
            if (t.length > 0 && !e.silent) delete e.index;
            return i
        },
        _isModel: function(t) {
            return t instanceof g
        },
        _addReference: function(t, e) {
            this._byId[t.cid] = t;
            var i = this.modelId(t.attributes, t.idAttribute);
            if (i != null) this._byId[i] = t;
            t.on("all", this._onModelEvent, this)
        },
        _removeReference: function(t, e) {
            delete this._byId[t.cid];
            var i = this.modelId(t.attributes, t.idAttribute);
            if (i != null) delete this._byId[i];
            if (this === t.collection) delete t.collection;
            t.off("all", this._onModelEvent, this)
        },
        _onModelEvent: function(t, e, i, r) {
            if (e) {
                if ((t === "add" || t === "remove") && i !== this) return;
                if (t === "destroy") this.remove(e, r);
                if (t === "changeId") {
                    var n = this.modelId(e.previousAttributes(), e.idAttribute);
                    var s = this.modelId(e.attributes, e.idAttribute);
                    if (n != null) delete this._byId[n];
                    if (s != null) this._byId[s] = e
                }
            }
            this.trigger.apply(this, arguments)
        },
        _forwardPristineError: function(t, e, i) {
            if (this.has(t)) return;
            this._onModelEvent("error", t, e, i)
        }
    });
    var y = typeof Symbol === "function" && Symbol.iterator;
    if (y) {
        m.prototype[y] = m.prototype.values
    }
    var b = function(t, e) {
        this._collection = t;
        this._kind = e;
        this._index = 0
    };
    var S = 1;
    var I = 2;
    var k = 3;
    if (y) {
        b.prototype[y] = function() {
            return this
        }
    }
    b.prototype.next = function() {
        if (this._collection) {
            if (this._index < this._collection.length) {
                var t = this._collection.at(this._index);
                this._index++;
                var e;
                if (this._kind === S) {
                    e = t
                } else {
                    var i = this._collection.modelId(t.attributes, t.idAttribute);
                    if (this._kind === I) {
                        e = i
                    } else {
                        e = [i, t]
                    }
                }
                return {
                    value: e,
                    done: false
                }
            }
            this._collection = void 0
        }
        return {
            value: void 0,
            done: true
        }
    };
    var A = h.View = function(t) {
        this.cid = x.uniqueId("view");
        this.preinitialize.apply(this, arguments);
        x.extend(this, x.pick(t, T));
        this._ensureElement();
        this.initialize.apply(this, arguments)
    };
    var P = /^(\S+)\s*(.*)$/;
    var T = ["model", "collection", "el", "id", "attributes", "className", "tagName", "events"];
    x.extend(A.prototype, r, {
        tagName: "div",
        $: function(t) {
            return this.$el.find(t)
        },
        preinitialize: function() {},
        initialize: function() {},
        render: function() {
            return this
        },
        remove: function() {
            this._removeElement();
            this.stopListening();
            return this
        },
        _removeElement: function() {
            this.$el.remove()
        },
        setElement: function(t) {
            this.undelegateEvents();
            this._setElement(t);
            this.delegateEvents();
            return this
        },
        _setElement: function(t) {
            this.$el = t instanceof h.$ ? t : h.$(t);
            this.el = this.$el[0]
        },
        delegateEvents: function(t) {
            t || (t = x.result(this, "events"));
            if (!t) return this;
            this.undelegateEvents();
            for (var e in t) {
                var i = t[e];
                if (!x.isFunction(i)) i = this[i];
                if (!i) continue;
                var r = e.match(P);
                this.delegate(r[1], r[2], i.bind(this))
            }
            return this
        },
        delegate: function(t, e, i) {
            this.$el.on(t + ".delegateEvents" + this.cid, e, i);
            return this
        },
        undelegateEvents: function() {
            if (this.$el) this.$el.off(".delegateEvents" + this.cid);
            return this
        },
        undelegate: function(t, e, i) {
            this.$el.off(t + ".delegateEvents" + this.cid, e, i);
            return this
        },
        _createElement: function(t) {
            return document.createElement(t)
        },
        _ensureElement: function() {
            if (!this.el) {
                var t = x.extend({}, x.result(this, "attributes"));
                if (this.id) t.id = x.result(this, "id");
                if (this.className) t["class"] = x.result(this, "className");
                this.setElement(this._createElement(x.result(this, "tagName")));
                this._setAttributes(t)
            } else {
                this.setElement(x.result(this, "el"))
            }
        },
        _setAttributes: function(t) {
            this.$el.attr(t)
        }
    });
    var H = function(r, t, n, s) {
        switch (t) {
            case 1:
                return function() {
                    return r[n](this[s])
                };
            case 2:
                return function(t) {
                    return r[n](this[s], t)
                };
            case 3:
                return function(t, e) {
                    return r[n](this[s], C(t, this), e)
                };
            case 4:
                return function(t, e, i) {
                    return r[n](this[s], C(t, this), e, i)
                };
            default:
                return function() {
                    var t = a.call(arguments);
                    t.unshift(this[s]);
                    return r[n].apply(r, t)
                }
        }
    };
    var $ = function(i, r, t, n) {
        x.each(t, function(t, e) {
            if (r[e]) i.prototype[e] = H(r, t, e, n)
        })
    };
    var C = function(e, t) {
        if (x.isFunction(e)) return e;
        if (x.isObject(e) && !t._isModel(e)) return M(e);
        if (x.isString(e)) return function(t) {
            return t.get(e)
        };
        return e
    };
    var M = function(t) {
        var e = x.matches(t);
        return function(t) {
            return e(t.attributes)
        }
    };
    var R = {
        forEach: 3,
        each: 3,
        map: 3,
        collect: 3,
        reduce: 0,
        foldl: 0,
        inject: 0,
        reduceRight: 0,
        foldr: 0,
        find: 3,
        detect: 3,
        filter: 3,
        select: 3,
        reject: 3,
        every: 3,
        all: 3,
        some: 3,
        any: 3,
        include: 3,
        includes: 3,
        contains: 3,
        invoke: 0,
        max: 3,
        min: 3,
        toArray: 1,
        size: 1,
        first: 3,
        head: 3,
        take: 3,
        initial: 3,
        rest: 3,
        tail: 3,
        drop: 3,
        last: 3,
        without: 0,
        difference: 0,
        indexOf: 3,
        shuffle: 1,
        lastIndexOf: 3,
        isEmpty: 1,
        chain: 1,
        sample: 3,
        partition: 3,
        groupBy: 3,
        countBy: 3,
        sortBy: 3,
        indexBy: 3,
        findIndex: 3,
        findLastIndex: 3
    };
    var N = {
        keys: 1,
        values: 1,
        pairs: 1,
        invert: 1,
        pick: 0,
        omit: 0,
        chain: 1,
        isEmpty: 1
    };
    x.each([
        [m, R, "models"],
        [g, N, "attributes"]
    ], function(t) {
        var i = t[0],
            e = t[1],
            r = t[2];
        i.mixin = function(t) {
            var e = x.reduce(x.functions(t), function(t, e) {
                t[e] = 0;
                return t
            }, {});
            $(i, t, e, r)
        };
        $(i, x, e, r)
    });
    h.sync = function(t, e, r) {
        var i = j[t];
        x.defaults(r || (r = {}), {
            emulateHTTP: h.emulateHTTP,
            emulateJSON: h.emulateJSON
        });
        var n = {
            type: i,
            dataType: "json"
        };
        if (!r.url) {
            n.url = x.result(e, "url") || V()
        }
        if (r.data == null && e && (t === "create" || t === "update" || t === "patch")) {
            n.contentType = "application/json";
            n.data = JSON.stringify(r.attrs || e.toJSON(r))
        }
        if (r.emulateJSON) {
            n.contentType = "application/x-www-form-urlencoded";
            n.data = n.data ? {
                model: n.data
            } : {}
        }
        if (r.emulateHTTP && (i === "PUT" || i === "DELETE" || i === "PATCH")) {
            n.type = "POST";
            if (r.emulateJSON) n.data._method = i;
            var s = r.beforeSend;
            r.beforeSend = function(t) {
                t.setRequestHeader("X-HTTP-Method-Override", i);
                if (s) return s.apply(this, arguments)
            }
        }
        if (n.type !== "GET" && !r.emulateJSON) {
            n.processData = false
        }
        var a = r.error;
        r.error = function(t, e, i) {
            r.textStatus = e;
            r.errorThrown = i;
            if (a) a.call(r.context, t, e, i)
        };
        var o = r.xhr = h.ajax(x.extend(n, r));
        e.trigger("request", e, o, r);
        return o
    };
    var j = {
        create: "POST",
        update: "PUT",
        patch: "PATCH",
        delete: "DELETE",
        read: "GET"
    };
    h.ajax = function() {
        return h.$.ajax.apply(h.$, arguments)
    };
    var O = h.Router = function(t) {
        t || (t = {});
        this.preinitialize.apply(this, arguments);
        if (t.routes) this.routes = t.routes;
        this._bindRoutes();
        this.initialize.apply(this, arguments)
    };
    var U = /\((.*?)\)/g;
    var z = /(\(\?)?:\w+/g;
    var q = /\*\w+/g;
    var F = /[\-{}\[\]+?.,\\\^$|#\s]/g;
    x.extend(O.prototype, r, {
        preinitialize: function() {},
        initialize: function() {},
        route: function(i, r, n) {
            if (!x.isRegExp(i)) i = this._routeToRegExp(i);
            if (x.isFunction(r)) {
                n = r;
                r = ""
            }
            if (!n) n = this[r];
            var s = this;
            h.history.route(i, function(t) {
                var e = s._extractParameters(i, t);
                if (s.execute(n, e, r) !== false) {
                    s.trigger.apply(s, ["route:" + r].concat(e));
                    s.trigger("route", r, e);
                    h.history.trigger("route", s, r, e)
                }
            });
            return this
        },
        execute: function(t, e, i) {
            if (t) t.apply(this, e)
        },
        navigate: function(t, e) {
            h.history.navigate(t, e);
            return this
        },
        _bindRoutes: function() {
            if (!this.routes) return;
            this.routes = x.result(this, "routes");
            var t, e = x.keys(this.routes);
            while ((t = e.pop()) != null) {
                this.route(t, this.routes[t])
            }
        },
        _routeToRegExp: function(t) {
            t = t.replace(F, "\\$&").replace(U, "(?:$1)?").replace(z, function(t, e) {
                return e ? t : "([^/?]+)"
            }).replace(q, "([^?]*?)");
            return new RegExp("^" + t + "(?:\\?([\\s\\S]*))?$")
        },
        _extractParameters: function(t, e) {
            var i = t.exec(e).slice(1);
            return x.map(i, function(t, e) {
                if (e === i.length - 1) return t || null;
                return t ? decodeURIComponent(t) : null
            })
        }
    });
    var B = h.History = function() {
        this.handlers = [];
        this.checkUrl = this.checkUrl.bind(this);
        if (typeof window !== "undefined") {
            this.location = window.location;
            this.history = window.history
        }
    };
    var J = /^[#\/]|\s+$/g;
    var L = /^\/+|\/+$/g;
    var W = /#.*$/;
    B.started = false;
    x.extend(B.prototype, r, {
        interval: 50,
        atRoot: function() {
            var t = this.location.pathname.replace(/[^\/]$/, "$&/");
            return t === this.root && !this.getSearch()
        },
        matchRoot: function() {
            var t = this.decodeFragment(this.location.pathname);
            var e = t.slice(0, this.root.length - 1) + "/";
            return e === this.root
        },
        decodeFragment: function(t) {
            return decodeURI(t.replace(/%25/g, "%2525"))
        },
        getSearch: function() {
            var t = this.location.href.replace(/#.*/, "").match(/\?.+/);
            return t ? t[0] : ""
        },
        getHash: function(t) {
            var e = (t || this).location.href.match(/#(.*)$/);
            return e ? e[1] : ""
        },
        getPath: function() {
            var t = this.decodeFragment(this.location.pathname + this.getSearch()).slice(this.root.length - 1);
            return t.charAt(0) === "/" ? t.slice(1) : t
        },
        getFragment: function(t) {
            if (t == null) {
                if (this._usePushState || !this._wantsHashChange) {
                    t = this.getPath()
                } else {
                    t = this.getHash()
                }
            }
            return t.replace(J, "")
        },
        start: function(t) {
            if (B.started) throw new Error("Backbone.history has already been started");
            B.started = true;
            this.options = x.extend({
                root: "/"
            }, this.options, t);
            this.root = this.options.root;
            this._trailingSlash = this.options.trailingSlash;
            this._wantsHashChange = this.options.hashChange !== false;
            this._hasHashChange = "onhashchange" in window && (document.documentMode === void 0 || document.documentMode > 7);
            this._useHashChange = this._wantsHashChange && this._hasHashChange;
            this._wantsPushState = !!this.options.pushState;
            this._hasPushState = !!(this.history && this.history.pushState);
            this._usePushState = this._wantsPushState && this._hasPushState;
            this.fragment = this.getFragment();
            this.root = ("/" + this.root + "/").replace(L, "/");
            if (this._wantsHashChange && this._wantsPushState) {
                if (!this._hasPushState && !this.atRoot()) {
                    var e = this.root.slice(0, -1) || "/";
                    this.location.replace(e + "#" + this.getPath());
                    return true
                } else if (this._hasPushState && this.atRoot()) {
                    this.navigate(this.getHash(), {
                        replace: true
                    })
                }
            }
            if (!this._hasHashChange && this._wantsHashChange && !this._usePushState) {
                this.iframe = document.createElement("iframe");
                this.iframe.src = "javascript:0";
                this.iframe.style.display = "none";
                this.iframe.tabIndex = -1;
                var i = document.body;
                var r = i.insertBefore(this.iframe, i.firstChild).contentWindow;
                r.document.open();
                r.document.close();
                r.location.hash = "#" + this.fragment
            }
            var n = window.addEventListener || function(t, e) {
                return attachEvent("on" + t, e)
            };
            if (this._usePushState) {
                n("popstate", this.checkUrl, false)
            } else if (this._useHashChange && !this.iframe) {
                n("hashchange", this.checkUrl, false)
            } else if (this._wantsHashChange) {
                this._checkUrlInterval = setInterval(this.checkUrl, this.interval)
            }
            if (!this.options.silent) return this.loadUrl()
        },
        stop: function() {
            var t = window.removeEventListener || function(t, e) {
                return detachEvent("on" + t, e)
            };
            if (this._usePushState) {
                t("popstate", this.checkUrl, false)
            } else if (this._useHashChange && !this.iframe) {
                t("hashchange", this.checkUrl, false)
            }
            if (this.iframe) {
                document.body.removeChild(this.iframe);
                this.iframe = null
            }
            if (this._checkUrlInterval) clearInterval(this._checkUrlInterval);
            B.started = false
        },
        route: function(t, e) {
            this.handlers.unshift({
                route: t,
                callback: e
            })
        },
        checkUrl: function(t) {
            var e = this.getFragment();
            if (e === this.fragment && this.iframe) {
                e = this.getHash(this.iframe.contentWindow)
            }
            if (e === this.fragment) return false;
            if (this.iframe) this.navigate(e);
            this.loadUrl()
        },
        loadUrl: function(e) {
            if (!this.matchRoot()) return false;
            e = this.fragment = this.getFragment(e);
            return x.some(this.handlers, function(t) {
                if (t.route.test(e)) {
                    t.callback(e);
                    return true
                }
            })
        },
        navigate: function(t, e) {
            if (!B.started) return false;
            if (!e || e === true) e = {
                trigger: !!e
            };
            t = this.getFragment(t || "");
            var i = this.root;
            if (!this._trailingSlash && (t === "" || t.charAt(0) === "?")) {
                i = i.slice(0, -1) || "/"
            }
            var r = i + t;
            t = t.replace(W, "");
            var n = this.decodeFragment(t);
            if (this.fragment === n) return;
            this.fragment = n;
            if (this._usePushState) {
                this.history[e.replace ? "replaceState" : "pushState"]({}, document.title, r)
            } else if (this._wantsHashChange) {
                this._updateHash(this.location, t, e.replace);
                if (this.iframe && t !== this.getHash(this.iframe.contentWindow)) {
                    var s = this.iframe.contentWindow;
                    if (!e.replace) {
                        s.document.open();
                        s.document.close()
                    }
                    this._updateHash(s.location, t, e.replace)
                }
            } else {
                return this.location.assign(r)
            }
            if (e.trigger) return this.loadUrl(t)
        },
        _updateHash: function(t, e, i) {
            if (i) {
                var r = t.href.replace(/(javascript:|#).*$/, "");
                t.replace(r + "#" + e)
            } else {
                t.hash = "#" + e
            }
        }
    });
    h.history = new B;
    var D = function(t, e) {
        var i = this;
        var r;
        if (t && x.has(t, "constructor")) {
            r = t.constructor
        } else {
            r = function() {
                return i.apply(this, arguments)
            }
        }
        x.extend(r, i, e);
        r.prototype = x.create(i.prototype, t);
        r.prototype.constructor = r;
        r.__super__ = i.prototype;
        return r
    };
    g.extend = m.extend = O.extend = A.extend = B.extend = D;
    var V = function() {
        throw new Error('A "url" property or function must be specified')
    };
    var G = function(e, i) {
        var r = i.error;
        i.error = function(t) {
            if (r) r.call(i.context, e, t, i);
            e.trigger("error", e, t, i)
        }
    };
    return h
});