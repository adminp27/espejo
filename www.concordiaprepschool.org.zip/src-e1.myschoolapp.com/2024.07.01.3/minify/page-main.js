(function() {
    function a(b, d, c) {
        this.$ = b;
        this.startEngine = function(e, f) {
            return undefined
        };
        this.init = function(h, g, e, f) {
            onMessage.settings = h;
            onMessage.blocks = e;
            onMessage.CdnUrls = {};
            onMessage.PhotonUrl = "";
            onMessage.CommonUrl = "";
            onMessage.LibrariesUrl = "";
            if (f !== undefined) {
                onMessage.CdnUrls = f;
                onMessage.commonObject = b.grep(f, function(i) {
                    return i.FilePathTypeId === 5
                })[0];
                onMessage.photonObject = b.grep(f, function(i) {
                    return i.FilePathTypeId === 6
                })[0];
                onMessage.librariesObject = b.grep(f, function(i) {
                    return i.FilePathTypeId === 13
                })[0];
                if (onMessage.photonObject !== undefined) {
                    if (onMessage.photonObject.Url !== undefined) {
                        onMessage.PhotonUrl = onMessage.photonObject.Url
                    }
                }
                if (onMessage.commonObject !== undefined) {
                    if (onMessage.commonObject.Url !== undefined) {
                        onMessage.CommonUrl = onMessage.commonObject.Url
                    }
                }
                if (onMessage.librariesObject !== undefined) {
                    if (onMessage.librariesObject.Url !== undefined) {
                        onMessage.LibrariesUrl = onMessage.librariesObject.Url
                    }
                }
            }
            onMessage.log("onMessage Init Started");
            onMessage.log(g, true);
            onMessage.initsCalled = [];
            b(c).ready(function() {
                onMessage.tools.init(onMessage.$);
                onMessage.App.init();
                var i = b("#passwordModal");
                if (i.length > 0) {
                    i.modal({
                        escClose: false,
                        autoResize: true,
                        opacity: 75,
                        overlayCss: {
                            backgroundColor: "#A9A9A9"
                        },
                        position: ["50px"],
                        containerCss: {
                            "max-width": "700px"
                        },
                        zIndex: 500000009
                    });
                    if (!b("#passwordModal #btnPasswordCheck").hasClass("disabled")) {
                        b("#passwordModal #btnPasswordCheck").addClass("disabled");
                        b("#txtPassword").on("keyup", function(l) {
                            l.preventDefault();
                            if (l.currentTarget.value.length == 0) {
                                b("#passwordModal #btnPasswordCheck").addClass("disabled")
                            } else {
                                b("#passwordModal #btnPasswordCheck").removeClass("disabled")
                            }
                        })
                    } else {
                        c.getElementById("txtPassword").disabled = true
                    }
                }
                if (!i.length > 0) {
                    if (!b("body").hasClass("sample-data") && c.getElementById("tmpl-page") == null) {
                        var k = onMessage.tools.getParameterByName("siteid"),
                            j = onMessage.App.module("EmergencyBulletin");
                        j.Utilities.processEmergencyBulletins(k)
                    }
                }
                onMessage.sizePhotos();
                onMessage.sizeIframes();
                onMessage.resizeIframesPollHeight();
                b(d).resize(function() {
                    onMessage.sizePhotos();
                    onMessage.resizeIframes();
                    onMessage.fixRegion()
                });
                onMessage.tools.listenForWindowMessage(onMessage.listenForInquiryResize);
                onMessage.tools.listenForWindowMessage(onMessage.listenForAddTrackingCode);
                b("#layout_region_0").on("onMessage.ContentLoaded", function() {
                    onMessage.fixRegion();
                    var l = d.location.hash.indexOf("giving");
                    if (l < 0) {
                        onMessage.scrollSpyInit()
                    }
                    onMessage.animationInit();
                    onMessage.fixPageLinks()
                });
                onMessage.ContentInit(g)
            });
            onMessage.log(onMessage.initsCalled);
            onMessage.log("onMessage Finished")
        };
        this.animationInit = function() {
            var e = b(".region, .row, .page-block, .layout-block, .group"),
                f = false;
            onMessage.tools.checkViewStatus(e);
            b(d).on("scroll", function() {
                f = true
            });
            setInterval(function() {
                if (f) {
                    f = false;
                    onMessage.tools.checkViewStatus(e)
                }
            }, 250)
        };
        this.scrollSpyInit = function() {
            var e = b("nav ul li.scrollspy-item a[href*='#']"),
                f = false;
            if (e.length > 0) {
                e.on("click", function(g) {
                    g.preventDefault();
                    onMessage.scrollSpy(b(this), this.hash.substring(1))
                });
                b(d).load(function() {
                    if (d.location.hash.length > 0) {
                        e.filter(function(g) {
                            return (b(this).prop("hash") === d.location.hash)
                        }).click()
                    }
                });
                b(d).on("scroll", function() {
                    f = true
                });
                setInterval(function() {
                    if (f) {
                        f = false;
                        onMessage.scrollSpyCheck()
                    }
                }, 250)
            }
        };
        this.getFixedHeaderHeight = function() {
            var f = 0,
                e = b("*").filter(function() {
                    return (b(this).css("position") === "fixed" && b(this).css("top") === "0px" && b(this).prop("tagName") !== "IFRAME")
                });
            f = e.length > 0 ? e[0].offsetHeight : 0;
            return f
        };
        this.scrollSpyCheck = function() {
            var g = b("*[data_scrollspy]"),
                i, f, l = 10,
                h = onMessage.getFixedHeaderHeight(),
                e = "";
            e = g.filter(function() {
                var p = b(this).closest(".layout-region").offset().top,
                    m = p + b(this).closest(".layout-region").outerHeight(),
                    o = b(d).scrollTop(),
                    n = false;
                if ((b(this).siblings().find("*[data_scrollspy]").length < 1) && (b(this).closest(".layout-region").siblings().find("*[data_scrollspy]").length < 1)) {
                    p = b(this).closest(".layout-row").offset().top;
                    m = p + b(this).closest(".layout-row").outerHeight()
                }
                o = o < h ? o : o + h;
                n = (o + l >= p && o + l < m);
                return n
            });
            if (e.length > 0) {
                i = e.attr("data_scrollspy");
                f = b("nav ul li a[href*='#" + i + "']").closest("li");
                f.closest("ul").find("li").removeClass("active");
                f.addClass("active");
                d.location.hash = "#" + i
            } else {
                b("nav ul li a[href*='#']").closest("ul").find("li").removeClass("active");
                var k = new RegExp(/(photo|video|audio)/),
                    j = d.location.hash.match(k);
                if (j == null) {
                    d.location.hash = "#/"
                }
            }
        };
        this.scrollSpy = function(e, h) {
            var k = b("*[data_scrollspy=" + h + "]").closest(".layout-region").offset().top,
                f = 5,
                g = onMessage.getFixedHeaderHeight(),
                j = b(d).scrollTop(),
                i = (b("*[data_scrollspy=" + h + "]").siblings().find("*[data_scrollspy]").length < 1) && (b("*[data_scrollspy=" + h + "]").closest(".layout-region").siblings().find("*[data_scrollspy]").length < 1) ? true : false;
            if (i) {
                k = b("*[data_scrollspy=" + h + "]").closest(".layout-row").offset().top
            }
            k = k < g ? k : k - g;
            if (Math.round(j) === Math.round(k)) {
                e.closest("ul").find("li").removeClass("active");
                e.closest("li").addClass("active")
            }
            b("html,body").animate({
                scrollTop: k
            }, 1000, "easeOutCirc", function() {
                g = onMessage.getFixedHeaderHeight();
                k = i ? b("*[data_scrollspy=" + h + "]").closest(".layout-row").offset().top : b("*[data_scrollspy=" + h + "]").closest(".layout-region").offset().top;
                k = k < g ? k : k - g;
                j = b(d).scrollTop();
                if (j < k - f || j > k + f) {
                    b("html,body").animate({
                        scrollTop: k
                    }, 500, "easeOutCirc")
                }
                d.location.hash = "#" + h
            })
        };
        this.fixRegion = function() {
            onMessage.log("Begin Fix Region");
            onMessage.hasFixedHeader = false;
            var h = b(".fixed-region"),
                g = h.next(),
                m = b(d).width(),
                e = b(".emergencybulletinbanner").closest(".page-block"),
                f = b(".cookieconsentbanner").closest(".page-block"),
                k = e.length > 0,
                l = f.length > 0,
                j = h.outerHeight(),
                i = 0;
            if (h.length > 0 && m > 979) {
                onMessage.hasFixedHeader = true;
                if (k) {
                    e.addClass("fixed-bulletin").css({
                        "z-index": "2000"
                    });
                    i = e.outerHeight();
                    j += i;
                    e.find(".close").on("click", function() {
                        onMessage.fixRegion()
                    })
                }
                h.css({
                    top: i + "px"
                });
                onMessage.fixedHeaderHeight = j;
                onMessage.log("Fix Region Height:" + j);
                g.css({
                    "margin-top": j + "px"
                })
            } else {
                if (g.length > 0) {
                    g.css({
                        "margin-top": "0px"
                    })
                }
                if (k) {
                    e.removeClass("fixed-bulletin")
                }
            }
            onMessage.log("End Fix Region");
            if (l) {
                f.addClass("fixed-cookie").css({
                    "z-index": "2000"
                });
                f.find(".close").on("click", function() {
                    onMessage.fixRegion()
                })
            } else {
                if (l) {
                    f.removeClass("fixed-cookie")
                }
            }
        };
        this.FindMethod = function(e) {
            return function(f) {
                return f.id === e.StyleTypeId
            }
        };
        this.ContentInit = function(j) {
            onMessage.log("Begin Content Init");
            var h = [{
                    id: 0,
                    name: "logo",
                    blockInitalizer: onMessage.blockInit
                }, {
                    id: 1,
                    name: "block",
                    blockInitalizer: onMessage.blockInit
                }, {
                    id: 2,
                    name: "menu",
                    blockInitalizer: onMessage.menuInit
                }, {
                    id: 3,
                    name: "carousel",
                    blockInitalizer: onMessage.carouselInit
                }, {
                    id: 4,
                    name: "global",
                    blockInitalizer: onMessage.blockInit
                }, {
                    id: 5,
                    name: "area",
                    blockInitalizer: onMessage.blockInit
                }, {
                    id: 8,
                    name: "cookieconsent",
                    blockInitalizer: onMessage.blockInit
                }, {
                    id: 9,
                    name: "skiptocontent",
                    blockInitializer: onMessage.blockInit
                }],
                e = j.slice(0),
                g;
            for (g = j.length - 1; g >= 0; g--) {
                if (j[g].StyleTypeId === 3) {
                    j.splice(g, 1)
                }
            }
            for (g = e.length - 1; g >= 0; g--) {
                if (e[g].StyleTypeId !== 3) {
                    e.splice(g, 1)
                }
            }
            for (g = 0; g < j.length; g++) {
                try {
                    h.filter(onMessage.FindMethod(j[g]))[0].blockInitalizer.call(h.filter(onMessage.FindMethod(j[g]))[0].blockInitalizer, j[g], b)
                } catch (f) {
                    onMessage.log("Error: " + f.message)
                }
            }
            onMessage.mobilemenu.init(b);
            onMessage.carouselInit.call(onMessage.carouselInit, e, b);
            b("#layout_region_0").trigger("onMessage.ContentLoaded");
            setTimeout(function() {
                onMessage.tools.fixVideoIE();
                onMessage.tools.fixVideoLoad()
            }, 500);
            onMessage.log("End Content Init")
        };
        this.blockInit = function(e) {
            if (b.inArray(e.content, onMessage.initsCalled) === -1) {
                switch (e.content) {
                    case "sitemap":
                        onMessage.sitemap.init(b);
                        break;
                    case "annualfund":
                        onMessage.annualfund.init(b);
                        break;
                    case "photo":
                        break;
                    case "facultystaffdirectory":
                        onMessage.facultyDirectory.init(b);
                        break;
                    case "video":
                        onMessage.video.init(b);
                        break;
                    case "forms":
                        onMessage.formsDetail.init.call(onMessage.forms, b);
                        break;
                    case "cookieconsentbanner":
                        onMessage.cookieConsentBanner.init(b);
                        break;
                    case "audio":
                        onMessage.audio.init(b);
                        break;
                    case "search":
                    case "searchresults":
                        onMessage.search.init(b);
                        break;
                    case "poll":
                        onMessage.poll.init(b);
                        break;
                    case "athleticrecentgames":
                        onMessage.athleticrecentgames.init(b);
                        break;
                    case "storeproducts":
                        onMessage.storeproducts.init(b);
                        break;
                    case "newsarchivedatepicker":
                        onMessage.newsarchivedatepicker.init(b);
                        break;
                    case "newsarchivefilter":
                        onMessage.newsarchivefilter.init(b);
                        break;
                    case "newscommententry":
                        onMessage.forms.init(b);
                        break;
                    case "calendargrid":
                        onMessage.calendargrid.init(b);
                        break;
                    case "trivia":
                        onMessage.trivia.init(b);
                        break;
                    case "skiptocontent":
                        onMessage.skipToContent.init(b);
                        break;
                    case "athleticteamschedulenew":
                        onMessage.athleticteamschedulenew.init(b);
                        break;
                    case "athleticteamnavigation":
                        onMessage.athleticteamnavigation.init(b);
                        break
                }
                onMessage.initsCalled.push(e.content)
            }
        };
        this.menuInit = function(e) {
            onMessage.log("menuinit called");
            onMessage.log(e);
            var f = [{
                name: "dropdown-flyout",
                pluginInitalizer: onMessage.menu
            }, {
                name: "horizontal",
                pluginInitalizer: onMessage.horizontalMenu
            }, {
                name: "accordion",
                pluginInitalizer: onMessage.accordionMenu
            }, {
                name: "dropdown-flyout",
                pluginInitalizer: onMessage.menu
            }, {
                name: "mega",
                pluginInitalizer: onMessage.megaMenu
            }];
            if (b.inArray(f[e.StyleModeId - 1].name, onMessage.initsCalled) === -1) {
                f[e.StyleModeId - 1].pluginInitalizer.init.call(f[e.StyleModeId - 1].pluginInitalizer.init, b);
                onMessage.log(f[e.StyleModeId - 1].name);
                onMessage.initsCalled.push(f[e.StyleModeId - 1].name)
            }
            onMessage.log(onMessage.initsCalled)
        };
        this.carouselInit = function(e) {
            var f, g;
            onMessage.log("new carousel init");
            onMessage.log(e);
            g = function() {
                var k = false,
                    j = false,
                    i, h;
                for (f = e.length - 1; f >= 0; f--) {
                    if (e[f].StyleModeId < 5) {
                        k = true
                    }
                    if (e[f].StyleModeId == 5) {
                        j = true
                    }
                }
                if (k) {
                    onMessage.log("carousel script loaded");
                    i = b(".carousel");
                    if (i.length > 0) {
                        i.each(function() {
                            var l = b(this);
                            l.carousel()
                        })
                    }
                }
                if (j) {
                    h = b(".background-carousel");
                    if (h.length > 0) {
                        h.bgcarousel()
                    }
                }
            };
            g()
        };
        this.log = function(e, f) {
            if (d.console !== undefined && (onMessage.tools.getParameterByName("debug") == "true")) {
                if (f) {
                    d.console.table(e)
                } else {
                    d.console.log(e)
                }
            }
        };
        this.tools = {
            recaptchaCount: 0,
            init: function(e) {
                var f, h, g;
                e(".mailto").on("click", function(j) {
                    var i = e(this),
                        k = i.attr("href");
                    if (!i.hasClass("prevented")) {
                        if (i.hasClass("mailto")) {
                            j.preventDefault();
                            i.addClass("prevented");
                            k = "mailto:" + k.replace(/[a-zA-Z]/g, function(l) {
                                var m = l.charCodeAt(0) + 13;
                                return String.fromCharCode((l <= "Z" ? 90 : 122) >= m ? m : m - 26)
                            });
                            i.attr("href", k);
                            d.location.href = k
                        }
                    }
                });
                e(".expand").on("click", function(l) {
                    l.preventDefault();
                    var i = e(this),
                        j = i.parent(),
                        m = "#" + i.attr("rel"),
                        k;
                    if (j.find(m).length === 1) {
                        k = j.find(m)
                    } else {
                        k = j.parent().find(m)
                    }
                    if (!i.hasClass("sample-template")) {
                        if (!k.is(":visible")) {
                            k.slideDown(250);
                            j.addClass("on-state");
                            j.removeClass("off-state");
                            if (!i.hasClass("no-replace")) {
                                i.data("old-btn-text", i.html()).html("close")
                            }
                        } else {
                            k.slideUp(250);
                            j.addClass("off-state");
                            j.removeClass("on-state");
                            if (!i.hasClass("no-replace")) {
                                i.html(i.data("old-btn-text"))
                            }
                        }
                    }
                });
                e(".newscommententry .submit-button").on("click", function(k) {
                    k.preventDefault();
                    var i = e(this),
                        m = i.data("id"),
                        j = i.data("cid"),
                        l = onMessage.App.module("NewsComments");
                    if (!i.hasClass("styler")) {
                        l.Utilities.postComment(m, j)
                    }
                });
                e(".newscommentlist .sort-button").on("click", function(j) {
                    j.preventDefault();
                    var i = e(this),
                        k = e(".news-comment-list");
                    if (!i.hasClass("styler")) {
                        k.children().each(function(l, m) {
                            k.prepend(m)
                        })
                    }
                });
                e(".athleticteamschedule .schedule-directions, .athletic-event .calendar-directions, .athleticupcominggames .schedule-directions, .athleticteamschedulenew .schedule-directions").on("click", function(k) {
                    if (!e("body").hasClass("sample-data")) {
                        k.preventDefault();
                        var i = e(this),
                            m = i.data("scheduleid"),
                            n = i.data("showtrans"),
                            l = i.data("practice"),
                            j = onMessage.App.module("AthleticSchedule");
                        if (!i.hasClass("styler")) {
                            j.Utilities.showDirections(m, n, l)
                        }
                    }
                });
                e(".athleticteamrosternew .athlete-user").on("click", function(l) {
                    if (!e("body").hasClass("sample-data")) {
                        l.preventDefault();
                        var i = e(this),
                            j = i.data("athleteid"),
                            m = i.data("sectionid"),
                            k = onMessage.App.module("AthleticRoster");
                        k.Utilities.showAthleteDetails(j, m)
                    }
                });
                e(".athleticteamrosternew .athlete-user").on("click", function(l) {
                    if (!e("body").hasClass("sample-data")) {
                        l.preventDefault();
                        var i = e(this),
                            j = i.data("athleteid"),
                            m = i.data("sectionid"),
                            k = onMessage.App.module("AthleticRoster");
                        k.Utilities.showAthleteDetails(j, m)
                    }
                });
                e(".mini-sitemap:not(.sample-template) .toggle").on("click", function(l) {
                    l.preventDefault();
                    var j = e(this),
                        i = j.closest("nav"),
                        k = j.next("ul");
                    if (i.attr("state") === "open") {
                        i.attr("state", "closed");
                        k.slideUp();
                        j.html(i.attr("toggle_open")).addClass("mini-sitemap-open").removeClass("mini-sitemap-close")
                    } else {
                        i.attr("state", "open");
                        k.slideDown(400, function() {
                            e("body,html").animate({
                                scrollTop: e(c).height() - e(d).height()
                            }, 400)
                        });
                        j.html(i.attr("toggle_close")).addClass("mini-sitemap-close").removeClass("mini-sitemap-open")
                    }
                });
                h = ".team-list a";
                e(h).on("click", function(i) {
                    i.preventDefault();
                    if (e(this).closest("html").hasClass("styler")) {
                        return false
                    }
                    var j = e(this).attr("href"),
                        k = onMessage.tools.getParameterByName("siteid");
                    if (isNaN(k)) {
                        if (k.length > 0) {
                            j += "&siteid=" + k
                        }
                    }
                    d.location = j;
                    return false
                });
                e(".print-roster-button").on("click", onMessage.tools.printRoster);
                e(".print-schedule-button").on("click", onMessage.tools.printSchedule);
                e(".print-button").on("click", onMessage.tools.printScheduleOld);
                e(".lazy-load").on("click", function(n) {
                    n.preventDefault();
                    var i = e(this),
                        j = i.data("blockid"),
                        m = parseInt(i.data("pagecount"), 10),
                        o = parseInt(i.data("marker"), 10) + m,
                        l = i.data("container"),
                        p = i.data("running"),
                        k = i.data("cachekey"),
                        q = onMessage.tools.getUrlParams();
                    if (i.closest("html").hasClass("styler")) {
                        return false
                    }
                    if (!p) {
                        i.data("running", true);
                        e.ajax({
                            url: q.base + "?lazyLoad=true&blockid=" + j + "&marker=" + o + "&ck=" + k + q.querystring,
                            context: c.body
                        }).done(function(u) {
                            var r = e(u),
                                t = r.find(".content").html(),
                                s = r.find("[data-cachekey]").data("cachekey"),
                                v = (r.find("[data-cachekey]").data("more-albums") === "True") ? true : false;
                            e("." + l).append(t);
                            if (!v) {
                                i.hide()
                            }
                            i.data("marker", o);
                            i.data("cachekey", s);
                            i.data("running", false)
                        })
                    }
                    return false
                });
                f = ".photo .album-select, .audio .album-select, .video .album-select";
                e(f).change(function(i) {
                    i.preventDefault();
                    d.location.href = onMessage.tools.getUrlForAlbumSelect(e(this));
                    return false
                });
                g = e(".obscure-email");
                _.each(g, function(i, j) {
                    e(i).on("click", function(k) {
                        k.preventDefault();
                        try {
                            d.location.href = "mailto:" + e(this).attr("data-username") + "@" + e(this).attr("data-domain");
                            return false
                        } catch (l) {
                            return false
                        }
                    })
                });
                e("#passModalClose, #passModalCancel").on("click", function(i) {
                    var k = parseInt(c.getElementById("totalPAttempts").value, 10),
                        j = k + 1;
                    i.preventDefault();
                    history.go("-" + j)
                });
                e(".departmentpicker #LevelNum").on("change", function(i) {
                    var j, k, l = onMessage.tools.getUrlParams() || {};
                    if (l.params && l.params.GradeId && l.params.GradeId.length > 0) {
                        k = l.querystring.replace("GradeId=" + l.params.GradeId, "GradeId=");
                        if (i.target.value && l.params.LevelNum && l.params.LevelNum.length > 0) {
                            k = k.replace("LevelNum=" + l.params.LevelNum, "LevelNum=" + i.target.value)
                        }
                        j = "?" + k.substring(1);
                        location.href = j
                    }
                })
            },
            printRoster: function() {
                var j = c.getElementById("athletic-roster-data"),
                    h = j.cloneNode(true),
                    e = h.getElementsByClassName("column-1");
                for (var f = e.length - 1; 0 <= f; f--) {
                    e[f].parentElement.removeChild(e[f])
                }
                b(h).find("th").css({
                    "text-align": "left"
                });
                b(h).find("a").css({
                    color: "inherit",
                    "text-decoration": "inherit"
                });
                var g = d.document.getElementById("roster-iframe");
                if (g) {
                    g.parentElement.removeChild(g)
                }
                b("<iframe>", {
                    id: "roster-iframe",
                    name: "rosteriframe",
                    style: "display:none;"
                }).appendTo("body").contents().find("body").append(h);
                if (d.head.browser.ie) {
                    d.parent.document.getElementById("roster-iframe").contentWindow.focus();
                    d.parent.document.getElementById("roster-iframe").contentWindow.print()
                } else {
                    d.frames.rosteriframe.focus();
                    d.frames.rosteriframe.print()
                }
                return false
            },
            printSchedule: function() {
                var g = c.getElementById("athletic-schedule-data"),
                    f = g.cloneNode(true);
                b(f).find(".classification-col, .category-col").css("display", "table-cell");
                b(f).find("a").css({
                    color: "inherit",
                    "text-decoration": "inherit"
                });
                b(f).find("th").css({
                    "text-align": "left"
                });
                var e = d.document.getElementById("schedule-Iframe");
                if (e) {
                    e.parentElement.removeChild(e)
                }
                b("<iframe>", {
                    id: "schedule-Iframe",
                    name: "scheduleIframe",
                    style: "display:none;"
                }).appendTo("body").contents().find("body").append(f);
                if (d.head.browser.ie) {
                    d.parent.document.getElementById("schedule-Iframe").contentWindow.focus();
                    d.parent.document.getElementById("schedule-Iframe").contentWindow.print()
                } else {
                    d.frames.scheduleIframe.focus();
                    d.frames.scheduleIframe.print()
                }
                return false
            },
            printScheduleOld: function() {
                var h = c.getElementsByClassName("athleticteamschedule")[0],
                    g = h.cloneNode(true);
                b(g).find(".print-button").remove(".print-button");
                b(g).find(".directions-link").remove();
                b(g).find("h1:first").remove();
                b(g).css({
                    width: "600px",
                    margin: "20px auto"
                });
                b(g).find(".game").css({
                    "margin-bottom": "15px",
                    "padding-bottom": "5px",
                    "border-bottom": "2px solid #000"
                });
                b(g).find(".game .schedule-result").css({
                    "float": "right"
                });
                if (d.head.browser.ff) {
                    var f = d.open("");
                    f.document.write(g.innerHTML);
                    f.stop();
                    f.print();
                    f.close()
                } else {
                    var e = d.document.getElementById("oldSchedule-Iframe");
                    if (e) {
                        e.parentElement.removeChild(e)
                    }
                    b("<iframe>", {
                        id: "oldSchedule-Iframe",
                        name: "oldScheduleIframe",
                        style: "display:none;"
                    }).appendTo("body").contents().find("body").append(g);
                    if (d.head.browser.ie) {
                        d.parent.document.getElementById("oldSchedule-Iframe").contentWindow.focus();
                        d.parent.document.getElementById("oldSchedule-Iframe").contentWindow.print()
                    } else {
                        d.frames.oldScheduleIframe.focus();
                        d.frames.oldScheduleIframe.print()
                    }
                }
                return false
            },
            checkViewStatus: function(e) {
                e.each(function() {
                    var f = b(this),
                        g = onMessage.tools.getElementInfo(f);
                    f.toggleClass("in-view", g.inView);
                    f.toggleClass("top-of-page", g.topOfPage);
                    f.toggleClass("bottom-of-page", g.bottomOfPage);
                    f.toggleClass("center-of-page", g.midCenterOfPage);
                    f.toggleClass("top-center-of-page", g.topCenterOfPage);
                    if (f.hasClass("bottom-of-page")) {
                        f.addClass("has-been-viewed")
                    }
                    if (f.hasClass("center-of-page")) {
                        f.addClass("center-has-been-viewed")
                    }
                })
            },
            getElementInfo: function(f) {
                var e = {
                        pageTop: b(d).scrollTop(),
                        pageBottom: b(d).scrollTop() + b(d).height(),
                        pageCenterTop: b(d).scrollTop() + ((b(d).height() / 2) - 50),
                        pageCenterbottom: b(d).scrollTop() + ((b(d).height() / 2) + 50),
                        elementTop: b(f).offset().top,
                        elementBottom: b(f).offset().top + b(f).outerHeight(),
                        elementCenter: b(f).offset().top + (b(f).outerHeight() / 2)
                    },
                    g = {};
                g.inView = (e.elementTop <= e.pageBottom) && (e.elementBottom >= e.pageTop);
                g.topOfPage = g.inView && e.pageTop >= e.elementTop;
                g.bottomOfPage = g.inView && e.pageBottom >= e.elementBottom;
                g.midCenterOfPage = (e.elementCenter <= e.pageCenterbottom) && (e.elementCenter >= e.pageCenterTop);
                g.topCenterOfPage = (e.elementTop <= e.pageCenterbottom) && (e.elementTop >= e.pageCenterTop);
                return g
            },
            getUrlForAlbumSelect: function(e) {
                var f = onMessage.tools.getUrlParams({
                    exclude: ["albumid"]
                });
                return f.base + "?albumid=" + e.val() + f.querystring
            },
            getParameterByName: function(f) {
                var e = (new RegExp("[?&]" + f + "=([^&]*)", "i")).exec(d.location.search);
                return e && decodeURIComponent(e[1].replace(/\+/g, " "))
            },
            getRandomNumberBetween: function(f, e) {
                return Math.round(Math.random() * (e - f)) + f
            },
            setCookie: function(e, h, g) {
                var f = new Date();
                f.setDate(f.getDate() + g);
                c.cookie = e + "=" + escape(h) + ((g == null) ? "" : ";expires=" + f.toGMTString()) + "; path=/"
            },
            getCookie: function(f) {
                if (c.cookie.length > 0) {
                    var g = c.cookie.indexOf(f + "="),
                        e;
                    if (g != -1) {
                        g = g + f.length + 1;
                        e = c.cookie.indexOf(";", g);
                        if (e == -1) {
                            e = c.cookie.length
                        }
                        return unescape(c.cookie.substring(g, e))
                    }
                }
                return ""
            },
            scrollTop: function() {
                b("html, body").animate({
                    scrollTop: 0
                }, "normal")
            },
            setFrameHeight: function(g) {
                try {
                    var f = g.contents().find("BODY"),
                        i = f.outerHeight() + 100;
                    g.css({
                        height: i + "px"
                    });
                    if (i === 100) {
                        g.attr("scrolling", "yes")
                    }
                } catch (h) {
                    g.css({
                        height: "2000px"
                    });
                    g.attr("scrolling", "yes")
                }
            },
            getUrlParams: function(j) {
                var q = d.location.href,
                    e = q.split("?")[0],
                    l = q.split("?")[1],
                    g = {},
                    n = "",
                    k = {
                        exclude: []
                    },
                    h, f, p, m;
                b.extend(true, k, j);
                e = e.replace("#", "");
                if (l === undefined) {
                    return {
                        base: e,
                        querystring: ""
                    }
                }
                if (l.length > 0) {
                    h = l.split("&");
                    for (f = 0; f < h.length; f++) {
                        p = h[f].split("=");
                        if (b.inArray(p[0], k.exclude) === -1) {
                            g[p[0]] = p[1]
                        }
                    }
                }
                for (m in g) {
                    if (g.hasOwnProperty(m)) {
                        n += "&" + m + "=" + g[m]
                    }
                }
                return {
                    base: e,
                    querystring: n,
                    params: g
                }
            },
            redirectWindow: function(e) {
                d.location.href = e
            },
            hideElement: function(e) {
                jQuery(e).hide()
            },
            listenForWindowMessage: function(h, e) {
                var g = d.addEventListener ? "addEventListener" : "attachEvent",
                    f = d[g],
                    i = (g === "attachEvent") ? "onmessage" : "message";
                f(i, function(j) {
                    h.call(e || this, j)
                }, false)
            },
            removeWindowMessageListener: function(g) {
                var f = d.removeEventListener ? "removeEventListener" : "detachEvent",
                    e = d[f],
                    h = (f === "detachEvent") ? "onmessage" : "message";
                e(h, g)
            },
            showCookieConsent: function(g) {
                var e = parseInt(decodeURI(this.getCookie(g)), 10),
                    f = b(".cookieconsent-item").data("ccid"),
                    h = false;
                if (e !== f) {
                    h = true
                }
                return h
            },
            getReCaptchaKey: function(e) {
                b.post(onMessage.App.Config.ApiPath + "Captcha/GetReCaptchaKey", {
                    message: "raw"
                }, function(f) {
                    setTimeout(function() {
                        e.append('<div class="g-recaptcha" id="grecaptcha-' + onMessage.tools.recaptchaCount + '"></div>');
                        grecaptcha.render("grecaptcha-" + onMessage.tools.recaptchaCount, {
                            sitekey: f.SiteKey
                        });
                        onMessage.tools.recaptchaCount++
                    }, 500)
                }, "json").fail(function(g, h, f) {
                    onMessage.log("error : " + h + " : " + f)
                })
            },
            detectIE: function() {
                var i = d.navigator.userAgent,
                    f = i.indexOf("MSIE "),
                    h = i.indexOf("Trident/"),
                    e = i.indexOf("Edge/"),
                    g;
                if (f > 0) {
                    return parseInt(i.substring(f + 5, i.indexOf(".", f)), 10)
                }
                if (h > 0) {
                    g = i.indexOf("rv:");
                    return parseInt(i.substring(g + 3, i.indexOf(".", g)), 10)
                }
                if (e > 0) {
                    return parseInt(i.substring(e + 5, i.indexOf(".", e)), 10)
                }
                return false
            },
            fixVideoLoad: function() {
                c.querySelectorAll("video:not([src]), video[src='']").forEach(function(e) {
                    videojs(e)
                })
            },
            fixVideoIE: function() {
                var f = onMessage.tools.detectIE(),
                    e;
                if (f >= 11) {
                    e = b(".aws-player");
                    e.each(function() {
                        var g = b(this),
                            o = g.attr("id"),
                            k = g.attr("poster") || "",
                            m = g.data("transcript") || "",
                            j = g.data("mp4"),
                            l = g.attr("data-setup"),
                            i = (g.closest("html").hasClass("ismodal")) ? 'autoplay="true"' : "",
                            n, h = g.parent();
                        n = "<video";
                        n += ' style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;"';
                        n += ' id="' + o + '"';
                        n += ' class="video-js vjs-default-skin vjs-big-play-centered aws-player"';
                        n += " controls " + i + ' preload="none"';
                        n += ' poster="' + k + '"';
                        if (g.attr("loop")) {
                            n += ' loop="' + g.attr("loop") + '"'
                        }
                        if (g.attr("muted")) {
                            n += ' muted="' + g.attr("muted") + '"'
                        }
                        if (g.attr("autoplay")) {
                            n += ' autoplay="true" '
                        }
                        n += ">";
                        n += '<source src="//' + j + '" type="video/mp4">';
                        if (m.length > 0) {
                            n += '<track kind="captions" src="' + m + '" label="Captions" default>'
                        }
                        n += "</video>";
                        videojs(o).pause().dispose();
                        h.append(n);
                        b("#" + o).attr("data-setup", l);
                        videojs(o, {}, function() {
                            videojs.initShareing()
                        })
                    })
                }
            }
        };
        this.findBlock = function(e) {
            return _.find(onMessage.blocks, function(f) {
                return f.ClientId == e
            })
        };
        this.pluginManager = {
            plugins: {
                FancyBox: {
                    Url: "{libs_url}/jquery-fancybox/1.3.3/jquery.fancybox-1.3.3.js",
                    Css: "{libs_url}/jquery-fancybox/1.3.3/jquery.fancybox-1.3.3.css",
                    isLoaded: function() {
                        return jQuery.fancybox
                    }
                }
            },
            load: function(h, e, g) {
                if (typeof h.isLoaded === "function") {
                    if (h.isLoaded()) {
                        return e(g)
                    }
                }
                var j = h.Url,
                    i, f;
                if (h.SslUrl && location.protocol === "https:") {
                    j = h.SslUrl
                }
                i = j.split(",");
                for (f = 0; f < i.length; f++) {
                    i[f] = i[f].replace("{libs_url}", onMessage.LibrariesUrl);
                    if (i[f].indexOf("ftpimages") > -1) {
                        i[f] = onMessage.CommonUrl + i[f]
                    }
                }
                i.push(function() {
                    if (h.Css) {
                        var l = h.Css.split(","),
                            k;
                        for (k = l.length - 1; k >= 0; k--) {
                            l[k] = l[k].replace("{libs_url}", onMessage.LibrariesUrl);
                            if (l[k].indexOf("ftpimages") > -1) {
                                l[k] = onMessage.CommonUrl + l[k]
                            }
                            if (l[k] && b('link[href="' + l[k] + '"]').length === 0) {
                                b("<link>").appendTo(b("head")).attr({
                                    type: "text/css",
                                    rel: "stylesheet"
                                }).attr("href", l[k])
                            }
                        }
                    }
                    return e(g)
                });
                head.js.apply(this, i)
            }
        };
        this.sizePhotos = function(f) {
            var e = b(".resp-photo"),
                g = function(k, h) {
                    var j;
                    for (j = 0; j < k.length; j++) {
                        if (h >= k[j].MinWidth && h <= k[j].MaxWidth) {
                            return k[j]
                        }
                    }
                };
            e.each(function(l) {
                onMessage.log("Resize Photo: " + l);
                var j = b(this),
                    h = j.closest(".col"),
                    n = j.data("colWidth"),
                    k = h.width(),
                    p = [],
                    m = 0,
                    i, o;
                if (n && n == k) {
                    return
                }
                j.data("colWidth", k);
                i = j.find("img.resp-image");
                if (j.data("renditions")) {
                    p = j.data("renditions")
                } else {
                    j.find("SPAN").each(function() {
                        p.push({
                            Src: b(this).data("src"),
                            MinWidth: m,
                            MaxWidth: b(this).data("width")
                        });
                        m = b(this).data("width") + 1
                    });
                    if (p.length > 0) {
                        p[p.length - 1].MaxWidth = 9999
                    }
                    j.data("renditions", p)
                }
                o = g(p, k);
                if (o) {
                    if (i.length > 0) {
                        i.attr("src", o.Src);
                        return
                    }
                    i = b("<img>", {
                        src: o.Src,
                        "class": "resp-image",
                        alt: j.data("caption") || j.data("title") || ""
                    }).appendTo(j)
                }
            });
            if (jQuery.isFunction(f)) {
                return f()
            }
        };
        this.sizeIframes = function() {
            b(".iframe-autoheight").each(function() {
                var e = b(this),
                    f = e.data("src");
                if (f === undefined) {
                    f = e.attr("src")
                }
                e.on("load", function() {
                    onMessage.tools.setFrameHeight(e)
                });
                e.attr("src", f)
            })
        };
        this.resizeIframes = function() {
            b(".iframe-autoheight").each(function() {
                onMessage.tools.setFrameHeight(b(this))
            })
        };
        this.resizeIframesPollHeight = function() {
            var e = b(".iframe-pollheight");
            if (e.length) {
                setInterval(function() {
                    e.each(function() {
                        onMessage.tools.setFrameHeight(b(this))
                    })
                }, 1000)
            }
        };
        this.listenForInquiryResize = function(g) {
            var f = g.data || {};
            if ((f.eventName === "OnBoard.InquiryForm.Resize" || f.eventName === "OnMessage.GivingForm.Resize") && f.newHeight && f.selector) {
                b(f.selector).css({
                    height: f.newHeight
                })
            }
        };
        this.listenForAddTrackingCode = function(g) {
            var f = g.data || {};
            if (f.eventName === "InquiryForm.AddTrackingCode") {
                b(c.head).prepend(f.headTrackingCode);
                b(c.body).prepend(f.bodyTrackingCode)
            }
        };
        this.fixPageLinks = function() {
            var e = onMessage.tools.getParameterByName("siteid");
            if (e) {
                b('a[href^="/"]').each(function() {
                    var f = b(this),
                        i = f.attr("href"),
                        h, g;
                    if (f.parents(".adminbar").length === 0) {
                        if (i !== "#" && i.toLowerCase().indexOf("siteid") === -1) {
                            h = i.indexOf("#");
                            g = (h > -1) ? i.substring(h) : "";
                            i = (h > -1) ? i.substring(0, h) : i;
                            i += (i.indexOf("?") > -1 ? "&" : "?") + "siteId=" + e + g;
                            f.attr("href", i)
                        }
                    }
                });
                b("form").each(function() {
                    var g = b(this),
                        h = g.attr("action"),
                        i = g.attr("method"),
                        f;
                    if (i && i.toLowerCase() == "get") {
                        f = g.find('input[name="siteId"]');
                        if (f.length === 0) {
                            f = b("<input>").attr({
                                type: "hidden",
                                name: "siteId"
                            }).val(e);
                            g.append(f)
                        }
                    } else {
                        if (h && h.indexOf("/") === 0) {
                            if (h.toLowerCase().indexOf("siteid") === -1) {
                                h += (h.indexOf("?") > -1 ? "&" : "?") + "siteId=" + e;
                                g.attr("action", h)
                            }
                        }
                    }
                })
            }
        };
        this.menu = {
            init: function(e) {
                var f = e(".menu nav");
                if (f.length > 0) {
                    f.menu()
                }
                onMessage.log("menu init called")
            }
        };
        this.accordionMenu = {
            init: function(e) {
                var f = e("nav.menu-accordion");
                if (f.length > 0) {
                    f.accordionmenu()
                }
                onMessage.log("accordion init called")
            }
        };
        this.horizontalMenu = {
            init: function(e) {
                var f = e("nav.menu-type-horizontal-flat");
                if (f.length > 0) {
                    f.horizontalmenu()
                }
                onMessage.log("horizontal init called")
            }
        };
        this.megaMenu = {
            init: function(e) {
                var f = e("nav.menu-type-mega:not(.sample-template)");
                if (f.length > 0) {
                    f.megamenu()
                }
                onMessage.log("megamenu init called")
            }
        };
        this.sitemap = {
            init: function(e) {
                var f = e(".sitemap nav:not(.sample-template)");
                if (f.length > 0) {
                    f.sitemap()
                }
                onMessage.log("sitemap init called")
            }
        };
        this.annualfund = {
            init: function(e) {
                var f = e(".annualfund .fund");
                if (f.length > 0) {
                    f.annual_fund()
                }
                onMessage.log("annual fund init called")
            }
        };
        this.photoList = {
            init: function(e) {
                var f = e(".photo .use-gallery");
                if (f.length > 0) {
                    f.photolist_manager()
                }
            }
        };
        this.facultyDirectory = {
            init: function(e) {
                e(".faculty-select").change(function() {
                    var h = e(this).val(),
                        g = e(this).attr("id"),
                        f = location.href;
                    f = "?" + g + "=" + h
                })
            }
        };
        this.video = {
            init: function(e) {
                onMessage.pluginManager.load(onMessage.pluginManager.plugins.FancyBox, function() {
                    if (e.fancybox) {
                        e(".lightboxTrigger").fancybox({
                            inline: true
                        })
                    }
                });
                onMessage.log("video init called")
            }
        };
        this.forms = {
            init: function(e) {
                var f = e(".forms");
                if (f.length > 0) {
                    f.forms()
                }
                onMessage.log("forms init called")
            }
        };
        this.formsDetail = {
            init: function(e) {
                var f = e(".forms");
                if (f.length > 0) {
                    f.forms_detail();
                    f.each(function() {
                        var h = e(this),
                            g = h.find("#captcha");
                        if (g.length > 0) {
                            onMessage.tools.getReCaptchaKey(g)
                        }
                    })
                }
                onMessage.log("forms_detail init called")
            },
        };
        this.cookieConsentBanner = {
            init: function(e) {
                var f = e("#content_436");
                if (onMessage.tools.showCookieConsent("om-ccb")) {
                    f.removeClass("hide")
                }
                if (f.length > 0) {
                    f.cookieConsentBanner()
                }
                onMessage.log("cookieConsentBanner init called")
            }
        };
        this.skipToContent = {
            init: function(e) {
                onMessage.log("skiptocontentinit called");
                if (e(".skip-link-container").length === 0) {
                    var f = c.createElement("a");
                    f.classList.add("skip-link");
                    f.tabIndex = 1;
                    f.href = "#skip-to-content";
                    f.innerHTML = "Skip to content";
                    c.body.insertBefore(f, c.body.firstChild)
                }
            }
        };
        this.athleticteamschedulenew = {
            init: function(e) {
                onMessage.log("athleticteamschedulenewinit called");
                e(".athleticteamschedulenew table").each(function(h, g) {
                    var f = e(g).find(".print-button").closest(".grid-header").prev().attr("data-colClass");
                    if (f) {
                        f = "tr td." + f;
                        e(g).find(f).each(function(j, i) {
                            e(i).attr("colspan", parseInt(e(i).attr("colspan")) + 1)
                        })
                    }
                })
            }
        };
        this.athleticteamnavigation = {
            init: function(e) {
                onMessage.log("athleticteamnavigationinit called");
                e(".athleticteamnavigation table").each(function(h, g) {
                    var f = e(g).find(".print-button").closest(".grid-header").prev().attr("data-colClass");
                    if (f) {
                        f = "tr td." + f;
                        e(g).find(f).each(function(j, i) {
                            e(i).attr("colspan", parseInt(e(i).attr("colspan")) + 1)
                        })
                    }
                });
                e(".athleticteamnavigation").athleticTeamNavigation()
            }
        };
        this.audio = {
            init: function(e) {
                e(".audio .album-select").change(function(f) {
                    f.preventDefault();
                    d.location = onMessage.tools.getUrlForAlbumSelect(e(this));
                    return false
                });
                e(".jp-jplayer").each(function(k, j) {
                    var i = e(this),
                        f = e(i.data("container-id")),
                        g = f.find("a.jp-pause"),
                        h = f.find("a.jp-repeat-off");
                    i.jPlayer({
                        ready: function() {
                            i.jPlayer("setMedia", {
                                mp3: i.data("filename-url")
                            });
                            onMessage.log("audio jplayer ready, file: " + i.data("filename-url") + ", container: " + i.data("container-id"))
                        },
                        play: function() {
                            i.jPlayer("pauseOthers");
                            g.css("display", "block")
                        },
                        repeat: function(l) {
                            if (l.jPlayer.options.loop) {
                                e(this).unbind(".jPlayerRepeat").bind(e.jPlayer.event.ended + ".jPlayer.jPlayerRepeat", function() {
                                    e(this).jPlayer("play")
                                });
                                h.css("display", "block")
                            } else {
                                e(this).unbind(".jPlayerRepeat")
                            }
                        },
                        cssSelectorAncestor: i.data("container-id"),
                        swfPath: "{libs_url}/jquery-jplayer/2.4.1/",
                        supplied: "mp3",
                        volume: 0.5,
                        preload: "none"
                    })
                });
                onMessage.log("audio init called")
            }
        };
        this.search = {
            init: function(e) {
                e(".search-box").pageSearch()
            }
        };
        this.poll = {
            init: function(e) {
                e(".poll").poll()
            }
        };
        this.athleticteamschedule = {
            init: function(e) {
                e(".athleticteamschedule").athleticteamschedule()
            }
        };
        this.athleticrecentgames = {
            init: function(e) {
                e(".athleticrecentgames").athleticteamschedule()
            }
        };
        this.storeproducts = {
            init: function(e) {
                e(".storeproducts").storeproducts()
            }
        };
        this.newsarchivedatepicker = {
            init: function(e) {
                e(".newsarchivedatepicker").newsarchivedatepicker()
            }
        };
        this.newsarchivefilter = {
            init: function(e) {
                e(".newsarchivefilter").newsarchivefilter()
            }
        };
        this.calendargrid = {
            init: function() {
                var e = b(".page-calendar-grid");
                if (e.length > 0) {
                    e.calendarGrid()
                }
            }
        };
        this.trivia = {
            init: function() {
                var e = b(".trivia");
                if (e.length > 0) {
                    e.trivia()
                }
            }
        };
        this.mobilemenu = {
            init: function(e) {
                var f = e(".mobilemenu");
                if (f.length > 0) {
                    f.dlmenu()
                }
            }
        };
        this.startEngine(b, c)
    }
    window.onMessage = window.onMessage || {};
    a.call(window.onMessage, jQuery, window, document)
}());
(function(a) {
    var b = {
        init: function(f) {
            if (f === undefined) {
                f = {}
            }
            var g = a.extend({}, f),
                e, c = a(this),
                d = (c.attr("class") !== undefined) ? c.attr("class").split(" ") : "";
            for (e = 0; e < d.length; e++) {
                if (d[e].indexOf("fund-indicator") !== -1) {
                    g.scale = d[e].split("-")[2]
                }
                g.animate = false;
                if (d[e].indexOf("fund-animate") !== -1) {
                    g.animate = true
                }
            }
            c.data("options", g)
        },
        fixHeight: function(c) {
            c.baric.height(function() {
                var d = (c.baric.outerHeight() - c.baric.height()) + c.li.height();
                return c.scale.outerHeight() - d
            })
        },
        getFundElements: function(d) {
            var c = a(d);
            return {
                obj: c,
                barc: c.find(".bar-container-outer"),
                baric: c.find(".bar-container"),
                scale: c.find(".scale"),
                li: c.find(".scale li:eq(2)"),
                bar: c.find(".bar-container .bar")
            }
        },
        version: function() {
            return "onMessage Annual Fund: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        }
    };
    a.fn.annual_fund = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(j) {
                this.method = j;
                b.init.apply(this, arguments);
                var d = b.getFundElements(this),
                    k = d.obj.data("options"),
                    h, g, e, f, i;
                switch (k.scale) {
                    case "center":
                        b.fixHeight(d);
                        d.barc.css({
                            bottom: (d.li.height() / 2)
                        });
                        break;
                    case "top":
                        d.baric.height(function() {
                            var l = d.baric.outerHeight() - d.baric.height();
                            return d.scale.outerHeight() - l
                        });
                        d.barc.css({
                            top: 0
                        });
                        break;
                    default:
                        d.baric.height(function() {
                            var l = d.baric.outerHeight() - d.baric.height();
                            return d.scale.outerHeight() - l
                        });
                        break
                }
                h = parseInt(d.obj.attr("goal"), 10);
                g = parseInt(d.obj.attr("current"), 10);
                e = Math.round(d.baric.height() * (g / h));
                f = d.baric.height() - e;
                if (g >= h) {
                    e = d.barc.height();
                    f = 0
                }
                if (d.bar.outerHeight() > 0) {
                    e = e - d.bar.outerHeight()
                }
                if (k.animate) {
                    i = f + e;
                    d.bar.css({
                        "margin-top": i
                    });
                    setTimeout(function() {
                        d.bar.animate({
                            height: e,
                            "margin-top": f
                        }, 500)
                    }, 1000)
                } else {
                    d.bar.css({
                        height: e,
                        "margin-top": f
                    })
                }
            })
        }
        a.error("Method " + c + " does not exist on jQuery.annual_fund")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function() {
            var d = a(this),
                c, f, l, e, k = "",
                m;
            d.find(".team-nav btn-team").addClass("active");
            d.find(".team-nav-content").hide();
            c = d.closest(".layout-col");
            f = c.attr("class").split(" ");
            for (var g = 0; g < f.length; g++) {
                if (f[g].indexOf("span") > -1) {
                    k = f[g];
                    break
                }
            }
            e = c.find('.page-block[data-cid="256"]');
            l = e.attr("class").split(" ");
            for (var h = 0; h < l.length; h++) {
                if (l[h].indexOf("style-") > -1) {
                    m = l[h];
                    break
                }
            }
            e.find(".athleticteampicker").addClass(m);
            d.find(".team-nav-btn").on("click", function() {
                var n = a(this),
                    i = d.find(".team-nav-content.athletic-roster-new"),
                    j = d.find(".team-nav-content.athletic-schedule-new");
                n.siblings().removeClass("active");
                n.addClass("active");
                if (n.hasClass("btn-team")) {
                    d.find(".team-nav-content").hide();
                    c.find(".page-block").show()
                } else {
                    if (n.hasClass("btn-roster")) {
                        var o = c.find('.page-block[data-cid="256"]');
                        o.css("margin-bottom", "50px");
                        c.find('.page-block:not([data-cid="441"], .team-nav-content > .page-block)').hide();
                        if (i.find(".athleticteampicker").length == 0) {
                            if (o != null) {
                                i.prepend(o.html())
                            }
                        }
                        if (!i.hasClass(k)) {
                            i.addClass(k)
                        }
                        j.hide();
                        i.show()
                    } else {
                        if (n.hasClass("btn-schedule")) {
                            var p = c.find('.page-block[data-cid="256"]');
                            p.css("margin-bottom", "50px");
                            c.find('.page-block:not([data-cid="441"], .teampicker-control, .team-nav-content > .page-block)').hide();
                            i.hide();
                            if (j.find(".athleticteampicker").length == 0) {
                                if (p != null) {
                                    j.prepend(p.html())
                                }
                            }
                            if (!j.hasClass(k)) {
                                j.addClass(k)
                            }
                            j.show()
                        }
                    }
                }
                return false
            })
        }
    };
    a.fn.athleticTeamNavigation = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(d) {
                this.method = d;
                b.init.apply(this, arguments)
            })
        }
        a.error("Method " + c + " does not exist on jQuery.forms")
    }
}(jQuery));
(function(a) {
    a("document").ready(function() {
        var q = window.onMessage,
            h = a(".calendardatepicker"),
            i = h.find("#sDate"),
            d = h.find("#eDate"),
            k = h.find("#siteId"),
            b = h.find("#calDatePicker"),
            c = h.find("li.day"),
            e = h.find("select"),
            g = h.find(".month-pager a"),
            p = h.closest("html").hasClass("styler"),
            f, l, o, s, r, j, m, u, n, v;

        function t(H, z) {
            var G = "",
                A, B, C, D = {},
                w = a(".calendarfilter"),
                x = w.find(".filter-item input[type=checkbox]"),
                y = b.find("#tab"),
                K = true,
                J = [],
                F, E;
            i.val(H);
            d.val(z);
            if (w.find(".filter-item input[type=checkbox].team").length === 0) {
                K = false;
                F = window.location.href.split("?")[1] || "";
                E = F.split("&") || "";
                for (A = 0; A < E.length; A++) {
                    var I = E[A].split("=");
                    if (I[0] === "ts") {
                        J.push(I[1])
                    }
                }
            }
            D = q.tools.getUrlParams() || {};
            D.params = D.params || {};
            v = window.location.origin + window.location.pathname;
            D.params.sDate = H;
            D.params.selStartDate = H;
            D.params.eDate = z;
            D.params.selEndDate = z;
            if (D && D.params !== undefined) {
                if (D.params.siteId !== undefined) {
                    k.val(D.params.siteId)
                } else {
                    k.remove()
                }
                b.find("#showAll").val(D.params.showAll);
                if (y !== undefined && y.val() === "1") {
                    D.params.tab = y.val();
                    D.params.ec = m;
                    D.params.ts = encodeURIComponent(u);
                    D.params.el = n
                }
                for (A in D.params) {
                    if (D && D.params.hasOwnProperty(A)) {
                        for (B = 0; B < x.length; B++) {
                            if (A === x[B].name) {
                                delete D.params[x[B].name]
                            }
                        }
                    }
                }
                if (!K && J && J.length > 0) {
                    delete D.params.ts
                }
                for (C = 0; C < x.length; C++) {
                    if (x[C].checked) {
                        G += x[C].name + "=" + x[C].value + "&"
                    }
                }
                for (C in D.params) {
                    if (D && D.params.hasOwnProperty(C)) {
                        G += C + "=" + D.params[C] + "&"
                    }
                }
                if (J.length > 0) {
                    for (C in J) {
                        G += "ts=" + J[C] + "&"
                    }
                }
            }
            if (G && G.length > 0) {
                G = G.substr(0, G.length - 1)
            }
            window.location = v + "?" + G
        }
        e.change(function(y) {
            y.preventDefault();
            if (p) {
                return
            }
            var w = a(y.currentTarget),
                x = w.val().split(",");
            t(x[0], x[1])
        });
        c.click(function(x) {
            x.preventDefault();
            if (p) {
                return
            }
            var w = a(x.currentTarget);
            t(w.data("date"), w.data("date"))
        });
        g.click(function(x) {
            x.preventDefault();
            if (p) {
                return
            }
            var w = a(x.currentTarget);
            t(w.data("sdate"), w.data("edate"))
        });
        a(".switch-to-grid").on("click", function(w) {
            w.preventDefault();
            f = a(this);
            b = f.closest("div");
            k = b.find("#siteId");
            l = b.find("#tab");
            j = b.find("#showAll");
            m = b.find("#ec").val();
            u = b.find("#ts").val();
            n = b.find("#el").val();
            o = !f.hasClass("styler-bypass");
            s = b.find("#selStartDate").val();
            r = b.find("#selEndDate").val();
            if (p && o) {
                return
            }
            l.val(1);
            j.val(0);
            i.val(s);
            d.val(r);
            t(s, r)
        })
    })
}(jQuery));
(function(a) {
    a("document").ready(function() {
        var e = a(".calendarfilter"),
            f = e.find(".filter-item input[type=checkbox]"),
            h = e.find(".select-all.button"),
            b = e.find(".clear-all.button"),
            g = e.find(".refresh.button"),
            i = e.find("input[name=siteId]"),
            d = e.find("#calEventFilter"),
            c = a(".collapse-btn"),
            j = e.closest("html").hasClass("styler");

        function k() {
            var o = onMessage.tools.getUrlParams() || {},
                r = window.location.origin + window.location.pathname,
                p = "",
                l, n, q, m;
            o.params = o.params || {};
            q = d.find("input[name=showAll]").val();
            o.params.showAll = q;
            for (l in o.params) {
                if (o.params.hasOwnProperty(l)) {
                    for (n = 0; n < f.length; n++) {
                        if (l === f[n].name) {
                            delete o.params[f[n].name]
                        }
                    }
                }
            }
            for (m = 0; m < f.length; m++) {
                if (f[m].checked) {
                    p += f[m].name + "=" + f[m].value + "&"
                }
            }
            for (m in o.params) {
                if (o.params.hasOwnProperty(m)) {
                    p += m + "=" + o.params[m] + "&"
                }
            }
            if (p.length > 0) {
                p = p.substr(0, p.length - 1)
            }
            window.location = r + "?" + p
        }
        h.on("click", function(l) {
            l.preventDefault();
            f.prop("checked", true);
            d.find("input[name=showAll]").val("1")
        });
        b.on("click", function(l) {
            l.preventDefault();
            f.prop("checked", false);
            d.find("input[name=showAll]").val("0")
        });
        f.on("click", function(l) {
            d.find("input[name=showAll]").val("0")
        });
        g.on("click", function(l) {
            l.preventDefault();
            if (!j) {
                var m = onMessage.tools.getUrlParams() || {};
                if (m.params !== undefined) {
                    if (m.params.siteId !== undefined) {
                        i.val(m.params.siteId)
                    } else {
                        i.remove()
                    }
                }
                k()
            }
        });
        c.on("click", function(n) {
            n.preventDefault();
            var l = a(n.currentTarget),
                m = l.closest(".filter-group").find(".filter-group-list");
            if (l.hasClass("hide")) {
                l.removeClass("hide");
                l.addClass("show");
                a(m).slideDown()
            } else {
                l.addClass("hide");
                l.removeClass("show");
                a(m).slideUp()
            }
        })
    })
}(jQuery));
(function(a) {
    var h = window.onMessage,
        b, f, c, d, e;

    function g(n, u, m) {
        var v = "",
            k = a("#gridView"),
            s, y, p, r, q, l, t = {},
            x = true,
            w = "",
            o = {};
        o = n.find(".filter-item input[type=checkbox].team");
        if (o && o.length === 0) {
            x = false;
            w = h.tools.getParameterByName("ts") || ""
        }
        t = h.tools.getUrlParams() || {};
        t.params = t.params || {};
        y = window.location.origin + window.location.pathname;
        l = n.find(".filter-item input[type=checkbox]") || {};
        e = k.find("#tab") || {};
        t.params.sDate = u;
        t.params.eDate = m;
        t.params.showAll = d.val();
        t.params.tab = e.val();
        t.params.ec = b.val();
        t.params.ts = encodeURIComponent(f.val());
        t.params.el = c.val();
        for (p in t.params) {
            if (t.params.hasOwnProperty(p)) {
                for (r = 0; r < l.length; r++) {
                    if (p === l[r].name) {
                        delete t.params[l[r].name]
                    }
                }
            }
        }
        if (!x && w && w.length > 0) {
            delete t.params.ts;
            v += "ts=" + encodeURIComponent(w) + "&"
        }
        for (q = 0; q < l.length; q++) {
            if (l[q].checked) {
                v += l[q].name + "=" + l[q].value + "&"
            }
        }
        for (s in t.params) {
            if (t.params.hasOwnProperty(s)) {
                v += s + "=" + t.params[s] + "&"
            }
        }
        if (v && v.length > 0) {
            v = v.substr(0, v.length - 1)
        }
        window.location = y + "?" + v
    }
    a.fn.calendarGrid = function(i) {
        var j = {
            init: function(l) {
                if (l === "undefined") {
                    l = {}
                }
                var m, k = a(this);
                m = a.extend({}, l);
                k.data("options", m)
            },
            version: function() {
                return "onMessage : Version 1.0"
            }
        };
        if (j[i]) {
            return j[i].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof i === "object" || !i) {
            return this.each(function(t) {
                var u, v, n, p, o, m, r, l, s, k, q;
                j.init.apply(this, arguments);
                n = a(this);
                v = {
                    openMobileEvents: function(y, A) {
                        var z = y.closest("li").data("date"),
                            w = y.next(".event-data"),
                            x = y.closest("ol").next(".calendar-list");
                        if (A === z) {
                            return
                        }
                        n.find(".active").removeClass("active");
                        if (w.length > 0) {
                            x.html(w.html());
                            a(".athletic-event .calendar-directions").on("click", function(D) {
                                if (!a("body").hasClass("sample-data")) {
                                    D.preventDefault();
                                    var B = a(this),
                                        F = B.data("scheduleid"),
                                        G = B.data("showtrans"),
                                        E = B.data("practice"),
                                        C = h.App.module("AthleticSchedule");
                                    if (!B.hasClass("styler")) {
                                        C.Utilities.showDirections(F, G, E)
                                    }
                                }
                            });
                            x.find("*").removeAttr("style");
                            x.slideDown()
                        }
                        n.data("open-day", z);
                        y.addClass("active")
                    },
                    setEventCats: function(x) {
                        var w = x.find(".filter-item input:checked"),
                            y = "",
                            B = "",
                            z = "",
                            A;
                        b = x.find("#ec");
                        f = x.find("#ts");
                        c = x.find("#el");
                        for (A = 0; A < w.length; A++) {
                            if (w.eq(A).hasClass("event-category")) {
                                y += "," + w.eq(A).val()
                            }
                            if (w.eq(A).hasClass("team")) {
                                B += "," + w.eq(A).val()
                            }
                            if (w.eq(A).hasClass("event-location")) {
                                z += "," + w.eq(A).val()
                            }
                        }
                        b.val(y.substr(1, y.length));
                        f.val(B.substr(1, B.length));
                        c.val(z.substr(1, z.length))
                    },
                    setShowAll: function(x) {
                        var w = o.closest("div");
                        d = w.find("#showAll");
                        d.val(x)
                    }
                };
                if (!a("html").hasClass("styler")) {
                    n.find(".date").on("click", function(w) {
                        w.preventDefault()
                    });
                    n.find(".date").on("mouseup", function(w) {
                        if (a(".event-data").css("display") === "none") {
                            o = a(this);
                            u = n.data("open-day");
                            p = "";
                            if (u !== undefined) {
                                p = n.find("li[data-date=" + u + "]").closest("ol").next(".calendar-list")
                            }
                            if (p.length > 0) {
                                p.slideUp(400, function() {
                                    n.data("open-day", null);
                                    v.openMobileEvents(o, u)
                                })
                            } else {
                                v.openMobileEvents(o)
                            }
                            return
                        }
                    });
                    m = n.find(".grid-filter");
                    s = m.find(".select-all.button");
                    k = m.find(".clear-all.button");
                    q = m.find(".refresh.button");
                    r = n.find("#sDate");
                    l = n.find("#eDate");
                    n.find(".calendar-grid-buttons .prev-button,.calendar-grid-buttons .next-button").on("click", function(y) {
                        y.preventDefault();
                        o = a(this);
                        var w = n.find("#siteId"),
                            A = n.closest("html").hasClass("styler"),
                            x = a(y.currentTarget),
                            z = window.location.href,
                            B;
                        if (A) {
                            return
                        }
                        r.val(x.data("sdate"));
                        l.val(x.data("edate"));
                        if (z.indexOf("siteId") !== -1) {
                            B = h.tools.getParameterByName("siteId");
                            w.val(B)
                        } else {
                            w.remove()
                        }
                        v.setEventCats(n.find("#gridView"));
                        v.setShowAll("0");
                        g(m, r.val(), l.val())
                    })
                }
                n.find(".switch-to-list").on("click", function(z) {
                    z.preventDefault();
                    o = a(this);
                    var w = o.closest("div"),
                        x = w.find("#siteId"),
                        C = w.closest("html").hasClass("styler"),
                        B = !o.hasClass("styler-bypass"),
                        A, D, y = a(z.currentTarget);
                    if (C && B) {
                        return
                    }
                    if (y.data("sdate") != undefined) {
                        r.val(y.data("sdate"))
                    }
                    if (y.data("edate") != undefined) {
                        l.val(y.data("edate"))
                    }
                    e = w.find("#tab");
                    e.val(0);
                    A = window.location.href;
                    if (A.indexOf("siteId") !== -1) {
                        D = h.tools.getParameterByName("siteId");
                        x.val(D)
                    } else {
                        x.remove()
                    }
                    v.setEventCats(n.find("#gridView"));
                    v.setShowAll("0");
                    g(n.find(".grid-filter"), (r != undefined ? r.val() : null), (l != undefined ? l.val() : null))
                });
                n.find(".grid-filter-button").on("click", function(w) {
                    w.preventDefault();
                    var x;
                    o = a(this);
                    m = a(".grid-filter");
                    x = m.closest("html").hasClass("styler");
                    if (x) {
                        return
                    }
                    if (m.is(":visible")) {
                        o.removeClass("active").html("Filter");
                        m.slideUp()
                    } else {
                        o.addClass("active").html("Close Filter");
                        m.slideDown()
                    }
                });
                s.click(function() {
                    m = a(".grid-filter");
                    var w = m.find(".filter-item input[type=checkbox]");
                    w.prop("checked", true);
                    v.setEventCats(n.find("#gridView"));
                    v.setShowAll("1")
                });
                k.click(function() {
                    m = a(".grid-filter");
                    var w = m.find(".filter-item input[type=checkbox]");
                    w.prop("checked", false);
                    v.setEventCats(n.find("#gridView"));
                    v.setShowAll("0")
                });
                m.find(".filter-item input").on("click", function() {
                    v.setEventCats(n.find("#gridView"));
                    v.setShowAll("0")
                });
                q.click(function() {
                    var w = a(this).closest("div"),
                        x = w.find("#siteId"),
                        z = w.closest("html").hasClass("styler"),
                        y, A;
                    if (!z) {
                        y = window.location.href;
                        if (y.indexOf("siteId") !== -1) {
                            A = h.tools.getParameterByName("siteId");
                            x.val(A)
                        } else {
                            x.remove()
                        }
                        g(n.find(".grid-filter"), r.val(), l.val())
                    }
                })
            })
        }
    }
}(jQuery));
(function(a) {
    a(".video select").change(function() {
        a(this).parents("form").submit()
    })
}(jQuery));
(function(a) {
    var b = {
        init: function() {
            var c = a(this);
            c.find(".close").on("click", function() {
                var d = a(this),
                    e = d.closest(".cookieconsent-item"),
                    f = e.data("ccid");
                if (f) {
                    onMessage.tools.setCookie("om-ccb", f.toString(), 30)
                }
                e.remove();
                if (c.find(".cookieconsent-item").length === 0) {
                    c.remove()
                }
            })
        },
        version: function() {
            return "onMessage cookieBanner: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        }
    };
    a.fn.cookieConsentBanner = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(d) {
                this.method = d;
                b.init.apply(this, arguments)
            })
        }
        a.error("Method " + c + " does not exist on jQuery.cookieConsentBanner")
    }
}(jQuery));
(function(a) {
    var b = {
        showSlide: function(d) {
            var e = a(".img-slide"),
                c;
            if (d >= e.length) {
                d = 0
            }
            if (d < 0) {
                d = e.length - 1
            }
            for (c = 0; c < e.length; c++) {
                e[c].style.display = "none"
            }
            e[d].style.display = "block"
        },
        loadImageSource: function() {
            var c;
            a(".carousel-image").each(function(d, e) {
                c = a(this);
                if (!c.hasClass("src-loaded")) {
                    c.addClass("src-loaded");
                    c.attr("src", c.attr("data-src"))
                }
            })
        },
        openModal: function(d) {
            var c = a("#modal_container");
            c.modal({
                containerId: "pageengine-modal",
                zIndex: 10000
            });
            a("#pageengine-modal").addClass("flush");
            this.showSlide(d);
            a.modal.setContainerDimensions();
            a("#pageengine-modal").addClass("album-detail-modal");
            a.modal.setPosition()
        },
        previousPhoto: function() {
            var c = a(".img-slide").filter(":visible").data("index");
            b.showSlide(c - 1)
        },
        nextPhoto: function() {
            var c = a(".img-slide").filter(":visible").data("index");
            b.showSlide(c + 1)
        }
    };
    a(function() {
        a(".modal-open").click(function(c) {
            c.preventDefault();
            var d = a(this).data("index");
            b.loadImageSource();
            b.openModal(d)
        });
        a(".flex-prev").click(b.previousPhoto);
        a(".flex-next").click(b.nextPhoto)
    })
}(jQuery));
(function(a) {
    var b = {
        init: function() {
            var c = a(this);
            c.find(".close").on("click", function() {
                var e = a(this),
                    d = e.closest(".bulletin-item"),
                    g = d.data("bid"),
                    h = d.data("showalways"),
                    f = d.data("bdate"),
                    j = onMessage.tools.getCookie("om-ebb"),
                    i = (j && j.length > 0) ? j.split(",") : [],
                    k;
                if (g && !h) {
                    k = g + "|" + f;
                    i.push(k)
                }
                j = i.toString();
                onMessage.tools.setCookie("om-ebb", j, 30);
                d.remove();
                if (c.find(".bulletin-item").length === 0) {
                    c.remove()
                }
            })
        },
        version: function() {
            return "onMessage bulletinBanner: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        }
    };
    a.fn.bulletinBanner = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(d) {
                this.method = d;
                b.init.apply(this, arguments)
            })
        }
        a.error("Method " + c + " does not exist on jQuery.bulletinBanner")
    }
}(jQuery));
(function(a) {
    a.fn.bulletinLightbox = function() {
        return this.each(function() {
            var b = a(this);
            b.modal({
                escClose: false,
                autoResize: true,
                onShow: function(c) {
                    a(c.container).css({
                        height: "90%",
                        width: "75%",
                        overflow: "auto"
                    });
                    a.modal.setPosition()
                },
                zIndex: 500000000,
                onClose: function() {
                    a.modal.close();
                    a("#emergency-bulletin-lightbox").remove()
                }
            });
            b.find(".close,.emergencybulletin-lightbox").on("click", function(e) {
                if (e.target.className !== "button addinfo") {
                    var d = onMessage.tools.getCookie("om-ebl"),
                        c = (d && d.length > 0) ? d.split(",") : [];
                    b.find(".bulletin-item").each(function() {
                        var f = a(this),
                            h = f.data("bid"),
                            g = f.data("bdate"),
                            i = f.data("showalways"),
                            j;
                        if (h && !i) {
                            j = h + "|" + g;
                            c.push(j)
                        }
                    });
                    d = c.toString();
                    onMessage.tools.setCookie("om-ebl", d, 30);
                    a.modal.close()
                }
            })
        })
    }
}(jQuery));
(function(a) {
    var b = function() {
            var e = new Date().getTime(),
                f = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(d) {
                    var g = (e + Math.random() * 16) % 16 | 0;
                    e = Math.floor(e / 16);
                    return (d === "x" ? g : (g & 7 | 8)).toString(16)
                });
            return f
        },
        c = {
            init: function() {
                var h = a(this),
                    e = h.find("form"),
                    f = h.find(".form-confirm"),
                    g = h.find("#formSubmitted").val(),
                    d = e.find("#captcharefresh");
                if (f.length > 0 && g > 0) {
                    var j = a("#headTrackingCode_" + g).val();
                    var i = a("#bodyTrackingCode_" + g).val();
                    a(document.head).prepend(j);
                    a(document.body).prepend(i)
                }
                e.on("submit", function() {
                    if (!c.validate(e)) {
                        h.find(".field-error-message").show();
                        e.find(".field-error INPUT:eq(0)").focus();
                        return false
                    }
                    a("#btnSubmit").attr("disabled", "disabled");
                    h.find(".field-error-message").hide();
                    e.find(".field-error").removeClass("field-error")
                });
                d.on("click", function() {
                    var l = b(),
                        k = "/page/utilities/captcha.ashx?prefix=" + l;
                    a("#captcha_image").attr("src", k);
                    a("#Captcha").val("");
                    a("#captcha_guid").val(l)
                })
            },
            version: function() {
                return "onMessage Forms: Version 1.0"
            },
            log: function(d) {
                if (window.console) {
                    window.console.debug(d)
                }
            },
            validate: function(d) {
                var e = d.find(".required"),
                    f = true;
                e.each(function() {
                    var g = a(this);
                    if (g.find("input").length > 0) {
                        if (g.find("input").val().length === 0) {
                            g.addClass("field-error");
                            f = false
                        }
                    }
                    if (g.find("select").length > 0) {
                        if (g.find("select").val().length === 0) {
                            g.addClass("field-error");
                            f = false
                        }
                    }
                });
                return f
            }
        };
    a.fn.forms_detail = function(d) {
        if (c[d]) {
            return c[d].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof d === "object" || !d) {
            return this.each(function(e) {
                this.method = e;
                c.init.apply(this, arguments)
            })
        }
        a.error("Method " + d + " does not exist on jQuery.forms")
    }
}(jQuery));
(function(a) {
    var c = (function() {
            var g, d, f = {
                    hidden: "visibilitychange",
                    webkitHidden: "webkitvisibilitychange",
                    mozHidden: "mozvisibilitychange",
                    msHidden: "msvisibilitychange"
                },
                e = 0;
            for (e = 0; e < f.length - 1; e++) {
                if (document.hasOwnProperty(f[e])) {
                    g = f[e];
                    d = f[g];
                    break
                }
            }
            return function(h) {
                if (h) {
                    document.addEventListener(d, h)
                }
                return !document[g]
            }
        }()),
        b = {
            init: function(i) {
                i = i || {};
                var j = a.extend({}, i),
                    f = a(this),
                    h = f.attr("class").split(" "),
                    e, d, g;
                j.loop = (a.inArray("loop-animation", h) !== -1) ? true : false;
                j.autoAdvance = (a.inArray("no-auto-advance", h) !== -1) ? false : true;
                j.pauseOnHover = (a.inArray("pause-on-hover", h) !== -1) ? true : false;
                j.pauseOnAction = (a.inArray("pause-on-action", h) !== -1) ? true : false;
                j.haveDetails = (a.inArray("no-details", h) !== -1) ? false : true;
                j.random = (a.inArray("randomize", h) !== -1) ? true : false;
                j.slideshowSpeed = (!isNaN(parseFloat(f.attr("slideshowspeed"), 10))) ? b.convertToMiliseconds(parseFloat(f.attr("slideshowspeed"), 10)) : 5000;
                j.animationSpeed = (!isNaN(parseFloat(f.attr("animationspeed"), 10))) ? b.convertToMiliseconds(parseFloat(f.attr("animationspeed"), 10)) : 1000;
                if (f.closest("html").hasClass("styler")) {
                    j.autoAdvance = false
                }
                if (j.random) {
                    f.find(".bg-image").shuffle()
                }
                f.data({
                    options: j,
                    index: 0,
                    finished: false
                });
                e = f.find(".bg-image").eq(0);
                d = f.find(".details-" + e.data("id"));
                g = f.find(".details-viewport");
                f.closest(".region").css({
                    position: "relative"
                });
                e.addClass("current-slide");
                f.find(".pager li a").eq(0).addClass("current-pager-item");
                d.addClass("current-details");
                g.height(d.outerHeight());
                return f
            },
            convertToMiliseconds: function(d) {
                return d * 1000
            },
            version: function() {
                return "Background Carousel : Version 1.2"
            },
            log: function(d) {
                if (window.console) {
                    console.debug(d)
                }
            }
        };
    a.fn.bgcarousel = function(d) {
        if (b[d]) {
            return b[d].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof d === "object" || !d) {
            return this.each(function(f) {
                var e = b.init.apply(this, arguments),
                    g = {
                        obj: e,
                        slides: e.find(".bg-image"),
                        pager: e.find(".pager"),
                        options: e.data("options"),
                        queue: [],
                        timeout: "",
                        animating: false,
                        isVisible: function() {
                            var h = true;
                            if (!c()) {
                                h = false
                            }
                            return h
                        },
                        go: function(h) {
                            if (!g.animating && g.isVisible()) {
                                g.animating = true;
                                var i = g.obj.data("index") + h;
                                if (h > 0) {
                                    i = (i >= g.slides.length) ? 0 : i
                                }
                                g.obj.data("next", i);
                                g.maybeLoadNextImages(i);
                                g.animate()
                            }
                        },
                        animate: function() {
                            var j = g.slides.eq(g.obj.data("index")),
                                l = g.slides.eq(g.obj.data("next")),
                                h = g.obj.find(".details"),
                                i = g.obj.find(".details-" + j.data("id")),
                                k = g.obj.find(".details-" + l.data("id")),
                                m = g.obj.find(".details-viewport");
                            if (k.hasClass("no-details")) {
                                k.closest(".details-content").animate({
                                    opacity: 0
                                }, {
                                    duration: g.options.animationSpeed / 2,
                                    easing: "swing"
                                })
                            }
                            i.animate({
                                opacity: 0
                            }, {
                                duration: g.options.animationSpeed / 2,
                                easing: "swing",
                                queue: false,
                                complete: function() {
                                    m.animate({
                                        height: k.outerHeight()
                                    }, {
                                        duration: g.options.animationSpeed / 2,
                                        easing: "swing",
                                        queue: false,
                                        complete: function() {
                                            h.removeClass("current-details").css({
                                                opacity: 0
                                            });
                                            k.animate({
                                                opacity: 1
                                            }, {
                                                duration: g.options.animationSpeed / 2,
                                                easing: "swing",
                                                queue: false,
                                                complete: function() {
                                                    a(this).addClass("current-details");
                                                    if (!k.hasClass("no-details")) {
                                                        k.closest(".details-content").animate({
                                                            opacity: 1
                                                        }, {
                                                            duration: g.options.animationSpeed / 2,
                                                            easing: "swing"
                                                        })
                                                    }
                                                }
                                            })
                                        }
                                    })
                                }
                            });
                            l.animate({
                                opacity: 1
                            }, {
                                duration: g.options.animationSpeed / 2,
                                easing: "swing",
                                queue: false,
                                complete: function() {
                                    j.animate({
                                        opacity: 0
                                    }, {
                                        duration: g.options.animationSpeed / 2,
                                        easing: "swing",
                                        queue: false,
                                        complete: function() {
                                            a(this).removeClass("current-slide")
                                        }
                                    });
                                    a(this).addClass("current-slide");
                                    g.obj.data("index", g.obj.data("next"));
                                    g.pager.find(".current-pager-item").removeClass("current-pager-item");
                                    g.pager.find("a").eq(g.obj.data("index")).addClass("current-pager-item");
                                    g.animating = false
                                }
                            })
                        },
                        autoAdvance: function() {
                            clearTimeout(g.timeout);
                            g.timeout = setTimeout(function() {
                                var i = g.obj.data("index"),
                                    h = true;
                                if (!g.options.loop && i === g.slides.length - 1) {
                                    h = false;
                                    g.obj.data("finished", true)
                                }
                                if (h) {
                                    g.go(1);
                                    g.autoAdvance()
                                }
                            }, g.options.slideshowSpeed)
                        },
                        maybeLoadNextImages: function(k) {
                            var i = g.obj.find(".bg-resp-photo"),
                                h = "",
                                l = 1,
                                m = 1,
                                j;
                            if (k === 0) {
                                m = 0;
                                h = i.slice(i.length - 1)
                            }
                            j = i.slice(k - m, k + l).add(h);
                            j.each(function() {
                                var n = a(this);
                                g.loadImage(n)
                            })
                        },
                        loadImage: function(i) {
                            var h = i.closest(".region"),
                                k = i.data("colWidth"),
                                j = h.width(),
                                m, l;
                            if (k && k === j) {
                                return
                            }
                            i.data("colWidth", j);
                            m = g.setRenditions(i);
                            l = g.selectRendition(m, j);
                            if (l) {
                                i.css({
                                    "background-image": "url(" + l.Src + ")"
                                });
                                return
                            }
                        },
                        selectRendition: function(k, h) {
                            var j;
                            for (j = 0; j < k.length; j++) {
                                if (h >= k[j].MinWidth && h <= k[j].MaxWidth) {
                                    return k[j]
                                }
                            }
                        },
                        setRenditions: function(h) {
                            if (h.data("renditions")) {
                                return h.data("renditions")
                            }
                            var j = [],
                                i = 0;
                            h.find("SPAN").each(function() {
                                j.push({
                                    Src: a(this).data("src"),
                                    MinWidth: i,
                                    MaxWidth: a(this).data("width")
                                });
                                i = a(this).data("width") + 1
                            });
                            if (j.length > 0) {
                                j[j.length - 1].MaxWidth = 9999
                            }
                            h.data("renditions", j);
                            return j
                        }
                    };
                g.maybeLoadNextImages(0);
                if (g.slides.length > 1) {
                    e.find(".controls a").on("click", function(i) {
                        i.preventDefault();
                        var h = a(this);
                        if (h.hasClass("control-next")) {
                            g.go(1)
                        } else {
                            g.go(-1)
                        }
                    });
                    e.find(".pager a").on({
                        click: function(j) {
                            j.preventDefault();
                            var h = a(this),
                                i = h.closest("ul"),
                                k = i.find("a").index(h);
                            if (g.obj.data("index") !== k) {
                                g.go(k - g.obj.data("index"))
                            }
                        },
                        mouseenter: function() {
                            var h = a(this),
                                i = h.closest("ul"),
                                j = i.find("a").index(h);
                            g.maybeLoadNextImages(j)
                        }
                    });
                    if (g.options.autoAdvance) {
                        g.autoAdvance();
                        if (g.options.haveDetails) {
                            if (g.options.pauseOnHover) {
                                g.obj.find(".details-content").on({
                                    mouseenter: function(h) {
                                        clearTimeout(g.timeout)
                                    },
                                    mouseleave: function(h) {
                                        var i = g.obj.data("finished");
                                        if (!i) {
                                            setTimeout(function() {
                                                g.autoAdvance()
                                            }, g.options.animationSpeed)
                                        }
                                    }
                                })
                            }
                            if (g.options.pauseOnAction) {
                                g.obj.find(".controls a, .pager a").on("click", function(h) {
                                    h.preventDefault();
                                    clearTimeout(g.timeout)
                                })
                            }
                        }
                    }
                } else {
                    g.obj.find(".bg-carousel-nav").remove();
                    g.obj.find(".controls").remove()
                }
            })
        }
    };
    a.fn.shuffle = function() {
        var d = this.get(),
            e = function(g) {
                return Math.floor(Math.random() * g)
            },
            f = a.map(d, function() {
                var h = e(d.length),
                    g = a(d[h]).clone(true)[0];
                d.splice(h, 1);
                return g
            });
        this.each(function(g) {
            a(this).replaceWith(a(f[g]))
        });
        return a(f)
    }
}(jQuery));
(function(a) {
    var b = {
        convertToMiliseconds: function(c) {
            return c * 1000
        },
        get_current_viewport: function() {
            var d = b.get_viewports(),
                e = a(window).width(),
                c = d.desktop;
            if (e > d.large_desktop) {
                c = d.large_desktop
            } else {
                if (e < d.portrait && e > d.mobile) {
                    c = d.portrait
                } else {
                    if (e <= d.mobile) {
                        c = d.mobile
                    }
                }
            }
            return c
        },
        get_viewports: function() {
            return {
                mobile: 767,
                portrait: 979,
                desktop: 0,
                large_desktop: 1200
            }
        },
        init: function(g) {
            g = g || {};
            var h = a.extend({
                    arrows: false,
                    podiumStyle: false
                }, g),
                c = a(this),
                d = (c.attr("class") !== undefined) ? c.attr("class").split(" ") : "",
                f = parseInt(c.attr("minItem"), 10),
                e = parseInt(c.attr("maxItem"), 10);
            h.carouselType = (a.inArray("carousel-type-text", d) !== -1) ? "text" : "photo";
            h.contentType = (c.attr("type") !== undefined) ? c.attr("type") : undefined;
            h.StyleModeId = (!isNaN(parseInt(c.attr("mode"), 10))) ? parseInt(c.attr("mode"), 10) : 1;
            h.arrows = (a.inArray("arrows", d) !== -1) ? true : false;
            h.counter = (a.inArray("show-counter", d) !== -1 && !a("HTML").hasClass("ismodal")) ? true : false;
            h.randomize = (a.inArray("randomize", d) !== -1) ? true : false;
            h.loop = (a.inArray("loop-animation", d) !== -1) ? true : false;
            h.startAt = (!isNaN(parseInt(c.attr("startat"), 10))) ? parseInt(c.attr("startat"), 10) : 1;
            h.smoothheight = (a.inArray("smoothheight", d) !== -1) ? true : false;
            h.showArrowsAlways = (a.inArray("show-arrows-always", d) !== -1) ? true : false;
            h.min = (!isNaN(f) && f !== 0) ? f : 1;
            h.max = (!isNaN(e) && e !== 0) ? e : 1;
            h.slideWidth = (!isNaN(parseInt(c.attr("slideWidth"), 10))) ? parseInt(c.attr("slideWidth"), 10) : 1;
            h.showCaption = (a.inArray("show-caption", d) !== -1) ? true : false;
            h.showCaptionOnHover = (a.inArray("caption-hover", d) !== -1) ? true : false;
            h.captionTop = (a.inArray("caption-position-top", d) !== -1) ? true : false;
            h.captionBottom = (a.inArray("caption-position-bottom", d) !== -1) ? true : false;
            h.captionInside = (a.inArray("caption-location-inside", d) !== -1) ? true : false;
            h.captionOutside = (a.inArray("caption-location-outside", d) !== -1) ? true : false;
            h.pagerArrows = (a.inArray("pager-arrows", d) !== -1) ? true : false;
            h.pager = (a.inArray("pager", d) !== -1) ? true : false;
            h.pagerThumbnails = (a.inArray("pager-type-thumbnails", d) !== -1) ? true : false;
            h.pagertop = (a.inArray("pager-position-top", d) !== -1) ? true : false;
            h.pagerbottom = (a.inArray("pager-position-bottom", d) !== -1) ? true : false;
            h.pagerleft = (a.inArray("pager-position-left", d) !== -1) ? true : false;
            h.pagerright = (a.inArray("pager-position-right", d) !== -1) ? true : false;
            h.pagerAlignLeft = (a.inArray("pager-alignment-right", d) !== -1) ? true : false;
            h.pagerAlignCenter = (a.inArray("pager-alignment-center", d) !== -1) ? true : false;
            h.pagerAlignRight = (a.inArray("pager-alignment-right", d) !== -1) ? true : false;
            h.pagerAlignTop = (a.inArray("pager-alignment-top", d) !== -1) ? true : false;
            h.pagerAlignBottom = (a.inArray("pager-alignment-bottom", d) !== -1) ? true : false;
            h.pagerType = (a.inArray("pager-type-thumbnails", d) !== -1) ? "thumbnails" : "shapes";
            if (h.pagerThumbnails) {
                h.pager = false;
                h.thumbMargin = (!isNaN(parseInt(c.attr("thumbMargin"), 10))) ? parseInt(c.attr("thumbMargin"), 10) : 0;
                h.thumbHeight = (!isNaN(parseInt(c.attr("thumbHeight"), 10))) ? parseInt(c.attr("thumbHeight"), 10) : 100;
                h.thumbWidth = (!isNaN(parseInt(c.attr("thumbWidth"), 10))) ? parseInt(c.attr("thumbWidth"), 10) : 100;
                h.thumbstop = (a.inArray("thumbs-position-top", d) !== -1) ? true : false;
                h.thumbsbottom = (a.inArray("thumbs-position-bottom", d) !== -1) ? true : false;
                h.thumbsleft = (a.inArray("thumbs-position-left", d) !== -1) ? true : false;
                h.thumbsright = (a.inArray("thumbs-position-right", d) !== -1) ? true : false
            }
            h.autoAdvance = (a.inArray("no-auto-advance", d) !== -1) ? false : true;
            h.pauseOnHover = (a.inArray("pause-on-hover", d) !== -1) ? true : false;
            h.pauseOnAction = (a.inArray("pause-on-action", d) !== -1) ? true : false;
            h.slideshowSpeed = (!isNaN(parseFloat(c.attr("slideshowSpeed"), 10))) ? b.convertToMiliseconds(parseFloat(c.attr("slideshowSpeed"), 10)) : 5000;
            h.animationSpeed = (!isNaN(parseFloat(c.attr("animationSpeed"), 10))) ? b.convertToMiliseconds(parseFloat(c.attr("animationSpeed"), 10)) : 1000;
            h.animationType = (a.inArray("animation-slide", d) !== -1) ? "slide" : "fade";
            h.direction = "horizontal";
            if ((h.pagerleft || h.pagerright || h.thumbsleft || h.thumbsright) && (h.animationType === "slide" || h.pagerType === "thumbnails")) {
                h.direction = "vertical"
            }
            h.heightResetUseLi = false;
            h.podiumStyle = (a.inArray("gallery-style", d) !== -1) ? true : false;
            if (h.podiumStyle) {
                h.pager = false;
                h.direction = "horizontal"
            }
            h.videoContentType = false;
            if (h.contentType === "video") {
                h.videoContentType = true
            }
            if (h.StyleModeId === 4 || h.StyleModeId === 2 || (h.StyleModeId == 1 && h.contentType === "video")) {
                h.direction = "horizontal";
                h.counter = false;
                c.find(".counter").remove();
                c.find("li").css({
                    width: h.slideWidth
                })
            } else {
                h.slideWidth = 0
            }
            h.defaultArgs = {
                animation: h.animationType,
                smoothHeight: h.smoothheight,
                easing: "swing",
                direction: h.direction,
                reverse: false,
                animationLoop: h.loop,
                slideshow: h.autoAdvance,
                slideshowSpeed: h.slideshowSpeed,
                animationSpeed: h.animationSpeed,
                startAt: h.startAt - 1,
                randomize: h.randomize,
                pauseOnAction: h.pauseOnAction,
                pauseOnHover: h.pauseOnHover,
                useCSS: true,
                touch: true,
                video: h.videoContentType,
                controlNav: h.pager,
                directionNav: h.arrows,
                prevText: "back",
                nextText: "next",
                itemWidth: h.slideWidth,
                itemMargin: 0,
                minItems: h.min,
                maxItems: h.max,
                move: 0
            };
            c.addClass("flex-" + h.direction);
            c.addClass("carousel-direction-" + h.direction);
            if (h.counter) {
                c.find(".counter").show()
            }
            c.data("options", h);
            c.data("vars", {
                pagerIndex: h.defaultArgs.startAt,
                pagerCurrentPage: 1
            });
            b.$obj = c;
            c.find(".carousel-photo").data("loaded", false);
            b.maybeLoadNextImages(c, 0)
        },
        loadAudio: function(c) {
            a(".jp-jplayer").each(function(f, e) {
                var d = a(e);
                d.jPlayer({
                    ready: function() {
                        d.jPlayer("setMedia", {
                            mp3: d.data("filename-url")
                        })
                    },
                    play: function() {
                        c.flexslider("pause");
                        d.jPlayer("pauseOthers")
                    },
                    ended: function() {
                        c.flexslider("play")
                    },
                    pause: function() {
                        c.flexslider("play")
                    },
                    cssSelectorAncestor: d.data("container-id"),
                    swfPath: onMessage.pluginManager.plugins.jPlayer.swfPath,
                    supplied: "mp3",
                    volume: 0.5
                })
            })
        },
        loadImage: function(e, f) {
            var i = f.data("options"),
                c = (i.StyleModeId === 2) ? e.closest("li") : e.closest(".col"),
                h = e.data("colWidth"),
                g = c.width(),
                k, d, j;
            if (h && h === g) {
                return
            }
            e.data("colWidth", g);
            k = b.setRenditions(e);
            d = e.find("img.carousel-image");
            j = b.selectRendition(k, g);
            if (j) {
                if (d.length > 0) {
                    d.attr("src", j.Src);
                    return
                }
                d = a("<img>", {
                    src: j.Src,
                    "class": "carousel-image",
                    alt: (e.data("caption") || e.data("title") || "")
                });
                if (j.altImgSrc) {
                    d.on("error", function() {
                        a(this).onerror = "";
                        a(this).attr("src", j.altImgSrc)
                    })
                }
                d.appendTo(e).load(function() {
                    if (f !== undefined) {
                        var n = f.data("options"),
                            m = (n.animationType === "slide") ? f.find(".flex-viewport") : f.find(".slides").parent(),
                            l = d.closest("li");
                        if (l.index() === 1 && !n.smoothheight) {
                            m.animate({
                                height: l.height()
                            }, (n.smoothheight) ? 200 : 1)
                        }
                    }
                });
                d.css("display", "none").height();
                d.css("display", "block");
                if (a("HTML").hasClass("ismodal")) {
                    d.height(a("HTML").height())
                }
            }
            if (f !== undefined) {
                f.resize()
            }
        },
        log: function(c) {
            if (window.console) {
                console.debug(c)
            }
        },
        maybeHideCaptionAll: function(d) {
            var c = d.find("figcaption");
            if (c.length > 0) {
                c.each(function() {
                    if (a(this).find(".caption-spacing").is(":empty")) {
                        a(this).hide()
                    }
                })
            }
        },
        maybeHideCaption: function(d) {
            var c = (d.slides === undefined) ? d.find("figcaption") : d.slides.eq(d.animatingTo).find("figcaption");
            if (c.length > 0) {
                if (c.find(".caption-spacing").is(":empty")) {
                    c.hide()
                }
            }
        },
        maybeLoadNextImages: function(f, g) {
            var i = f.data("options"),
                d = f.find("li:not(.clone) .carousel-photo"),
                c = "",
                h = i.max,
                j = i.max,
                e;
            if (g === 0 || g === d.length) {
                if (g === 0) {
                    j = 0
                }
                c = f.find(".clone .carousel-photo")
            }
            e = d.slice((g * i.max) - j, (g * i.max) + i.max + h).add(c);
            e.each(function() {
                var k = a(this);
                b.loadImage(k, f)
            })
        },
        selectRendition: function(e, c) {
            var d;
            for (d = 0; d < e.length; d++) {
                if (c >= e[d].MinWidth && c <= e[d].MaxWidth) {
                    return e[d]
                }
            }
        },
        setCaption: function(e) {
            var c = e.find(".caption-spacing"),
                d = e.find(".flex-active-slide figure"),
                f = "",
                l, j, i, g, h, k;
            if (e.slides === undefined || e.slides.length === 1) {
                d = e.find("figure")
            }
            l = d.data("title") || "";
            j = d.data("detailurl") || "";
            i = d.data("date") || "";
            g = d.data("author") || "";
            h = d.data("caption") || "";
            k = d.data("long") || "";
            if (l.length > 0) {
                if (j.length > 0) {
                    f += '<h4 class="crl-title"><a href="' + j + '">' + l + "</a></h4>"
                } else {
                    f += '<h4 class="crl-title">' + l + "</h4>"
                }
            }
            if (i.length > 0) {
                f += '<time class="crl-date">' + i + "</time>"
            }
            if (g.length > 0) {
                f += '<h4 class="crl-author">' + g + "</h4>"
            }
            if (h.length > 0) {
                f += '<div class="crl-caption">' + h + "</div>"
            }
            if (k.length > 0) {
                f += '<div class="crl-description">' + k + "</div>"
            }
            if (f.length > 0) {
                c.html("").append(f).show()
            } else {
                c.hide()
            }
        },
        setRenditions: function(c) {
            if (c.data("renditions")) {
                return c.data("renditions")
            }
            var f = [],
                e = 0,
                d = "";
            c.find("SPAN").each(function() {
                if (a(this).data("src").indexOf("large") >= 0) {
                    d = a(this).data("src")
                }
            });
            c.find("SPAN").each(function() {
                f.push({
                    Src: a(this).data("src"),
                    MinWidth: e,
                    MaxWidth: a(this).data("width"),
                    altImgSrc: d
                });
                e = a(this).data("width") + 1
            });
            if (f.length > 0) {
                f[f.length - 1].MaxWidth = 9999
            }
            c.data("renditions", f);
            return f
        },
        updateCounter: function(d) {
            if (d.slides === undefined) {
                return
            }
            var c = d.find(".counter .current-image"),
                e = d.slides.index(d.find(".flex-active-slide"));
            c.html(e + 1)
        },
        version: function() {
            return "onMessage Carousel: Version 2.8"
        }
    };
    a.fn.carousel = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(h) {
                this.method = h;
                b.init.apply(this, arguments);
                var e = a(this),
                    f = e.find("li"),
                    i = e.data("options"),
                    j = e.data("vars"),
                    g = -1,
                    d;
                j.carouselID = e.attr("id").split("-")[1];
                e.data("vars", j);
                if (i.direction === "vertical" && i.animationType === "slide") {
                    if (i.captionOutside && (i.captionBottom || i.captionTop)) {
                        i.heightResetUseLi = true
                    }
                    f.each(function() {
                        var l = a(this),
                            k = (i.heightResetUseLi) ? l : l.find("img"),
                            m = k.height();
                        g = (g < m) ? m : g
                    });
                    f.height(g)
                }
                i.defaultArgs.start = function(l) {
                    j = l.data("vars");
                    var k, m = l.find("li.autoplay:not(.clone) .vjs-big-play-button");
                    if (i.contentType === "video") {
                        l.find(".vjs-big-play-button, .vjs-play-control.vjs-paused").on("click", function() {
                            l.flexslider("pause")
                        });
                        l.on("mouseleave", function() {
                            var n = l.find(".vjs-play-control.vjs-playing");
                            if (n.length > 0) {
                                l.flexslider("pause")
                            }
                        });
                        if (m.length > 0) {
                            m.click()
                        }
                    }
                    if (i.contentType === "audio") {
                        b.loadAudio(l)
                    }
                    if (i.StyleModeId <= 2) {
                        b.maybeLoadNextImages(l, 0)
                    }
                    if (i.direction === "vertical" && i.pagerType === "thumbnails") {
                        a(i.defaultArgs.sync + " .flex-viewport").height(l.height())
                    }
                    if (l.hasClass("sample-template")) {
                        a(i.defaultArgs.sync).addClass("sample-template")
                    }
                    if (i.podiumStyle) {
                        if (i.counter) {
                            k = l.find(".counter");
                            d = l.find(".flex-direction-nav");
                            d.append('<li class="counter crl-counter show">' + k.html() + "</li>");
                            k.remove()
                        }
                        if (i.showCaption) {
                            l.append('<div class="caption"><div class="caption-spacing crl-inner-details"></div></div>');
                            b.setCaption(l)
                        }
                    } else {
                        if (i.StyleModeId <= 2) {
                            b.maybeHideCaptionAll(l)
                        }
                    }
                    if (i.pagerType !== "thumbnails") {
                        l.find(".flex-control-nav").addClass("crl-pager")
                    }
                    if (i.carouselType === "photo") {
                        l.find("img").on("click", function() {
                            l.flexslider("next")
                        })
                    }
                    l.data("vars", j);
                    if (i.animationType === "fade") {
                        l.find("ul.slides li.flex-active-slide").css({
                            display: "list-item"
                        })
                    }
                    if (i.StyleModeId === 2) {
                        l.find("figure").css({
                            "min-height": l.find(".carousel-photo img").eq(0).height()
                        })
                    }
                    if (l.controlNav !== undefined) {
                        l.controlNav.on({
                            mouseenter: function() {
                                b.maybeLoadNextImages(l, a(this).parent().prevAll().length)
                            }
                        })
                    }
                    l.append('<div class="aria-live-region" aria-live="polite" aria-atomic="true" ></div>');
                    setTimeout(function() {
                        l.resize()
                    }, 750)
                };
                i.defaultArgs.before = function(l) {
                    switch (i.contentType) {
                        case "video":
                            var k = l.find(".vjs-play-control.vjs-playing");
                            if (k.length > 0) {
                                k.click()
                            }
                            l.find("li:not(.autoplay) .video-js.vjs-controls-disabled").removeClass("vjs-controls-disabled");
                            break;
                        case "audio":
                            l.find(".jp-jplayer").jPlayer("pause");
                            break
                    }
                    if (!i.podiumStyle) {
                        b.maybeHideCaption(l)
                    }
                };
                i.defaultArgs.after = function(k) {
                    j = k.data("vars");
                    i = k.data("options");
                    var n = k.find(".flex-active-slide").index();
                    var l = k.find(".flex-active-slide .carousel-photo");
                    var o = l.data("title");
                    var m = l.data("caption");
                    k.find(".aria-live-region").text(m || o);
                    if (i.direction === "vertical" && i.pagerType === "thumbnails") {
                        a(i.defaultArgs.sync + " .flex-viewport").height(k.height())
                    }
                    if (i.podiumStyle) {
                        b.setCaption(k)
                    }
                    j.pagerIndex = n;
                    if (i.counter) {
                        b.updateCounter(k)
                    }
                    if (i.StyleModeId <= 2) {
                        b.maybeLoadNextImages(k, k.currentSlide)
                    }
                    k.data("vars", j);
                    k.resize()
                };
                if (i.showCaptionOnHover) {
                    e.find("li").on({
                        mouseenter: function() {
                            a(this).find(".details").fadeIn()
                        },
                        mouseleave: function() {
                            a(this).find(".details").fadeOut()
                        }
                    })
                }
                if (i.pagerThumbnails) {
                    d = a("#carousel-nav-" + j.carouselID);
                    d.flexslider({
                        animation: "slide",
                        direction: i.direction,
                        controlNav: false,
                        animationLoop: i.loop,
                        slideshow: false,
                        itemHeight: i.thumbHeight,
                        itemWidth: i.thumbWidth,
                        itemMargin: i.thumbMargin,
                        start: function(k) {
                            k.addClass("crl-pager")
                        },
                        asNavFor: "#carousel-" + j.carouselID
                    });
                    i.defaultArgs.sync = "#carousel-nav-" + j.carouselID
                }
                e.flexslider(i.defaultArgs)
            })
        }
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(f) {
            if (f === undefined) {
                f = {}
            }
            var e, g = a.extend({
                    animate: true
                }, f),
                c = a(this),
                d = c.attr("class").split(" ");
            g.plusminus = false;
            for (e = 0; e < d.length; e++) {
                if (d[e].indexOf("menu-animate") !== -1) {
                    g.animate = (d[e].split("-")[2] === "true") ? true : false
                }
                if (d[e].indexOf("menu-always-show") !== -1) {
                    g.show = (d[e].split("-")[3] === "true") ? true : false
                }
                if (d[e] === "use-plusminus") {
                    g.plusminus = true
                }
            }
            if (c.hasClass("sample-template")) {
                g.show = true
            }
            g.offLabel = (c.attr("sub_off").length > 0) ? c.attr("sub_off") : false;
            g.hoverLabel = (c.attr("sub_hover").length > 0) ? c.attr("sub_hover") : false;
            g.onLabel = (c.attr("sub_on").length > 0) ? c.attr("sub_on") : false;
            c.data("options", g);
            b.$menu = c;
            a("body").on("resize", function(h) {
                h.stopPropagation()
            })
        },
        open: function(c, e) {
            var d = this.getMenuObject(c),
                f = b.$menu.data("options");
            d.li.addClass("on");
            if (f.onLabel) {
                d.ind.removeClass("arrow").html(f.onLabel)
            } else {
                d.ind.addClass("arrow").html("")
            }
            if (e) {
                d.sub.slideDown()
            } else {
                d.sub.css("display", "block")
            }
        },
        close: function(c, d) {
            var e = c.length;
            c.each(function() {
                var f = b.getMenuObject(c),
                    g = b.$menu.data("options");
                f.li.removeClass("on");
                if (g.offLabel) {
                    f.ind.removeClass("arrow").html(g.offLabel)
                } else {
                    f.ind.addClass("arrow").html("")
                }
                if (d) {
                    f.sub.slideUp(250)
                } else {
                    f.sub.css("display", "none")
                }
                if (e === 1) {
                    b.$menu.css("min-height", "")
                }
                e--
            })
        },
        getMenuObject: function(c) {
            var d = {};
            switch (c.prop("tagName").toLowerCase()) {
                case "a":
                    d.sub = c.next("ul");
                    d.a = c;
                    d.li = c.parent();
                    d.ind = c.find("i");
                    break;
                case "ul":
                    d.sub = c;
                    d.a = c.siblings("span.toggle");
                    d.li = c.parent();
                    break;
                case "span":
                    d.sub = c.parent().next("ul");
                    d.a = c.parent();
                    d.li = c.closest("li");
                    d.ind = c.siblings("i");
                    break;
                default:
                    d.sub = c.find("ul:eq(0)");
                    d.a = c.find("span.toggle");
                    d.li = c;
                    d.ind = c.find("i");
                    break
            }
            return d
        },
        version: function() {
            return "onMessage Accordion Menu: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        },
        debug: function() {
            var c = a(this);
            if (c.hasClass("debug")) {
                c.removeClass("debug")
            } else {
                c.addClass("debug")
            }
            return "Debug Settings Changed."
        }
    };
    a.fn.accordionmenu = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(f) {
                b.init.apply(this, arguments);
                var e = a(this),
                    g = e.data("options"),
                    d;
                e.find("span.toggle").on("click", function(h) {
                    h.preventDefault();
                    h.stopPropagation()
                });
                e.find("span.toggle").on("mousedown focusin", function(j) {
                    j.preventDefault();
                    j.stopPropagation();
                    var i = a(this),
                        h = i.closest("li");
                    if (!h.hasClass("active")) {
                        h.siblings().each(function() {
                            var k = a(this),
                                l = (g.show && k.closest("li").hasClass("active")) ? false : true;
                            if (l) {
                                b.close(k, g.animate)
                            }
                        })
                    }
                    if (h.hasClass("on")) {
                        b.close(i, g.animate)
                    } else {
                        b.open(i, g.animate)
                    }
                });
                if (g.hoverLabel) {
                    e.find("li.has-sub-menu").find("a:eq(0)").on({
                        mouseenter: function() {
                            var j = a(this),
                                i = j.parent(),
                                h = j.find("i");
                            if (!i.hasClass("on")) {
                                h.removeClass("arrow").html(g.hoverLabel)
                            }
                        },
                        mouseleave: function() {
                            var j = a(this),
                                i = j.parent(),
                                h = j.find("i");
                            if (!i.hasClass("on")) {
                                if (g.offLabel) {
                                    h.html(g.offLabel)
                                } else {
                                    h.html("").addClass("arrow")
                                }
                            } else {
                                if (g.onLabel) {
                                    h.html(g.onLabel)
                                } else {
                                    h.html("").addClass("arrow")
                                }
                            }
                        }
                    })
                }
                if (g.show) {
                    d = e.find("li.active");
                    if (d.length > 0) {
                        b.open(d, g.animate)
                    }
                }
                e.find("li a").on("focusout", function(h) {
                    var i = e.find("li:focus-within");
                    if (i.length == 0) {
                        e.find("li").each(function() {
                            var j = a(this);
                            b.close(j, g.animate)
                        })
                    }
                })
            })
        }
        a.error("Method " + c + " does not exist on jQuery.accmenu")
    }
}(jQuery));
(function(a) {
    var b = a(".breadcrumb .home");
    if (b.length === 0) {
        a(".breadcrumb ul").find("li.separator").eq(0).hide()
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(f) {
            if (f === undefined) {
                f = {}
            }
            var e, g = a.extend({
                    action: "hover",
                    type: "horizontal",
                    animate: true
                }, f),
                c = a(this),
                d;
            if (c.hasClass("menu-type-vertical") && c.closest(".layout-col").hasClass("last-col")) {
                c.removeClass("menu-direction-left").addClass("menu-direction-right")
            }
            d = c.attr("class").split(" ");
            for (e = 0; e < d.length; e++) {
                if (d[e].indexOf("menu-type") !== -1) {
                    g.type = d[e].split("-")[2]
                }
                if (d[e].indexOf("menu-action") !== -1) {
                    g.action = d[e].split("-")[2]
                }
                if (d[e].indexOf("menu-animate") !== -1) {
                    g.animate = (d[e].split("-")[2] === "true") ? true : false
                }
                if (d[e].indexOf("menu-direction") !== -1) {
                    g.direction = d[e].split("-")[2]
                }
            }
            c.data("options", g);
            return c
        },
        open: function(c, d) {
            if (d) {
                c.fadeIn()
            } else {
                c.css({
                    display: "block"
                })
            }
        },
        close: function(c, d) {
            if (d) {
                c.fadeOut()
            } else {
                c.css("display", "none")
            }
            c.css({
                left: "-10000px"
            })
        },
        positionSubMenus: function(c) {
            return undefined
        },
        version: function() {
            return "onMessage Menu: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        },
        debug: function() {
            var c = a(this);
            if (c.hasClass("debug")) {
                c.removeClass("debug")
            } else {
                c.addClass("debug")
            }
            return "Debug Settings Changed."
        },
        positionMe: function() {
            return undefined
        }
    };
    a.fn.menu = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(h) {
                var f = b.init.apply(this, arguments),
                    i = f.data("options"),
                    e = f.find(".submenu").parent(":not(nav)"),
                    g, d;
                switch (i.action) {
                    case "click":
                        e.find("a").on("click", function(m) {
                            var j = a(this),
                                l = j.next(".submenu"),
                                n = j.offset(),
                                o = parseInt(a(window).width(), 10),
                                k;
                            n.right = parseInt(l.outerWidth() * 2 + n.left, 10);
                            n.left = parseInt(j.outerWidth() * 2 + n.left, 10);
                            if (l.length === 0) {
                                b.close(f.find(".submenu:visible"), i.animate);
                                return
                            }
                            if (l.length > 0 && !l.is(":visible")) {
                                m.preventDefault();
                                k = j.closest(".submenu");
                                if (k.length >= 1) {
                                    b.close(j.find(".submenu"), i.animate)
                                } else {
                                    b.close(f.find(".submenu:visible"), i.animate)
                                }
                                if (!l.parents("ul:eq(0)").hasClass("menu-container")) {
                                    if (o <= n.right) {
                                        l.css({
                                            "z-index": n.right,
                                            left: -(j.outerWidth())
                                        })
                                    }
                                }
                                b.open(l, i.animate)
                            }
                        });
                        e.find(".submenu").on({
                            mouseleave: function() {
                                b.close(a(this), i.animate)
                            }
                        });
                        f.find(".menu-container > li").on({
                            mouseleave: function() {
                                b.close(a(this).children(".submenu"), i.animate)
                            }
                        });
                        break;
                    default:
                        d = f.find("ul.menu-container li.has-sub-menu");
                        d.on({
                            "mouseenter touchstart": function() {
                                var j = a(this),
                                    k = j.children(".submenu"),
                                    l = k.offset(),
                                    n = parseInt(a(window).width(), 10),
                                    m = 0;
                                l.right = parseInt(k.outerWidth() + l.left, 10);
                                m = k.outerWidth() * -1;
                                if (j.hasClass("level-1")) {
                                    m += j.outerWidth()
                                }
                                if (l.left !== 0) {
                                    if (n <= l.right) {
                                        k.css({
                                            left: m
                                        })
                                    }
                                }
                            },
                            mouseleave: function() {
                                var j = a(this),
                                    k = j.children(".submenu");
                                k.css({
                                    left: "-10000px"
                                })
                            }
                        });
                        break
                }
                switch (i.direction) {
                    case "up":
                        g = f.find(".menu-container > li").find(".submenu:eq(0)");
                        g.each(function() {
                            var j = a(this);
                            j.css({
                                top: -(j.height())
                            })
                        });
                        d = f.find("ul.menu-container ul li.has-sub-menu");
                        d.on({
                            mouseenter: function() {
                                var j = a(this),
                                    k = j.children(".submenu");
                                k.css({
                                    top: -(k.height() - j.outerHeight())
                                })
                            }
                        });
                        break;
                    case "right":
                        g = f.find(".menu-container li.has-sub-menu");
                        g.on({
                            mouseenter: function() {
                                var j = a(this),
                                    k = j.children(".submenu"),
                                    l = j.outerWidth(),
                                    n = k.outerWidth(),
                                    m = (l < n) ? l + (n - l) : l;
                                k.css({
                                    left: -1 * m
                                })
                            },
                            mouseleave: function() {
                                var j = a(this),
                                    k = j.children(".submenu");
                                k.css({
                                    left: "-10000px"
                                })
                            }
                        });
                        break;
                    case "left":
                        g = f.find(".menu-container li");
                        g.on({
                            mouseenter: function() {
                                var j = a(this),
                                    k = j.children(".submenu");
                                k.css({
                                    left: (k.outerWidth())
                                })
                            },
                            mouseleave: function() {
                                var j = a(this),
                                    k = j.children(".submenu");
                                k.css({
                                    left: "-10000px"
                                })
                            }
                        });
                        break
                }
                a(window).resize(function() {
                    d = f.find("ul.menu-container ul li.has-sub-menu");
                    d.each(function() {
                        var j = a(this),
                            k = j.children(".submenu");
                        k.attr("style", "")
                    })
                });
                f.find("li.has-sub-menu > a").on({
                    touchstart: function(l) {
                        var k = a(this),
                            j = k.closest(".nav-menu").find(".level-1 > a");
                        if (!k.data("clicked")) {
                            l.preventDefault()
                        }
                        j.data("clicked", false);
                        k.data("clicked", true)
                    }
                })
            })
        }
        a.error("Method " + c + " does not exist on jQuery.menu")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(f) {
            if (f === undefined) {
                f = {}
            }
            var e, g = a.extend({
                    action: "hover",
                    type: "horizontal",
                    animate: true
                }, f),
                c = a(this),
                d;
            if (c.hasClass("menu-type-vertical") && c.closest(".col").hasClass("last-col")) {
                c.removeClass("menu-direction-left").addClass("menu-direction-right")
            }
            d = c.attr("class").split(" ");
            for (e = 0; e < d.length; e++) {
                if (d[e].indexOf("menu-type") !== -1) {
                    g.type = d[e].split("-")[2]
                }
                if (d[e].indexOf("menu-action") !== -1) {
                    g.action = d[e].split("-")[2]
                }
                if (d[e].indexOf("menu-animate") !== -1) {
                    g.animate = (d[e].split("-")[2] === "true") ? true : false
                }
                if (d[e].indexOf("menu-direction") !== -1) {
                    g.direction = d[e].split("-")[2]
                }
            }
            c.data("options", g);
            return c
        },
        open: function(c, d) {
            if (d) {
                c.fadeIn()
            } else {
                c.css("display", "block")
            }
        },
        close: function(c, d) {
            if (d) {
                c.fadeOut()
            } else {
                c.css("display", "none")
            }
            c.css({
                left: -1000000
            })
        },
        positionSubMenus: function(c) {
            return undefined
        },
        version: function() {
            return "onMessage Menu: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        },
        debug: function() {
            var c = a(this);
            if (c.hasClass("debug")) {
                c.removeClass("debug")
            } else {
                c.addClass("debug")
            }
            return "Debug Settings Changed."
        }
    };
    a.fn.menu = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(f) {
                var e = b.init.apply(this, arguments),
                    g = e.data("options"),
                    d = e.find(".submenu").parent(":not(nav)");
                switch (g.action) {
                    case "click":
                        d.find("a").on("click", function(k) {
                            var h = a(this),
                                j = h.next(".submenu"),
                                l = h.offset(),
                                m = parseInt(a(window).width(), 10),
                                i;
                            l.right = parseInt(j.outerWidth() * 2 + l.left, 10);
                            l.left = parseInt(h.outerWidth() * 2 + l.left, 10);
                            if (j.length === 0) {
                                b.close(e.find(".submenu:visible"), g.animate);
                                return
                            }
                            if (j.length > 0 && !j.is(":visible")) {
                                k.preventDefault();
                                i = h.closest(".submenu");
                                if (i.length >= 1) {
                                    b.close(h.find(".submenu"), g.animate)
                                } else {
                                    b.close(e.find(".submenu:visible"), g.animate)
                                }
                                if (!j.parents("ul:eq(0)").hasClass("menu-container")) {
                                    if (m <= l.right) {
                                        j.css({
                                            "z-index": l.right,
                                            left: -(h.outerWidth())
                                        })
                                    }
                                }
                                b.open(j, g.animate)
                            }
                        });
                        d.find(".submenu").on({
                            mouseleave: function() {
                                b.close(a(this), g.animate)
                            }
                        });
                        e.find(".menu-container > li").on({
                            mouseleave: function() {
                                b.close(a(this).children(".submenu"), g.animate)
                            }
                        });
                        break;
                    default:
                        e.find("ul.menu-container li.has-sub-menu").on({
                            "touchstart mouseenter": function() {
                                var h = a(this),
                                    i = h.children(".submenu"),
                                    j = i.offset(),
                                    l = parseInt(a(window).width(), 10),
                                    k = 0;
                                j.right = parseInt(i.outerWidth() + j.left, 10);
                                k = i.outerWidth() * -1;
                                if (h.hasClass("level-1")) {
                                    k += h.outerWidth()
                                }
                                if (j.left !== 0) {
                                    if (l <= j.right) {
                                        i.css({
                                            left: k
                                        })
                                    }
                                }
                            }
                        });
                        break
                }
                switch (g.direction) {
                    case "up":
                        e.find(".menu-container > li").find(".submenu:eq(0)").each(function() {
                            var h = a(this);
                            h.css({
                                top: -(h.height())
                            })
                        });
                        e.find("ul.menu-container ul li.has-sub-menu").on({
                            mouseenter: function() {
                                var h = a(this),
                                    i = h.children(".submenu");
                                i.css({
                                    top: -(i.height() - h.outerHeight())
                                })
                            }
                        });
                        break;
                    case "right":
                        e.find(".menu-container li.has-sub-menu").on({
                            "mouseenter focusin": function() {
                                var h = a(this),
                                    i = h.children(".submenu"),
                                    j = h.outerWidth(),
                                    l = i.outerWidth(),
                                    k = (j < l) ? j + (l - j) : j;
                                i.css({
                                    left: -1 * k
                                })
                            },
                            "mouseleave focusout": function() {
                                var h = a(this),
                                    i = h.children(".submenu");
                                i.css({
                                    left: -1000000
                                })
                            }
                        });
                        break;
                    case "left":
                        e.find(".menu-container li").on({
                            mouseenter: function() {
                                var h = a(this),
                                    i = h.children(".submenu");
                                i.css({
                                    left: (i.outerWidth())
                                })
                            },
                            mouseleave: function() {
                                var h = a(this),
                                    i = h.children(".submenu");
                                i.css({
                                    left: -1000000
                                })
                            }
                        });
                        break;
                    case "down":
                        e.find(".menu-container li").on({
                            mouseleave: function() {
                                var h = a(this),
                                    i = h.children(".submenu");
                                i.css({
                                    left: ""
                                })
                            }
                        });
                        break
                }
                a(window).resize(function() {
                    e.find("ul.menu-container ul li.has-sub-menu").each(function() {
                        var h = a(this),
                            i = h.children(".submenu");
                        i.attr("style", "")
                    })
                });
                e.find("li.has-sub-menu > a").on({
                    touchstart: function(j) {
                        var i = a(this),
                            h = i.closest(".nav-menu").find(".level-1 > a");
                        if (!i.data("clicked")) {
                            j.preventDefault()
                        }
                        h.data("clicked", false);
                        i.data("clicked", true)
                    }
                });
                d.find("a").on("focusin", function(h) {
                    if (!e.hasClass("menu-accordion") && !e.hasClass("menu-type-horizontal")) {
                        d.find(".submenu").removeAttr("style")
                    }
                })
            })
        }
        a.error("Method " + c + " does not exist on jQuery.menu")
    }
}(jQuery));
(function(a) {
    var b = {
        version: function() {
            return "Horizontal Menu : Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        }
    };
    a.fn.equals = function(c) {
        var d;
        if (!c || this.length != c.length) {
            return false
        }
        for (d = 0; d < this.length; ++d) {
            if (this[d] !== c[d]) {
                return false
            }
        }
        return true
    };
    a.fn.horizontalmenu = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(f) {
                var g = {
                        menu: "",
                        init: function(l) {
                            if (l === undefined) {
                                l = {}
                            }
                            var k, m = a.extend({}, l),
                                h = a(this),
                                j = (h.attr("class") !== undefined) ? h.attr("class").split(" ") : "";
                            m.show = false;
                            for (k = 0; k < j.length; k++) {
                                if (j[k].indexOf("menu-action") !== -1) {
                                    m.action = j[k].split("-")[2]
                                }
                                if (j[k].indexOf("menu-animate") !== -1) {
                                    m.animate = (j[k].split("-")[2] === "true") ? true : false
                                }
                                if (j[k].indexOf("menu-always-show") !== -1) {
                                    m.show = true
                                }
                            }
                            h.data("options", m);
                            return h
                        },
                        open: function(h, i) {
                            if (i) {
                                h.fadeIn(250)
                            } else {
                                h.css({
                                    display: "block",
                                    opacity: "1"
                                })
                            }
                        },
                        close: function(h, i) {
                            if (i) {
                                h.fadeOut(50)
                            } else {
                                h.css({
                                    display: "none",
                                    opacity: "0"
                                })
                            }
                        },
                        openCurrent: function(h) {
                            var i = h.find("li.active .submenu.level2");
                            if (g.options.show) {
                                if (i.length > 0) {
                                    i.css({
                                        left: "0%",
                                        opacity: "1"
                                    });
                                    g.open(i, g.options.animate);
                                    h.css({
                                        "margin-bottom": i.outerHeight() + 20
                                    })
                                }
                            }
                        },
                        killAll: function(i, l) {
                            var j = i.closest(".menu-type-horizontal-flat"),
                                h = j.find(".submenu"),
                                k = i.siblings().find(".submenu");
                            k.each(function() {
                                g.close(a(this), g.options.animate, true)
                            });
                            if (l) {
                                h.each(function() {
                                    g.close(a(this), g.options.animate, true)
                                })
                            }
                        }
                    },
                    e, d;
                g.menu = g.init.apply(this, arguments);
                g.options = g.menu.data("options");
                e = g.menu.width();
                g.menu.find("li.l1-item > .submenu").width(e);
                d = g.menu.find("li");
                d.on({
                    "mouseenter focusin": function() {
                        var h = a(this),
                            i = h.children(".submenu");
                        g.killAll(h);
                        if (i.length > 0 && g.options.action == "hover") {
                            g.open(i, g.options.animate)
                        }
                    }
                });
                if (g.options.action == "click") {
                    d.find("a").on("click", function(j) {
                        var h = a(this),
                            i = h.next(".submenu");
                        g.killAll(h.parent());
                        if (i.length > 0 && !i.is(":visible")) {
                            j.preventDefault();
                            if (i.hasClass("level2") || i.parent("li").hasClass("l2-item")) {
                                i.css({
                                    left: "0%"
                                })
                            } else {
                                i.css({
                                    left: "100%"
                                })
                            }
                            g.open(i, g.options.animate)
                        }
                    })
                }
                g.openCurrent(g.menu);
                g.menu.on({
                    mouseleave: function() {
                        g.killAll(a(this).find("li.has-sub-menu"), true);
                        g.openCurrent(a(this))
                    }
                });
                d.find("a").on("focusout", function(h) {
                    var i = g.menu.find("li:focus-within");
                    if (i.length == 0) {
                        g.killAll(g.menu.find("li.has-sub-menu"), true);
                        g.openCurrent(g.menu)
                    }
                })
            })
        }
        a.error("Method " + c + " does not exist on jQuery.horizontalmenu")
    }
}(jQuery));
(function(a) {
    var b = {
        version: function() {
            return "Mega Menu : Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        }
    };
    a.fn.equals = function(c) {
        var d;
        if (!c || this.length != c.length) {
            return false
        }
        for (d = 0; d < this.length; ++d) {
            if (this[d] !== c[d]) {
                return false
            }
        }
        return true
    };
    a.fn.megamenu = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(e) {
                var f = {
                        menu: "",
                        init: function(k) {
                            if (k === undefined) {
                                k = {}
                            }
                            var j, l = a.extend({}, k),
                                g = a(this),
                                h = (g.attr("class") !== undefined) ? g.attr("class").split(" ") : "";
                            l.show = false;
                            for (j = 0; j < h.length; j++) {
                                if (h[j].indexOf("menu-action") !== -1) {
                                    l.action = h[j].split("-")[2]
                                }
                                if (h[j].indexOf("menu-animate") !== -1) {
                                    l.animate = (h[j].split("-")[2] === "true") ? true : false
                                }
                            }
                            g.data("options", l);
                            return g
                        },
                        open: function(g, h) {
                            if (h) {
                                g.fadeIn(250)
                            } else {
                                g.css({
                                    display: "block",
                                    opacity: "1"
                                })
                            }
                            g.closest("li.level-1").removeClass("closed").addClass("open")
                        },
                        close: function(g, h) {
                            if (h) {
                                g.fadeOut(50)
                            } else {
                                g.css({
                                    display: "none",
                                    opacity: "0"
                                })
                            }
                            g.closest("li.level-1").removeClass("open").addClass("closed")
                        },
                        openCurrent: function(g) {
                            var h = g.find("li.active .mega-menu-panel");
                            if (f.options.show) {
                                if (h.length > 0) {
                                    h.css({
                                        left: "0%",
                                        opacity: "1"
                                    });
                                    f.open(h, f.options.animate);
                                    g.css({
                                        "margin-bottom": h.outerHeight() + 20
                                    })
                                }
                            }
                        },
                        killAll: function(h, k) {
                            var i = h.closest(".menu-type-mega"),
                                g = i.find(".mega-menu-panel"),
                                j = h.siblings().find(".mega-menu-panel");
                            j.each(function() {
                                f.close(a(this), f.options.animate, true)
                            });
                            if (k) {
                                g.each(function() {
                                    f.close(a(this), f.options.animate, true)
                                })
                            }
                        }
                    },
                    d;
                f.menu = f.init.apply(this, arguments);
                f.options = f.menu.data("options");
                d = f.menu.find("li");
                d.on({
                    mouseenter: function() {
                        var g = a(this),
                            h = g.children(".mega-menu-panel");
                        if (f.options.action == "hover") {
                            f.killAll(g);
                            if (h.length > 0) {
                                f.open(h, f.options.animate)
                            }
                        }
                    }
                });
                if (f.options.action == "click") {
                    d.find("a").on("click", function(i) {
                        var g = a(this),
                            h = g.next(".mega-menu-panel");
                        f.killAll(g.parent());
                        if (h.length > 0) {
                            if (!h.is(":visible")) {
                                i.preventDefault();
                                if (window.head.browser.ff) {
                                    var j = h.find("iframe")[0];
                                    if (j && j.title === "Inquiry Form") {
                                        var l = j.parentElement;
                                        var k = l.removeChild(j);
                                        l.appendChild(k)
                                    }
                                }
                                if (h.hasClass("level2") || h.parent("li").hasClass("l2-item")) {
                                    h.css({
                                        left: "0%"
                                    })
                                } else {
                                    h.css({
                                        left: "100%"
                                    })
                                }
                                f.open(h, f.options.animate)
                            } else {
                                i.preventDefault();
                                f.killAll(g, true)
                            }
                        }
                    })
                }
                f.openCurrent(f.menu);
                f.menu.on({
                    mouseleave: function(g) {
                        if (g.target.tagName.toLowerCase() !== "select" && f.options.action !== "click") {
                            f.killAll(a(this).find("li"), true)
                        }
                    }
                });
                d.on({
                    focus: function() {
                        var g = a(this),
                            h = g.children(".mega-menu-panel");
                        f.killAll(g);
                        if (h.length > 0) {
                            f.open(h, f.options.animate)
                        }
                    }
                });
                d.find("a").on("focusout", function(g) {
                    var h = f.menu.find("li:focus-within");
                    if (h.length == 0) {
                        f.killAll(f.menu.find("li.has-sub-menu"), true);
                        f.openCurrent(f.menu)
                    }
                })
            })
        }
        a.error("Method " + c + " does not exist on jQuery.megamenu")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(f) {
            if (f === undefined) {
                f = {}
            }
            var e, g = a.extend({
                    animate: true
                }, f),
                c = a(this),
                d = c.attr("class").split(" ");
            for (e = 0; e < d.length; e++) {
                if (d[e].indexOf("menu-animate") !== -1) {
                    g.animate = (d[e].split("-")[2] === "true") ? true : false
                }
            }
            g.openToggle = c.attr("toggle_open");
            g.closeToggle = c.attr("toggle_close");
            g.defExpAll = (c.attr("def_exp_all").toLowerCase() === "true") ? true : false;
            c.data("options", g);
            b.$menu = c
        },
        toggle: function(c, d) {
            c.each(function() {
                var f = a(this),
                    e = f.closest("li").children("ul"),
                    g = f.closest("nav").data("options");
                switch (d) {
                    case "open":
                        if (g.animate) {
                            e.slideDown()
                        } else {
                            e.show()
                        }
                        f.html(g.openToggle).removeClass("closed").addClass("open");
                        b.$menu.data("state", "open");
                        break;
                    case "close":
                        if (g.animate) {
                            e.slideUp()
                        } else {
                            e.hide()
                        }
                        f.html(g.closeToggle).removeClass("open").addClass("closed");
                        b.$menu.data("state", "closed");
                        break
                }
            })
        },
        version: function() {
            return "onMessage Sitemap: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        }
    };
    a.fn.sitemap = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(f) {
                b.init.apply(this, arguments);
                var d = a(this),
                    e;
                d.data("state", "open");
                e = d.find("ul:eq(0) li").children(".single-toggle");
                e.on("click", function(i) {
                    i.preventDefault();
                    var h = a(this),
                        g = h.closest("li").children("ul");
                    if (g.is(":visible")) {
                        b.toggle(h, "close")
                    } else {
                        b.toggle(h, "open")
                    }
                });
                d.find(".toggle:eq(0)").on("click", function(g) {
                    g.preventDefault();
                    if (d.data("state") === "open") {
                        b.toggle(e, "close")
                    } else {
                        b.toggle(e, "open")
                    }
                });
                e.each(function(h) {
                    var g = a(this);
                    if (d.data("options").defExpAll) {
                        b.toggle(g, "open")
                    } else {
                        b.toggle(g, "close")
                    }
                })
            })
        }
        a.error("Method " + c + " does not exist on jQuery.sitemap")
    }
}(jQuery));
(function(a, e) {
    var c = e.head,
        b = a("body"),
        d;
    a.DLMenu = function(g, f) {
        this.$el = a(f);
        this._init(g)
    };
    a.DLMenu.defaults = {
        onLevelClick: function() {
            return false
        },
        onLinkClick: function() {
            return false
        }
    };
    a.DLMenu.prototype = {
        _init: function(f) {
            this.options = a.extend(true, {}, a.DLMenu.defaults, f);
            this._config();
            this._initEvents()
        },
        _config: function() {
            this.open = false;
            this.$menu = this.$el.find("ul.dl-menu");
            this.$subMenu = this.$el.find("ul.dl-submenu");
            this.$subMenuInd = this.$el.find(".mm-item div");
            this.$menuOpenBtn = this.$el.find(".mm-button");
            this.$menuCloseBtn = this.$el.find(".mm-close");
            this.$activeItems = this.$el.find(".mm-item.active-item");
            this.$lastMenuItem = this.$menu.find("li a").last();
            this.$activeItems.parent(".dl-submenu").addClass("dl-submenuOpen");
            this.$activeItems.not(":last").each(function() {
                var f = a(this);
                var g = f.find(".mm-sub-ind").first();
                g.addClass("subIndClicked")
            })
        },
        _initEvents: function() {
            this.$subMenuInd.on("mousedown focus", function(h) {
                var g = a(this);
                h.preventDefault();
                var f = g.next(".dl-submenu").toggleClass("dl-submenuOpen");
                g.children(":first").toggleClass("subIndClicked");
                if (!f.hasClass("dl-submenuOpen")) {
                    f.find(".dl-submenu").removeClass("dl-submenuOpen");
                    f.find(".mm-sub-ind").removeClass("subIndClicked")
                }
                return false
            });
            this.$menuOpenBtn.on("mousedown focus", function(g) {
                g.preventDefault();
                var f = a(".mm-close");
                if (f.length > 0) {
                    a("ul.dl-menu").addClass("dl-menuopen");
                    a(".mm-button").css({
                        opacity: "0",
                        "z-index": "1"
                    });
                    a(".mm-close").css({
                        opacity: "1",
                        "z-index": "2"
                    })
                } else {
                    a("ul.dl-menu").toggleClass("dl-menuopen");
                    a(this).toggleClass("dl-active")
                }
                return false
            });
            this.$menuCloseBtn.on("click", function() {
                event.preventDefault();
                a("ul.dl-menu").removeClass("dl-menuopen");
                a(".mm-button").css({
                    opacity: "1",
                    "z-index": "2"
                });
                a(".mm-close").css({
                    opacity: "0",
                    "z-index": "1"
                });
                a("ul.dl-submenu").removeClass("dl-submenuOpen");
                a("li .mm-sub-ind").removeClass("subIndClicked");
                return false
            });
            this.$lastMenuItem.on("blur", function() {
                a.DLMenu.prototype.closeMenu()
            });
            this.$menu.find("li a").keydown(function(t) {
                var h = a(this),
                    g = h.parent("li"),
                    j = g.next("li"),
                    p = g.prev("li"),
                    i = a("ul.dl-menu li a").last(),
                    k, q;
                switch (t.keyCode) {
                    case 37:
                        t.preventDefault();
                        t.stopPropagation();
                        var n = g.parent(".dl-submenu.dl-submenuOpen");
                        if (n && n.length > 0) {
                            var l = n.parent("li"),
                                m = l.children("a.mm-text"),
                                o = l.children("div").find(".mm-sub-ind");
                            n.removeClass("dl-submenuOpen");
                            o.removeClass("subIndClicked");
                            if (m && m.length > 0) {
                                m.focus()
                            }
                        }
                        break;
                    case 38:
                        t.preventDefault();
                        t.stopPropagation();
                        if (p && p.length > 0) {
                            if (p.hasClass("mm-menu-separator")) {
                                p = p.prev("li")
                            }
                            q = p.children("a.mm-text")
                        }
                        if (q && q.length > 0) {
                            q.focus()
                        }
                        break;
                    case 39:
                        t.preventDefault();
                        t.stopPropagation();
                        var f = g.children(".dl-submenu").length > 0;
                        if (f) {
                            var r = g.children(".dl-submenu"),
                                s = g.children("div").find(".mm-sub-ind");
                            if (!r.hasClass("dl-submenuOpen")) {
                                r.addClass("dl-submenuOpen");
                                s.addClass("subIndClicked")
                            }
                            j = r.children("li").first();
                            k = j.children("a.mm-text");
                            if (k && k.length > 0) {
                                k.focus()
                            }
                        }
                        break;
                    case 40:
                        t.preventDefault();
                        t.stopPropagation();
                        if (j && j.length > 0) {
                            if (j.hasClass("mm-menu-separator")) {
                                j = j.next("li")
                            }
                            k = j.children("a.mm-text")
                        }
                        if (k && k.length > 0) {
                            k.focus()
                        } else {
                            if (h.is(i)) {
                                a.DLMenu.prototype.closeMenu()
                            }
                        }
                        break
                }
            })
        },
        closeMenu: function() {
            a("ul.dl-menu").removeClass("dl-menuopen");
            a("ul.dl-submenu").removeClass("dl-submenuOpen")
        }
    };
    d = function(f) {
        if (e.console) {
            e.console.error(f)
        }
    };
    a.fn.dlmenu = function(g) {
        if (typeof g === "string") {
            var f = Array.prototype.slice.call(arguments, 1);
            this.each(function() {
                var h = a.data(this, "dlmenu");
                if (!h) {
                    d("cannot call methods on dlmenu prior to initialization; attempted to call method '" + g + "'");
                    return
                }
                if (!a.isFunction(h[g]) || g.charAt(0) === "_") {
                    d("no such method '" + g + "' for dlmenu instance");
                    return
                }
                h[g].apply(h, f)
            })
        } else {
            this.each(function() {
                var h = a.data(this, "dlmenu");
                if (h) {
                    h._init()
                } else {
                    h = a.data(this, "dlmenu", new a.DLMenu(g, this))
                }
            })
        }
        return this
    }
}(jQuery, window));
(function(a) {
    var b = {
        init: function() {
            var d = a(this),
                c = d.find("form");
            c.on("submit", function() {
                if (!b.validate(c)) {
                    d.find(".field-error-message").show();
                    c.find(".field-error INPUT:eq(0)").focus();
                    return false
                }
                d.find(".field-error-message").hide();
                c.find(".field-error").removeClass("field-error")
            })
        },
        version: function() {
            return "onMessage Forms: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        },
        validate: function(c) {
            var d = c.find(".required"),
                e = true;
            d.each(function() {
                var f = a(this);
                if (f.find("input").val().length === 0) {
                    f.addClass("field-error");
                    e = false
                }
            });
            return e
        }
    };
    a.fn.forms = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(d) {
                this.method = d;
                b.init.apply(this, arguments)
            })
        }
        a.error("Method " + c + " does not exist on jQuery.forms")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(d) {
            if (d === undefined) {
                d = {}
            }
            var c = a(this);
            b.$newsarchivedatepicker = c
        },
        has_styler_class: function() {
            var d, c = (a("html").attr("class") !== undefined) ? a("html").attr("class").split(" ") : "";
            for (d = 0; d < c.length; d++) {
                if (c[d].indexOf("styler") !== -1) {
                    return true
                }
            }
            return false
        }
    };
    a.fn.newsarchivedatepicker = function(c) {
        var d = function(m, f) {
            var l = window.location.origin + window.location.pathname,
                j = window.location.search.substr(1),
                e, k = "",
                h, g = j.split("&");
            if (g.indexOf("&") !== -1) {
                for (e = 0; e < g.length; e++) {
                    h = g[e].split("=");
                    if (h[0] === "MonthNumber") {
                        k += h[0] + "=" + f + "&"
                    } else {
                        if (h[0] === "YearNumber") {
                            k += h[0] + "=" + m + "&"
                        } else {
                            k += h[0] + "=" + h[1] + "&"
                        }
                    }
                }
            }
            if (k.indexOf("MonthNumber") === -1) {
                k += "MonthNumber=" + f + "&"
            }
            if (k.indexOf("YearNumber") === -1) {
                k += "YearNumber=" + m + "&"
            }
            k = k.substr(0, k.length - 1);
            window.location = l + "?" + k
        };
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(f) {
                b.init.apply(this, arguments);
                var e = a(this);
                e.find(".year-number").on("click", function(h) {
                    h.stopPropagation();
                    h.preventDefault();
                    var g = a(this),
                        i;
                    if (b.has_styler_class() == false) {
                        i = g.data("year");
                        d(i, document.getElementsByName("MonthNumber")[0].value)
                    }
                });
                e.find(".month-number").on("click", function(h) {
                    h.stopPropagation();
                    h.preventDefault();
                    var g = a(this),
                        i;
                    if (b.has_styler_class() == false) {
                        i = g.val();
                        d(document.getElementsByName("YearNumber")[0].value, i)
                    }
                })
            })
        }
        a.error("Method " + c + " does not exist")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(d) {
            if (d === undefined) {
                d = {}
            }
            var c = a(this);
            b.$newsarchivefilter = c
        },
        has_styler_class: function() {
            var d, c = (a("html").attr("class") !== undefined) ? a("html").attr("class").split(" ") : "";
            for (d = 0; d < c.length; d++) {
                if (c[d].indexOf("styler") !== -1) {
                    return true
                }
            }
            return false
        }
    };
    a.fn.newsarchivefilter = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(e) {
                b.init.apply(this, arguments);
                var d = a(this);
                d.find("a.select-all.button").on("click", function(f) {
                    f.stopPropagation();
                    f.preventDefault();
                    if (b.has_styler_class() == false) {
                        a(".newsarchivefilter .filter-item input[type=checkbox]").prop("checked", true)
                    }
                });
                d.find("a.clear-all.button").on("click", function(f) {
                    f.stopPropagation();
                    f.preventDefault();
                    if (b.has_styler_class() == false) {
                        a(".newsarchivefilter .filter-item input[type=checkbox]").prop("checked", false)
                    }
                });
                d.find("a.refresh.button").on("click", function(f) {
                    f.stopPropagation();
                    f.preventDefault();
                    if (b.has_styler_class() == false) {
                        var m = window.location.origin + window.location.pathname,
                            k = [],
                            g = document.getElementsByClassName("filter-list")[0].children,
                            n = document.getElementsByName("YearNumber")[1].value || "",
                            j = document.getElementsByName("MonthNumber")[1].value || "",
                            l, h;
                        l = "?YearNumber=" + n + "&MonthNumber=" + j;
                        for (h = 0; h < g.length; h++) {
                            if (g[h].querySelector(".news-category").checked) {
                                k.push(g[h].getElementsByClassName("news-category")[0].getAttribute("value"))
                            }
                        }
                        if (!k.length) {
                            l += "&nc="
                        } else {
                            for (h = 0; h < k.length; h++) {
                                l += "&nc=" + k[h]
                            }
                        }
                        window.location = m + l
                    }
                })
            })
        }
        a.error("Method " + c + " does not exist")
    }
}(jQuery));
(function() {
    var c, b;

    function a() {
        if (c) {
            clearTimeout(c)
        }
        c = setTimeout(function() {
            var e = $(window).scrollTop(),
                d = e + $(window).height(),
                g, f;
            b.forEach(function(h) {
                g = $(h).offset().top;
                f = g + $(h).height();
                if ((f <= d) && (g >= e)) {
                    h.src = h.dataset.src;
                    h.classList.remove("lazy")
                }
            });
            if (b.length === 0) {
                document.removeEventListener("scroll", a);
                window.removeEventListener("resize", a);
                window.removeEventListener("orientationChange", a)
            }
        }, 20)
    }
    document.addEventListener("DOMContentLoaded", function() {
        var d;
        b = document.querySelectorAll(".lazy");
        b = [].slice.call(b);
        if (window.IntersectionObserver !== undefined) {
            d = new IntersectionObserver(function(e, f) {
                e.forEach(function(g) {
                    if (g.isIntersecting) {
                        var h = g.target;
                        h.src = h.dataset.src;
                        h.classList.remove("lazy");
                        d.unobserve(h)
                    }
                })
            });
            b.forEach(function(e) {
                d.observe(e)
            })
        } else {
            a();
            document.addEventListener("scroll", a);
            window.addEventListener("resize", a);
            window.addEventListener("orientationChange", a)
        }
    })
}());
(function(a) {
    var b = {
        init: function(f) {
            if (f === undefined) {
                f = {}
            }
            var e, g = a.extend({
                    gallery: false
                }, f),
                c = a(this),
                d = (c.attr("class") !== undefined) ? c.attr("class").split(" ") : "";
            for (e = 0; e < d.length; e++) {
                if (d[e].indexOf("use-gallery") !== -1) {
                    g.gallery = true
                }
            }
            c.data("options", g);
            b.$obj = c
        },
        state: "off",
        get_current_viewport: function() {
            var d = b.get_viewports(),
                e = a(window).width(),
                c = d.desktop;
            if (e > d.large_desktop) {
                c = d.large_desktop
            } else {
                if (e < d.portrait && e > d.mobile) {
                    c = d.portrait
                } else {
                    if (e <= d.mobile) {
                        c = d.mobile
                    }
                }
            }
            return c
        },
        get_viewports: function() {
            return {
                mobile: 767,
                portrait: 979,
                desktop: 0,
                large_desktop: 1200
            }
        },
        flexdestroy: function(e) {
            var c = a(e),
                d = c.clone();
            d.find(".flex-viewport").children().unwrap();
            d.removeClass("flexslider").find(".clone, .flex-direction-nav, .flex-control-nav").remove().end().find("*").removeAttr("style").removeClass(function(g, f) {
                return (f.match(/\bflex\S+/g) || []).join(" ")
            });
            d.insertBefore(c);
            c.remove();
            b.state = "off"
        },
        version: function() {
            return "onMessage Photo List Manager: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        }
    };
    a.fn.photolist_manager = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(e) {
                b.init.apply(this, arguments);
                var d = a(this),
                    f = d.data("options");
                if (d.find("li").length > 1 && f.gallery) {
                    setInterval(function() {
                        var g = b.get_current_viewport(),
                            h = b.get_viewports();
                        if (g === h.mobile || g === h.portrait) {
                            if (b.state === "off") {
                                a(".mobile-slider").addClass("flexslider").flexslider({
                                    animation: "slide",
                                    animationLoop: true,
                                    slideshow: false,
                                    useCSS: true,
                                    touch: true,
                                    controlNav: true,
                                    directionNav: true,
                                    itemWidth: g,
                                    itemMargin: 0,
                                    minItems: 1,
                                    maxItems: 1
                                });
                                b.state = "on"
                            }
                        } else {
                            if (b.state === "on") {
                                b.flexdestroy(".mobile-slider")
                            }
                        }
                    }, 50)
                }
            })
        }
        a.error("Method " + c + " does not exist on jQuery.photolist_manager")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(d) {
            if (d === undefined) {
                d = {}
            }
            var c = a(this);
            b.$poll = c
        },
        has_styler_class: function() {
            var d, c = (a("html").attr("class") !== undefined) ? a("html").attr("class").split(" ") : "";
            for (d = 0; d < c.length; d++) {
                if (c[d].indexOf("styler") !== -1) {
                    return true
                }
            }
            return false
        },
        show_questions: function(c, e, d) {
            a(".questions#poll-ques-" + d + "-" + e).removeClass("hide");
            a(".questions#poll-ques-" + d + "-" + e).addClass("show");
            a(".results#poll-res-" + d + "-" + e).removeClass("show");
            a(".results#poll-res-" + d + "-" + e).addClass("hide")
        },
        submit_vote: function(c, e, d) {
            var f = a(".questions#poll-ques-" + d + "-" + e + " ul li input[type='radio']:checked").val();
            if (f != undefined) {
                a(".questions#poll-ques-" + d + "-" + e + " form").submit()
            } else {
                alert("Please indicate your selection")
            }
        },
        show_results: function(c, e, d) {
            a(".questions#poll-ques-" + +d + "-" + e).removeClass("show");
            a(".questions#poll-ques-" + d + "-" + e).addClass("hide");
            a(".results#poll-res-" + d + "-" + e).removeClass("hide");
            a(".results#poll-res-" + d + "-" + e).addClass("show")
        }
    };
    a.fn.poll = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(e) {
                b.init.apply(this, arguments);
                var d = a(this);
                d.find(".show-questions-button").on("click", function(g) {
                    g.stopPropagation();
                    g.preventDefault();
                    var f = a(this),
                        i, h;
                    if (b.has_styler_class() == false) {
                        i = f.parents("li.results").data("poll");
                        h = f.parents("li.results").data("group");
                        b.show_questions(f, i, h)
                    }
                });
                d.find(".submit-vote-button").on("click", function(g) {
                    g.stopPropagation();
                    g.preventDefault();
                    var f = a(this),
                        i, h;
                    if (b.has_styler_class() == false) {
                        i = f.parents("li.questions").data("poll");
                        h = f.parents("li.questions").data("group");
                        b.submit_vote(f, i, h)
                    }
                });
                d.find(".show-results-button").on("click", function(g) {
                    g.stopPropagation();
                    g.preventDefault();
                    var f = a(this),
                        i, h;
                    if (b.has_styler_class() == false) {
                        i = f.parents("li.questions").data("poll");
                        h = f.parents("li.questions").data("group");
                        b.show_results(f, i, h)
                    }
                })
            })
        }
        a.error("Method " + c + " does not exist")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(d) {
            if (d === undefined) {
                d = {}
            }
            var e = a.extend({}, d),
                c = a(this);
            c.data("options", e)
        },
        version: function() {
            return "onMessage Search: Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        }
    };
    a.fn.pageSearch = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(e) {
                b.init.apply(this, arguments);
                var d = a(this),
                    f = function(i) {
                        i.preventDefault();
                        var g = a(this),
                            h = g.find(".search-box"),
                            j = h.val();
                        j = j.replace(/[`()|;:",<>]/gi, " ").trim();
                        h.val(j);
                        g.off("submit", f);
                        g.submit()
                    };
                d.closest(".searchresults-control").on("submit", f);
                d.closest(".search-container").on("submit", f)
            })
        }
        a.error("Method " + c + " does not exist on jQuery.pageSearch")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function() {
            var d = a(this),
                c, e, g = "";
            d.find(".team-nav btn-team").addClass("active");
            d.find(".team-nav-content").hide();
            c = d.closest(".layout-col");
            e = c.attr("class").split(" ");
            for (var f = 0; f < e.length; f++) {
                if (e[f].indexOf("span") > -1) {
                    g = e[f];
                    break
                }
            }
            d.find(".team-nav-btn").on("click", function() {
                var j = a(this),
                    h = d.find(".team-nav-content.athletic-roster-new"),
                    i = d.find(".team-nav-content.athletic-schedule-new");
                j.siblings().removeClass("active");
                j.addClass("active");
                if (j.hasClass("btn-team")) {
                    d.find(".team-nav-content").hide();
                    c.find(".page-block").show()
                } else {
                    if (j.hasClass("btn-roster")) {
                        c.find('.page-block:not([data-cid="441"], .team-nav-content > .page-block)').hide();
                        if (!h.hasClass(g)) {
                            h.addClass(g)
                        }
                        i.hide();
                        h.show()
                    } else {
                        if (j.hasClass("btn-schedule")) {
                            c.find('.page-block:not([data-cid="441"],.team-nav-content > .page-block)').hide();
                            h.hide();
                            if (!i.hasClass(g)) {
                                i.addClass(g)
                            }
                            i.show()
                        }
                    }
                }
                return false
            })
        }
    };
    a.fn.athleticTeamNavigation = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(d) {
                this.method = d;
                b.init.apply(this, arguments)
            })
        }
        a.error("Method " + c + " does not exist on jQuery.forms")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(d) {
            if (d === undefined) {
                d = {}
            }
            var c = a(this);
            b.$storeproducts = c
        },
        has_styler_class: function() {
            var d, c = (a("html").attr("class") !== undefined) ? a("html").attr("class").split(" ") : "";
            for (d = 0; d < c.length; d++) {
                if (c[d].indexOf("styler") !== -1) {
                    return true
                }
            }
            return false
        }
    };
    a.fn.storeproducts = function(c) {
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(e) {
                b.init.apply(this, arguments);
                var d = a(this);
                d.find(".item-image").on("click", function(g) {
                    g.stopPropagation();
                    g.preventDefault();
                    if (b.has_styler_class() == false) {
                        var f = a(this),
                            j = f.data("zoom"),
                            i = f.data("height") || 360,
                            k = f.data("width") || 600,
                            h = '<div id="pageengine-modal" class="flush tall" ><a class="simplemodal-close modalCloseImg"></a><img src="' + j + '"></div>';
                        a.modal(h, {
                            containerCss: {
                                height: i,
                                width: k
                            }
                        })
                    }
                });
                d.find("li.page-number").on("click", function(h) {
                    h.stopPropagation();
                    h.preventDefault();
                    var f = a(this),
                        i = f.attr("data-page"),
                        g = a("#PgNbr");
                    g.val(i);
                    g.parents("form").submit()
                });
                d.find("A.add-to-cart").on("click", function(g) {
                    g.stopPropagation();
                    g.preventDefault();
                    var f = a(this),
                        h = f.data("id"),
                        i = onMessage.App.module("store");
                    i.Utilities.addToCart(h);
                    return false
                })
            })
        }
        a.error("Method " + c + " does not exist")
    }
}(jQuery));
(function(a) {
    var b = {
        init: function(d) {
            if (d === undefined) {
                d = {}
            }
            var e = a.extend({}, d),
                c = a(this);
            c.data("options", e);
            c.data("current-question", a(".question:visible").data("id"));
            c.data("phase-two", false)
        },
        version: function() {
            return "onMessage Trivia : Version 1.0"
        },
        log: function(c) {
            if (window.console) {
                window.console.debug(c)
            }
        }
    };
    a.fn.trivia = function(c) {
        if (a("html").hasClass("styler")) {
            return
        }
        if (b[c]) {
            return b[c].apply(this, Array.prototype.slice.call(arguments, 1))
        }
        if (typeof c === "object" || !c) {
            return this.each(function(e) {
                b.init.apply(this, arguments);
                var d = a(this);
                d.find(".next").on("click", function(i) {
                    i.preventDefault();
                    var g = a(".question[data-id=" + d.data("current-question") + "]"),
                        f = a(this),
                        h;
                    if (d.data("phase-two")) {
                        g.fadeOut(500, function() {
                            g.find(".part-one").show();
                            g.find(".part-two").hide();
                            g.find("input").prop("checked", false);
                            var j = g.next();
                            if (j.length === 0) {
                                j = d.find(".question").eq(0)
                            }
                            j.fadeIn();
                            d.data("current-question", j.data("id"));
                            if (j.hasClass("end")) {
                                f.html("Go to beginning");
                                return false
                            }
                            d.data("phase-two", false);
                            f.html("submit")
                        })
                    } else {
                        h = g.find("input:checked").closest(".answer-container");
                        if (h.length === 0) {
                            d.find(".trivia-error").show();
                            return false
                        }
                        d.find(".trivia-error").hide();
                        g.find(".part-one").fadeOut(500, function() {
                            h.find(".part-two").fadeIn();
                            d.data("phase-two", true);
                            f.html("Next Question")
                        })
                    }
                    return false
                })
            })
        }
        a.error("Method " + c + " does not exist on jQuery.trivia")
    }
}(jQuery));
(function() {
    function b(c) {
        return c.replace(/\w\S*/g, function(d) {
            return d.charAt(0).toUpperCase() + d.substr(1).toLowerCase()
        })
    }
    Handlebars.registerHelper("eachWithIndex", function(c, k, h) {
        var d = "",
            e, g, f;
        if (_.isArray(c)) {
            for (e = 0, g = c.length; e < g; e++) {
                f = c[e];
                f.index = e + k;
                d += h.fn(f)
            }
        }
        return d
    });
    Handlebars.registerHelper("eachWithFirstLast", function(c, h) {
        var d = "",
            e, g, f;
        if (_.isArray(c)) {
            for (e = 0, g = c.length; e < g; e++) {
                f = c[e];
                f.first = (e === 0) ? true : false;
                f.last = (e === g - 1) ? true : false;
                d += h.fn(f)
            }
        }
        return d
    });
    Handlebars.registerHelper("eachWithIndexFirstLast", function(c, k, h) {
        var d = "",
            e, g, f;
        if (_.isArray(c)) {
            for (e = 0, g = c.length; e < g; e++) {
                f = c[e];
                f.first = (e === 0) ? true : false;
                f.last = (e === g - 1) ? true : false;
                f.index = e + k;
                d += h.fn(f)
            }
        }
        return d
    });
    Handlebars.registerHelper("eachKeyValue", function(c, k) {
        if (!_.isArray(c)) {
            c = [c]
        }
        var d = "",
            h, e, g, f;
        for (e = 0, g = c.length; e < g; e++) {
            f = c[e];
            for (h in f) {
                if (f.hasOwnProperty(h)) {
                    d += k.fn({
                        key: h,
                        value: f[h]
                    })
                }
            }
        }
        return d
    });
    Handlebars.registerHelper("eachKeyValueWithContent", function(c, k) {
        if (!_.isArray(c)) {
            c = [c]
        }
        var d = "",
            h, e, g, f;
        for (e = 0, g = c.length; e < g; e++) {
            f = c[e];
            for (h in f) {
                if (f.hasOwnProperty(h) && f[h] && !_.isObject(f[h])) {
                    d += k.fn({
                        key: h,
                        value: f[h]
                    })
                }
            }
        }
        return d
    });
    Handlebars.registerHelper("eachKeyValueWithAccess", function(d, c, l) {
        if (!_.isArray(d)) {
            d = [d]
        }
        var e = "",
            k, f, h, g;
        for (f = 0, h = d.length; f < h; f++) {
            g = d[f];
            for (k in g) {
                if (g.hasOwnProperty(k) && $.inArray(k, c)) {
                    e += l.fn({
                        key: k,
                        value: g[k]
                    })
                }
            }
        }
        return e
    });
    Handlebars.registerHelper("eachKeyValueWithContentAccess", function(d, c, l) {
        if (!_.isArray(d)) {
            d = [d]
        }
        var e = "",
            k, f, h, g;
        for (f = 0, h = d.length; f < h; f++) {
            g = d[f];
            for (k in g) {
                if (g.hasOwnProperty(k) && g[k] && !_.isObject(g[k]) && $.inArray(k, c) > -1) {
                    e += l.fn({
                        key: k,
                        value: g[k]
                    })
                }
            }
        }
        return e
    });
    Handlebars.registerHelper("eachSelected", function(k, c, h) {
        var d = "",
            e, g, f;
        if (_.isArray(c)) {
            for (e = 0, g = c.length; e < g; e++) {
                f = c[e];
                f.selectedId = k;
                d += h.fn(f)
            }
        }
        return d
    });
    Handlebars.registerHelper("eachSelectedCountry", function(k, c, h) {
        var d = "",
            e, g, f;
        k = b(k);
        for (e = 0, g = c.length; e < g; e++) {
            f = c[e];
            f.selectedId = k;
            d += h.fn(f)
        }
        return d
    });
    Handlebars.registerHelper("eachSelectedActive", function(l, c, k) {
        var d = "",
            e, h, g;

        function f(i) {
            return (i == null || i.length === 0)
        }
        for (e = 0, h = c.length; e < h; e++) {
            g = c[e];
            if ((g.dd_active == true) || (!f(l) && (g.dd_id.toString() === l.toString()))) {
                g.selectedId = l;
                d += k.fn(g)
            }
        }
        return d
    });
    Handlebars.registerHelper("eachSelectedDefault", function(k, c, h) {
        var d = "",
            e, g, f;
        if (k == null) {
            if (c.length > 0) {
                if (_.has(c[0], "dd_default")) {
                    _.each(c, function(i) {
                        if (i.dd_default == true) {
                            k = i.dd_id
                        }
                    })
                }
            }
        }
        for (e = 0, g = c.length; e < g; e++) {
            f = c[e];
            f.selectedId = k;
            d += h.fn(f)
        }
        return d
    });
    Handlebars.registerHelper("eachUnique", function(c, d, p) {
        var e = "",
            q = _.chain(c).map(function(i) {
                return i.get(d)
            }).uniq().value(),
            f, m, n, o, g, h;
        for (f = 0, m = q.length; f < m; f++) {
            g = q[f];
            for (n = 0, o = c.length; n < o; n++) {
                h = c[n].get(d);
                if (g == h) {
                    e += p.fn(c[n]);
                    break
                }
            }
        }
        return e
    });
    Handlebars.registerHelper("eachUniqueToJson", function(c, d, p) {
        var e = "",
            q = _.chain(c).map(function(i) {
                return i[d]
            }).uniq().value(),
            f, m, n, o, g, h;
        for (f = 0, m = q.length; f < m; f++) {
            g = q[f];
            for (n = 0, o = c.length; n < o; n++) {
                h = c[n][d];
                if (g == h) {
                    e += p.fn(c[n]);
                    break
                }
            }
        }
        return e
    });
    Handlebars.registerHelper("eachGroupGradesByGradeLevels", function(c, d, k, j, h) {
        var g, f, e;
        if (k !== null) {
            c = _.sortBy(c, k)
        }
        if (j !== null) {
            for (f = 0; f < c.length; f++) {
                g = c[f];
                g.selectedId = j
            }
        }
        e = _.groupBy(c, d);
        return h.fn(e)
    });
    Handlebars.registerHelper("groupGradeLevelsIntoRows", function(c, e, f) {
        var g = -1,
            d;
        d = _.groupBy(c, function() {
            g++;
            return Math.floor(g / e)
        });
        d = _.values(d);
        return f.fn(d)
    });
    Handlebars.registerHelper("ifAccess", function(d, c, e) {
        return ($.inArray(d.toString(), c) > -1) ? e.fn(this) : e.inverse(this)
    });
    Handlebars.registerHelper("ifValue", function(d, c) {
        return ($.trim(d).length === 0) ? c.inverse(this) : c.fn(this)
    });
    Handlebars.registerHelper("ifEmpty", function(d, c) {
        return ($.trim(d).length === 0) ? c.fn(this) : c.inverse(this)
    });
    Handlebars.registerHelper("ifContent", function(d, c) {
        return d ? c.fn(this) : c.inverse(this)
    });
    Handlebars.registerHelper("ifContentAccess", function(d, f, c, e) {
        return (f && $.inArray(d, c) > -1) ? e.fn(this) : e.inverse(this)
    });
    Handlebars.registerHelper("ifContains", function(c, f, d) {
        if ((f || f === 0) && c) {
            var e = c;
            if (!_.isArray(e)) {
                e = e.split(",")
            }
            e = e.map(function(g) {
                return g.toString()
            });
            return (_.contains(e, f.toString())) ? d.fn(this) : d.inverse(this)
        }
        return d.inverse(this)
    });
    Handlebars.registerHelper("unlessContains", function(c, f, d) {
        if (f && c) {
            var e = c;
            if (!_.isArray(e)) {
                e = e.split(",")
            }
            e = e.map(function(g) {
                return g.toString()
            });
            return (_.contains(e, f.toString())) ? d.inverse(this) : d.fn(this)
        }
        return d.fn(this)
    });
    Handlebars.registerHelper("compare", function(c, h, f) {
        if (arguments.length < 3) {
            throw new Error("Handlebars Helper 'compare' needs 2 parameters")
        }
        var d = f.hash.operator || "==",
            e = {
                "==": function(i, j) {
                    return i == j
                },
                "===": function(i, j) {
                    return i === j
                },
                "!=": function(i, j) {
                    return i != j
                },
                "<": function(i, j) {
                    return i < j
                },
                ">": function(i, j) {
                    return i > j
                },
                "<=": function(i, j) {
                    return i <= j
                },
                ">=": function(i, j) {
                    return i >= j
                }
            },
            g;
        if (!e[d]) {
            throw new Error("Handlebars Helper 'compare' doesn't know the operator " + d)
        }
        g = e[d](c, h);
        if (g) {
            return f.fn(this)
        }
        return f.inverse(this)
    });
    Handlebars.registerHelper("comparator", function(c, d, g, f) {
        var e = {
            "==": function(h, i) {
                return h == i
            },
            "===": function(h, i) {
                return h === i
            },
            "!=": function(h, i) {
                return h != i
            },
            "<": function(h, i) {
                return h < i
            },
            ">": function(h, i) {
                return h > i
            },
            "<=": function(h, i) {
                return h <= i
            },
            ">=": function(h, i) {
                return h >= i
            },
            "||": function(h, i) {
                return h || i
            },
            "&&": function(h, i) {
                return h && i
            },
            "%": function(h, i) {
                return h % i
            }
        };
        if (arguments.length < 4) {
            throw new Error("Handlebars Helper 'comparator' needs 3 parameters")
        }
        if (!e[d]) {
            throw new Error("Handlebars Helper 'comparator' doesn't know the operator " + d)
        }
        return (e[d](c, g)) ? f.fn(this) : f.inverse(this)
    });
    Handlebars.registerHelper("ifAny", function(e) {
        var c = false,
            f, d = e.hash;
        for (f in d) {
            if (d.hasOwnProperty(f) && d[f]) {
                c = true
            }
        }
        return c ? e.fn(this) : e.inverse(this)
    });
    Handlebars.registerHelper("ifAll", function(e) {
        var c = true,
            f, d = e.hash;
        for (f in d) {
            if (d.hasOwnProperty(f) && !d[f]) {
                c = false
            }
        }
        return c ? e.fn(this) : e.inverse(this)
    });
    Handlebars.registerHelper("ifAnyBool", function() {
        var c = [].slice.apply(arguments);
        var g = c.pop();
        var e = false;
        var d = g.fn;
        for (var f = 0; f < c.length; ++f) {
            if (c[f]) {
                e = true;
                break
            }
        }
        return e ? g.fn(this) : g.inverse(this)
    });
    Handlebars.registerHelper("ifAnyValues", function(f) {
        var d = false,
            e = function(i) {
                var h = $.trim(i);
                return (h == null || h.length === 0)
            },
            g, c = f.hash;
        for (g in c) {
            if (c.hasOwnProperty(g) && !e(c[g])) {
                d = true
            }
        }
        return d ? f.fn(this) : f.inverse(this)
    });
    Handlebars.registerHelper("forWithIndex", function(k, d, h) {
        var c = "",
            e, g, f;
        for (e = k, g = d; e <= g; e++) {
            f = {};
            f.index = e;
            c += h.fn(f)
        }
        return c
    });
    Handlebars.registerHelper("forPrintRange", function(d, l) {
        var c = "",
            e = 0,
            h = 0,
            g = 100,
            f;
        while (d > 0) {
            f = {};
            if (d > 100) {
                f.index = h++;
                e = e + 1;
                f.range = e + "-" + g;
                e = g;
                g = g + 100
            } else {
                e = e + 1;
                f.index = h;
                f.range = e + "-" + (g - 100 + d)
            }
            d = d - 100;
            c += l.fn(f)
        }
        return c
    });
    Handlebars.registerHelper("ifFileType", function(c, d, e) {
        return (c && podiumApp.Utilities.FileTools.isValidFile(podiumApp.Utilities.Enum.UploadType[d], c)) ? e.fn(this) : e.inverse(this)
    });
    Handlebars.registerHelper("unlessFileType", function(c, d, e) {
        return (c && !podiumApp.Utilities.FileTools.isValidFile(podiumApp.Utilities.Enum.UploadType[d], c)) ? e.fn(this) : e.inverse(this)
    });
    Handlebars.registerHelper("eachWithHeader", function(c, f, l) {
        var d = "",
            e, g, k, h;
        if (_.isArray(c)) {
            e = null;
            for (g = 0, k = c.length; g < k; g++) {
                h = c[g];
                if (e == h[f]) {
                    h._header = null
                } else {
                    h._header = h[f];
                    e = h[f]
                }
                d += l.fn(h)
            }
        }
        return d
    });
    Handlebars.registerHelper("eachSelectedWithOptgroup", function(m, c, e, l) {
        var d = "",
            g, k, h, f = "";
        if (!_.isArray(c)) {
            c = [c]
        }
        if (c.length) {
            _.each(c, function(n, j) {
                n._optGroupEnd = undefined;
                if (n[e] !== f) {
                    f = n[e];
                    if (j > 0) {
                        c[j - 1]._optGroupEnd = true
                    }
                    n._optGroup = f
                } else {
                    n._optGroup = undefined
                }
            });
            _.last(c)._optGroupEnd = true
        }
        for (g = 0, k = c.length; g < k; g++) {
            h = c[g];
            h.selectedId = m;
            d += l.fn(h)
        }
        return d
    });
    Handlebars.registerHelper("ifStringIncludes", function(f, d, c) {
        var e = c.hash.start || 0;
        if (_.isString(f) && _.isString(d) && f.includes(d, e)) {
            return c.fn(this)
        }
        return c.inverse(this)
    });
    Handlebars.registerHelper("isSmallCollege", function(c) {
        if (podiumApp.Config.IsSmallCollege) {
            return c.fn(this)
        }
        return c.inverse(this)
    });
    Handlebars.registerHelper("booleanYesNo", function(d) {
        var c;
        if (d === null) {
            c = ""
        } else {
            if (d.toString().toLowerCase() === "true") {
                c = "Yes"
            } else {
                if (d.toString().toLowerCase() === "false") {
                    c = "No"
                } else {
                    c = d ? "Yes" : "No"
                }
            }
        }
        return c
    });
    Handlebars.registerHelper("dateTimeFormat", function(c, d, e) {
        if (e.hash) {
            e = false
        }
        if ((c != null) && (c.indexOf("00:00:00") > -1) && e) {
            var g = new RegExp("[hHmtTslL]", "g"),
                f = new RegExp("[hHmtTslL](?!.*[hHmtTslL])", "g");
            if (podiumApp.Utilities.DateTime.masks[d]) {
                d = String(podiumApp.Utilities.DateTime.masks[d])
            }
            d = d.replace(d.slice(d.search(g), d.search(f) + 1), "")
        }
        return ((c != null) && (c !== "") && (d !== "")) ? podiumApp.Utilities.DateTime.format(c, d) : null
    });
    Handlebars.registerHelper("dateFormatWithCulture", function(c, d) {
        if (typeof d !== "string") {
            d = "shortDate"
        }
        return podiumApp.Utilities.Culture.displayDate(c, d)
    });
    Handlebars.registerHelper("timeFormatWithCulture", function(c, e, d) {
        if (typeof d !== "string") {
            d = "shortTime"
        }
        return podiumApp.Utilities.Culture.displayTime(c, e, d)
    });
    Handlebars.registerHelper("datetimeSplitDate", function(d) {
        var c;
        if (d) {
            c = d.split(" ");
            c = c[0]
        } else {
            c = null
        }
        return c
    });
    Handlebars.registerHelper("dateDisplay", function(c) {
        return podiumApp.Utilities.Culture.todayAt(c, true)
    });
    Handlebars.registerHelper("streamDateDisplay", function(c) {
        return podiumApp.Utilities.Culture.todayAt(c)
    });
    Handlebars.registerHelper("dateDisplayTwoLine", function(c) {
        return podiumApp.Utilities.Culture.todayAt(c).replace(" at ", "<br>at ")
    });
    Handlebars.registerHelper("formatDateAt", function(d, c, e) {
        return podiumApp.Utilities.Culture.formatDateAt(d, c, e)
    });
    Handlebars.registerHelper("timeDisplay", function(c) {
        if (c) {
            return podiumApp.Utilities.Culture.displayTime(c, true)
        }
    });
    Handlebars.registerHelper("monthDateDisplay", function(c) {
        return podiumApp.Utilities.Culture.monthDay(c)
    });
    Handlebars.registerHelper("shortDateDisplayNoTime", function(c) {
        return podiumApp.Utilities.Culture.displayDate(c)
    });
    Handlebars.registerHelper("isSameDay", function(c, d, e) {
        return podiumApp.Utilities.Culture.isSameDay(c, d) ? e.fn(this) : e.inverse(this)
    });
    Handlebars.registerHelper("isSelected", function(d, e) {
        function c(f) {
            return (f == null || f.length === 0)
        }
        return new Handlebars.SafeString((!c(d) && !c(e) && d.toString() === e.toString()) ? ' selected="selected"' : "")
    });
    Handlebars.registerHelper("isSelectedCaseInsensitiveString", function(d, e) {
        function c(f) {
            return (f == null || f.length === 0)
        }
        return new Handlebars.SafeString((!c(d) && !c(e) && d.toLowerCase() === e.toLowerCase()) ? ' selected="selected"' : "")
    });
    Handlebars.registerHelper("isChecked", function(c) {
        return new Handlebars.SafeString(c ? ' checked="checked"' : "")
    });
    Handlebars.registerHelper("isDisabled", function(c) {
        return new Handlebars.SafeString(c ? ' disabled="disabled"' : "")
    });
    Handlebars.registerHelper("isActive", function(d, e) {
        function c(f) {
            return (f == null || f.length === 0)
        }
        return new Handlebars.SafeString((!c(d) && d.toString() === e.toString()) ? " active" : "")
    });
    Handlebars.registerHelper("outputDictionary", function(k, c, e, g) {
        var f, h = (e && !_.isObject(e)) ? e : "dd_id",
            j = (g && !_.isObject(g)) ? g : "dd_description",
            d;
        for (d = 0; d < c.length; d++) {
            if (k == c[d][h]) {
                f = c[d][j];
                break
            }
        }
        return f
    });
    Handlebars.registerHelper("outputDictionaryPlus", function(f, c) {
        var e = f,
            d;
        for (d = 0; d < c.length; d++) {
            if (f == c[d].dd_id || f == c[d].dd_description) {
                e = c[d].dd_description;
                break
            }
        }
        return e
    });
    Handlebars.registerHelper("outputDictionaryDataCheck", function(h, c, d, f) {
        var g = false,
            e;
        for (e = 0; e < d.length; e++) {
            if (h == d[e].dd_id) {
                if (c == d[e].dd_data) {
                    g = true;
                    break
                }
            }
        }
        return g ? f.fn(this) : f.inverse(this)
    });
    Handlebars.registerHelper("schoolId", function() {
        return podiumApp.Config.SchoolId
    });
    Handlebars.registerHelper("gradYear", function(c) {
        if (c) {
            return "'" + c.substring(2, 4)
        }
    });
    Handlebars.registerHelper("displayFixedDecimal", function(d, c) {
        return parseFloat(d).toFixed(c)
    });
    Handlebars.registerHelper("replace", function(e, d, c) {
        if (e) {
            return e.replace(d, c)
        }
    });
    Handlebars.registerHelper("requiredIndicator", function() {
        return new Handlebars.SafeString(podiumApp.Utilities.Validate.requiredIndicator())
    });
    Handlebars.registerHelper("sharedIndicator", function(c) {
        return '<a class="sharedIcon" rel="tooltip" data-content="" data-original-title="This is shared with:' + c + '"><i class="p3icon-share"></i></a>'
    });
    Handlebars.registerHelper("config", function(c) {
        return podiumApp.Config[c]
    });
    Handlebars.registerHelper("configLabel", function(d, c) {
        var f, e = d;
        if (d !== null && d !== undefined) {
            f = _.findWhere(podiumApp.Config.LabelDictionary, {
                Key: d.toLowerCase().split(" ").join("")
            });
            if (f !== undefined) {
                e = f.Value;
                if (c === true) {
                    e = e.toLowerCase()
                }
            }
        }
        return e
    });
    Handlebars.registerHelper("HideForSmallCollege", function(c) {
        var d = c.fn(this);
        if (podiumApp.Config.IsSmallCollege) {
            d = new Handlebars.SafeString('<div class="hide">' + c.fn(this) + "</div>")
        }
        return d
    });
    Handlebars.registerHelper("ShowForSmallCollege", function(c) {
        var d = c.fn(this);
        if (!podiumApp.Config.IsSmallCollege) {
            d = new Handlebars.SafeString('<div class="hide">' + c.fn(this) + "</div>")
        }
        return d
    });
    Handlebars.registerHelper("location", function(c) {
        return location[c]
    });
    Handlebars.registerHelper("ordinate", function(e, c) {
        var d;
        c = c || {};
        d = (c.suffix === undefined ? " Grade" : c.suffix);
        if (!isNaN(e)) {
            return podiumApp.Utilities.Tools.formatRank(e) + d
        }
        return e
    });
    Handlebars.registerHelper("formatRank", function(c) {
        return podiumApp.Utilities.Tools.formatRank(c)
    });
    Handlebars.registerHelper("formatCurrency", function(c) {
        return podiumApp.Utilities.Tools.formatCurrency(c)
    });
    Handlebars.registerHelper("formatCurrencyOutput", function(c) {
        return podiumApp.Utilities.Tools.formatCurrencyOutput(c)
    });
    Handlebars.registerHelper("formatCurrencySupCents", function(c) {
        return new Handlebars.SafeString(podiumApp.Utilities.Tools.formatCurrencySupCents(c))
    });
    Handlebars.registerHelper("currencySymbol", function(c) {
        return podiumApp.Data.SchoolContext.attributes.Culture.NumberFormat.CurrencySymbol
    });
    Handlebars.registerHelper("dateDiff", function(c, d) {
        if (c != null && d != null) {
            if (c == "now") {
                c = new Date()
            } else {
                c = new Date(c)
            }
            if (d == "now") {
                d = new Date()
            } else {
                d = new Date(d)
            }
            return c - d
        }
        return ""
    });
    Handlebars.registerHelper("ifPastDue", function(d, f, e) {
        var c;
        if (d != null && f != null) {
            if (d == "now") {
                d = new Date()
            } else {
                d = new Date(d)
            }
            if (f == "now") {
                f = new Date()
            } else {
                f = new Date(f)
            }
            c = d - f
        }
        return (c <= 0) ? e.fn(this) : e.inverse(this)
    });
    var a = {};
    Handlebars.registerHelper("recursive", function(c, d, e) {
        var f = "";
        if (e.fn !== undefined) {
            a[d] = e.fn
        }
        c.forEach(function(g) {
            f = f + a[d](g)
        });
        return f
    });
    Handlebars.registerHelper("stringMult", function(g, f) {
        var c = "",
            d, e;
        for (d = 1, e = f; d < e; d++) {
            c += g
        }
        return c
    });
    Handlebars.registerHelper("noCache", function() {
        return new Date().getTime()
    });
    Handlebars.registerHelper("getSessionState", function(c) {
        return podiumApp.getSessionState(c)
    });
    Handlebars.registerHelper("outputNewLines", function(d) {
        if (d) {
            var c = (d.toString()).replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, "$1<br>$2");
            return new Handlebars.SafeString(c)
        }
    });
    Handlebars.registerHelper("splitString", function(c) {
        if (c) {
            var d = (c.toString()).replace(/,/g, "<br>");
            return new Handlebars.SafeString(d)
        }
    });
    Handlebars.registerHelper("toZeroBased", function(c) {
        return new Handlebars.SafeString(c - 1)
    });
    Handlebars.registerHelper("toOneBased", function(c) {
        return new Handlebars.SafeString(c + 1)
    });
    Handlebars.registerHelper("valueIfFalse", function(d, e, c) {
        return d || e
    });
    Handlebars.registerHelper("escapeLimited", function(c) {
        c = Handlebars.Utils.escapeExpression(c);
        return new Handlebars.SafeString(c.replace(/&lt;BR&gt;/ig, "<br>"))
    });
    Handlebars.registerHelper("createList", function(c, d) {
        if (c != null) {
            return c.join(d)
        }
    });
    Handlebars.registerHelper("nameFormat", function(i, c, h, g, e, f, j, d) {
        return podiumApp.Utilities.Tools.nameFormat(i, c, h, g, e, f, j, d)
    });
    Handlebars.registerHelper("stripWhiteSpace", function(c) {
        return new Handlebars.SafeString(c.replace(/ /g, ""))
    });
    Handlebars.registerHelper("commalist", function(d, f) {
        var g = "",
            c, e;
        if (d) {
            for (c = 0, e = d.length; c < e; c++) {
                g = g + f.fn(d[c]) + (c !== (e - 1) ? ", " : "")
            }
        }
        return g
    });
    Handlebars.registerHelper("mediaIcon", function(c) {
        switch (c) {
            case (31):
                return "p3icon-topicPhoto";
            case (165):
                return "p3icon-topicAudio";
            case (167):
                return "p3icon-topicVideo"
        }
    });
    Handlebars.registerHelper("mediaLabel", function(c) {
        switch (c) {
            case (31):
                return "Photos";
            case (165):
                return "Clips";
            case (167):
                return "Videos"
        }
    });
    Handlebars.registerHelper("mediaCount", function(c, e, f, g) {
        var d = e;
        switch (c) {
            case (31):
                return e;
            case (165):
                return e;
            case (167):
                if (g) {
                    d = f
                }
                return d
        }
    });
    Handlebars.registerHelper("mediaCountLabel", function(c, d) {
        switch (c) {
            case (31):
                return (d != 1) ? "photos" : "photo";
            case (165):
                return (d != 1) ? "clips" : "clip";
            case (167):
                return (d != 1) ? "videos" : "video"
        }
    });
    Handlebars.registerHelper("phoneNumberLink", function(d) {
        var c = "";
        d = d.replace(/[() \-]/g, "");
        if (d.length === 10) {
            c = "1" + d
        } else {
            c = d
        }
        return c
    });
    Handlebars.registerHelper("isVideoProcessing", function(c, f, d, e) {
        var g = false;
        if (d) {
            if (!f) {
                g = true;
                if (parseInt(c, 10) === 0) {
                    g = false
                }
            }
        } else {
            if (parseInt(c, 10) > 0) {
                g = true
            }
        }
        return g ? e.fn() : e.inverse()
    });
    Handlebars.registerHelper("loadingIcon", function(c) {
        var d = (_.isString(c)) ? c : "";
        return new Handlebars.SafeString('<div class="textcenter"><img src="' + podiumApp.Config.CssImagePath + 'spinner.gif" > ' + d + "</div>")
    });
    Handlebars.registerHelper("skyLoadingIcon", function(d, c) {
        var f = (_.isString(d)) ? d : "",
            e = (_.isString(c)) ? " " + c : "";
        return new Handlebars.SafeString('<div style="position:relative; min-height:100px; min-width:100px"><div class="sky-wait-mask text-align-center' + e + '"><div class="sky-wait">' + f + "</div></div></div>")
    });
    Handlebars.registerHelper("trimString", function(d, c) {
        if (d && d.length > c) {
            d = d.substring(0, c) + "..."
        } else {
            if (d === null || d === undefined) {
                d = ""
            }
        }
        return d
    });
    Handlebars.registerHelper("captchaContainer", function() {
        return new Handlebars.SafeString(podiumApp.Utilities.Captcha.GetContainer())
    });
    Handlebars.registerHelper("stringEncodeURIComponent", function(c) {
        return encodeURIComponent(c)
    });
    Handlebars.registerHelper("stringtToLowerCase", function(c) {
        return c.toLowerCase()
    });
    Handlebars.registerHelper("filenameToId", function(c) {
        return podiumApp.Utilities.Tools.filenameToId(c)
    });
    Handlebars.registerHelper("photonForAvatar", function(c) {
        return podiumApp.Utilities.Tools.photonForAvatar(c)
    });
    Handlebars.registerHelper("photonForAvatarMedium", function(c) {
        return podiumApp.Utilities.Tools.photonForAvatarMedium(c)
    });
    Handlebars.registerHelper("photonForThumbnail", function(c) {
        return podiumApp.Utilities.Tools.photonForThumbnail(c)
    });
    Handlebars.registerHelper("stripHTML", function(c) {
        return new Handlebars.SafeString(c.replace(/<br(.|\n)*?>/g, "").replace(/<(.|\n)*?>/gi, ""))
    });
    Handlebars.registerHelper("getSumOfTwoNumbers", function(c, d) {
        return c + d
    })
}());
Backbone.View = (function(a) {
    return a.extend({
        constructor: function(b) {
            this.options = b || {};
            a.apply(this, arguments)
        }
    })
}(Backbone.View));
Backbone.Collection = (function(a) {
    var b = function(d, e) {
        var c = e.error;
        e.error = function(f) {
            if (c) {
                c(d, f, e)
            }
            d.trigger("error", d, f, e)
        }
    };
    return a.extend({
        fetch: function(d) {
            d = d ? _.clone(d) : {};
            if (d.parse === undefined) {
                d.parse = true
            }
            var e = d.success,
                c = this;
            d.success = function(g) {
                var f = d.update ? "set" : "reset";
                c[f](g, d);
                if (e) {
                    e(c, g, d)
                }
                c.trigger("sync", c, g, d)
            };
            b(this, d);
            return this.sync("read", this, d)
        },
        update: function(c, d) {
            return this.set(c, d)
        }
    })
}(Backbone.Collection));
var MQMap;
(function(c) {
    c.App = c.App || {};
    var a = c.App;
    a._modules = {};
    a.Config = {
        TemplatePath: "/page/pagesrc/",
        ApiPath: "/api/"
    };
    a.init = function(d) {
        a.Config.ApiPath = c.settings.AppDomain + "/api/";
        b();
        a.createRoutes();
        a.createHelpers();
        a.Utilities.logPageView();
        a.Utilities.checkFromHash()
    };
    a.createRoutes = function() {
        var d = Backbone.Router.extend({});
        a.Router = new d();
        a.Router.route("*path", "home", function(e) {
            a.Utilities.closeModal()
        });
        a.Router.route("photo/:id", "photo", function(e) {
            var f = a.module("media");
            f.Utilities.displayPhotoAlbum(e)
        });
        a.Router.route("audio/:id", "audio", function(e) {
            var f = a.module("media");
            f.Utilities.displayAudioAlbum(e)
        });
        a.Router.route("video/:id", "video", function(e) {
            var f = a.module("media");
            f.Utilities.displayVideoAlbum(e)
        });
        a.Router.route("giving/:id", "giving", function(f) {
            var e = a.module("forms");
            e.Utilities.displayGivingForm(f)
        });
        a.Router.route("inquiry/:id", "inquiry", function(f) {
            var e = a.module("forms");
            e.Utilities.displayInquiryForm(f)
        });
        a.Router.route("register/:id", "register", function(f) {
            var e = a.module("forms");
            e.Utilities.displayRegForm(f, c)
        });
        a.Router.route("store/cart", "storeCart", function() {
            var e = a.module("store");
            e.Utilities.displayCart()
        });
        a.Router.route(/^store\/checkout(r[0|1])?$/, "storeCheckout", function() {
            var e = a.module("store");
            e.Utilities.displayCheckout(c)
        });
        Backbone.history.start()
    };
    a.createHelpers = function() {
        Handlebars.registerHelper("comparator", function(d, e, h, g) {
            var f = {
                "==": function(i, j) {
                    return i === j
                },
                "===": function(i, j) {
                    return i === j
                },
                "!=": function(i, j) {
                    return i !== j
                },
                "!==": function(i, j) {
                    return i !== j
                },
                "<": function(i, j) {
                    return i < j
                },
                ">": function(i, j) {
                    return i > j
                },
                "<=": function(i, j) {
                    return i <= j
                },
                ">=": function(i, j) {
                    return i >= j
                },
                "typeof": function(i, k) {
                    var j = typeof i;
                    return (j === k)
                }
            };
            if (arguments.length < 4) {
                throw new Error("Handlerbars Helper 'comparator' needs 3 parameters")
            }
            if (!f[e]) {
                throw new Error("Handlerbars Helper 'comparator' doesn't know the operator " + e)
            }
            return (f[e](d, h)) ? g.fn(this) : g.inverse(this)
        });
        Handlebars.registerHelper("currency", function(d) {
            return d ? a.Utilities.formatCurrency(d) : ""
        });
        Handlebars.registerHelper("totalPrice", function(e, d) {
            return a.Utilities.formatCurrency(e * d)
        });
        Handlebars.registerHelper("formatDateWithoutTime", function(d) {
            return a.Utilities.formatDateWithoutTime(d)
        })
    };
    a.module = (function() {
        return function(d) {
            if (a._modules[d]) {
                return a._modules[d]
            }
            a._modules[d] = _.extend({
                Models: {},
                Collections: {},
                Views: {},
                Utilities: {}
            }, Backbone.Events);
            return a._modules[d]
        }
    }());
    a.Tools = {
        leadingZero: function(d) {
            return d < 10 ? "0" + d : d
        },
        parseDate: function(d) {
            var e;
            if (_.isString(d) && d.substring(0, 1) === "/") {
                e = new Date(parseInt(d.substr(6), 10))
            } else {
                e = new Date(d)
            }
            return e
        },
        shortDateDisplayNoTime: function(d) {
            var e;
            d = this.parseDate(d);
            e = d.getMonth() + 1 + "/" + d.getDate() + "/" + d.getFullYear();
            return e
        },
        timeDisplay: function(e) {
            var d, f, g;
            e = this.parseDate(e);
            d = e.getHours();
            if (d > 12) {
                d = d - 12;
                g = "PM"
            } else {
                if (d === 12) {
                    g = "PM"
                } else {
                    if (d === 0) {
                        d = 12;
                        g = "AM"
                    } else {
                        g = "AM"
                    }
                }
            }
            f = this.leadingZero(e.getMinutes());
            return d + ":" + f + " " + g
        }
    };
    a.Utilities = {
        openIframeModal: function(e, d) {
            d = d || {};
            d.Url = e;
            a.Utilities.showModal(d)
        },
        renderModalView: function(e, d) {
            d = d || {};
            d.View = e;
            a.Utilities.showModal(d)
        },
        showModal: function(j) {
            j = j || {};
            j.ContainerId = j.ContainerId || "pageengine-modal";
            var f = $("#modal_container"),
                d, i, e, k = new RegExp(/(video|photo|audio)/),
                h = window.location.hash.match(k);
            if (f.length === 0) {
                f = $('<div id="modal_container">');
                if ($("html").hasClass("touch")) {
                    f.css({
                        overflow: "auto",
                        "-webkit-overflow-scrolling": "touch"
                    })
                }
            }
            f.removeClass();
            $("#" + j.ContainerId).css({
                height: "",
                top: ""
            });
            f.modal({
                containerId: j.ContainerId,
                zIndex: 10000,
                minHeight: "300px"
            });
            if (j.View) {
                j.View.render(f)
            } else {
                if (j.Url) {
                    j.attributes = j.attributes || "";
                    e = $('<iframe class="engine-iframe" src="about:blank" width="100%" height="100%" frameborder="0" ' + j.attributes + ">");
                    f.html("").append(e);
                    e.on("load", function() {
                        if (j.Flush) {
                            var l = e.contents().find("BODY");
                            l.css({
                                overflow: "hidden"
                            })
                        }
                    });
                    e.attr("src", j.Url)
                }
            }
            d = $("#" + j.ContainerId);
            if (j.Bootstrap) {
                d.addClass("bootstrap")
            } else {
                d.removeClass("bootstrap")
            }
            if (j.Tall) {
                d.addClass("tall")
            } else {
                d.removeClass("Tall")
            }
            if (j.Flush) {
                d.addClass("flush")
            } else {
                d.removeClass("Flush")
            }
            if (j.Lightbox) {
                $(".simplemodal-wrap").addClass("lightbox")
            }
            var g = d.find(":focus");
            if (g.className !== "athlete-user") {
                $.modal.setContainerDimensions();
                $.modal.setPosition()
            }
            $(document).unbind().on("keyup", function(l) {
                if (l.keyCode === 27) {
                    a.Utilities.clearHash();
                    clearInterval(i);
                    a.Utilities.closeModal()
                }
            });
            $(".simplemodal-close").click(function(l) {
                l.preventDefault();
                var m = window.location.hash.indexOf("giving");
                if (m > 0) {
                    c.scrollSpyInit()
                }
                if (h) {
                    a.Utilities.addScrollSpyElements()
                }
                a.Utilities.clearHash();
                clearInterval(i);
                return false
            });
            i = setInterval(function() {
                $.modal.setPosition()
            }, 250);
            if (h) {
                a.Utilities.removeScrollSpyElements()
            }
        },
        renderView: function(e, d) {
            e.render(d)
        },
        closeModal: function() {
            try {
                if ($.modal) {
                    var e = window.location.hash.indexOf("giving");
                    if (e > 0) {
                        c.scrollSpyInit()
                    }
                    $.modal.close()
                }
            } catch (d) {}
        },
        trapModalFocus: function() {
            var d = document.getElementById("pageengine-modal");
            var f = d.querySelectorAll('a:not([style*="display:none"]), button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="button"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])');
            var e = f[0];
            var j = f[f.length - 1];
            var i = 9;
            var h = false;
            var g = 0;
            d.addEventListener("keydown", function(k) {
                var m = (k.key === "Tab" || k.keyCode === i);
                if (!m) {
                    return
                }
                for (var l = 0; l < f.length; l++) {
                    if (document.activeElement == f[l]) {
                        g = l;
                        h = true;
                        break
                    }
                }
                if (h) {
                    if (k.shiftKey) {
                        if (g === 0) {
                            j.focus()
                        } else {
                            f[g - 1].focus()
                        }
                        k.preventDefault()
                    } else {
                        if (g === f.length - 1) {
                            e.focus()
                        } else {
                            f[g + 1].focus()
                        }
                        k.preventDefault()
                    }
                } else {
                    e.focus();
                    k.preventDefault()
                }
            })
        },
        cancelRegistration: function() {
            window.location.reload()
        },
        clearHash: function() {
            localStorage.ScrollPosition = $(window).scrollTop();
            a.Router.navigate("", true);
            if (localStorage) {
                var d = localStorage.ScrollPosition;
                if (d) {
                    $(window).scrollTop(d);
                    localStorage.removeItem("ScrollPosition")
                }
            }
        },
        loadData: function(f, d, e) {
            return $.ajax({
                url: a.Config.ApiPath + f,
                dataType: "json",
                success: function(g) {
                    d(g)
                }
            })
        },
        fetchTemplate: function(f, d, e) {
            if (Handlebars.templates && Handlebars.templates[f]) {
                return d(Handlebars.templates[f])
            }
            return $.ajax({
                url: a.Config.TemplatePath + f,
                cache: false,
                dataType: "html",
                success: function(h) {
                    var g;
                    h = h.replace(/(\r\n|\n|\r|\t)/gm, "");
                    g = Handlebars.compile(h);
                    if (!Handlebars.templates) {
                        Handlebars.templates = {}
                    }
                    Handlebars.templates[f] = g;
                    d(g)
                }
            })
        },
        formatCurrency: function(d) {
            return "$" + d.toFixed(2)
        },
        formatDateWithoutTime: function(e) {
            var d = a.Tools.parseDate(e);
            if (!isNaN(d)) {
                return d.toISOString().slice(0, 10)
            } else {
                return ""
            }
        },
        getQueryString: function(d, h) {
            var e = h || window.location.href,
                f = new RegExp("[?&]" + d + "=([^&#]*)", "i"),
                g = f.exec(e);
            return g ? g[1] : null
        },
        urlParse: function(e) {
            var d = $("<a>", {
                href: e
            })[0];
            return {
                host: d.hostname,
                path: d.pathname,
                query: d.search,
                hash: d.hash
            }
        },
        ensureSsl: function() {
            if (c.settings.SslInd) {
                var d = document.location.toString(),
                    e, h, g, f = a.Utilities.urlParse(c.settings.SslUrl);
                if (d.indexOf(f.host) === -1) {
                    if (c.settings.SslUrl) {
                        h = c.settings.SslUrl;
                        if (h.indexOf("ssl=1") === -1) {
                            g = (h.indexOf("?") > -1 ? "&" : "?") + "ssl=1";
                            if ((h.indexOf("#") > -1)) {
                                h = h.replace("#", g + "#")
                            } else {
                                h += g
                            }
                        }
                        e = h + ((h.indexOf("#") > -1) ? "" : document.location.hash);
                        location.replace(e);
                        return false
                    }
                }
            }
            return true
        },
        logPageView: function() {
            try {
                if (!c.settings.PageTaskId || c.settings.PageTaskId <= 0 || !c.settings.PageName) {
                    return
                }
                var d = new XMLHttpRequest(),
                    h = c.settings.AppDomain + "/api/page/logview",
                    g = {
                        TaskId: c.settings.PageTaskId,
                        TaskName: c.settings.PageName,
                        SiteId: c.settings.SiteId,
                        Url: window.location.href
                    },
                    f = JSON.stringify(g);
                d.open("PUT", h, true);
                d.setRequestHeader("Content-type", "application/json");
                d.send(f)
            } catch (e) {}
        },
        logAlbumView: function(e) {
            try {
                if (!c.settings.PageTaskId || c.settings.PageTaskId <= 0 || !c.settings.PageName) {
                    return
                }
                var d = new XMLHttpRequest(),
                    g = c.settings.AppDomain + "/api/page/logalbumview/" + e;
                d.open("GET", g, true);
                d.send()
            } catch (f) {}
        },
        checkFromHash: function() {
            var e = a.Utilities.getQueryString("fromHash"),
                d = Backbone.history.fragment;
            if (e) {
                e = e.replace("%2f", "/")
            }
            if (e && (e !== d)) {
                a.Router.navigate(e, true)
            }
        },
        removeScrollSpyElements: function() {
            var d = $("nav ul li.scrollspy-item"),
                e = $("*[data_scrollspy]");
            d.removeClass("scrollspy-item");
            d.addClass("scrollspy-item-remove");
            e.each(function() {
                var f = $(this);
                f.attr({
                    data_scrollspy_remove: f.attr("data_scrollspy")
                }).removeAttr("data_scrollspy")
            })
        },
        addScrollSpyElements: function() {
            var d = $("nav ul li.scrollspy-item-remove"),
                e = $("*[data_scrollspy_remove]");
            d.removeClass("scrollspy-item-remove");
            d.addClass("scrollspy-item");
            e.each(function() {
                var f = $(this);
                f.attr({
                    data_scrollspy: f.attr("data_scrollspy_remove")
                }).removeAttr("data_scrollspy_remove")
            })
        }
    };

    function b() {
        var f = $("#__AjaxAntiForgery").children().val(),
            e, d;
        if (f) {
            e = Backbone.sync;
            Backbone.sync = function(g, h, i) {
                if (g !== "fetch" && g !== "read") {
                    d = i.beforeSend;
                    i.beforeSend = function(k, j) {
                        k.setRequestHeader("RequestVerificationToken", f);
                        if (d) {
                            d(k, j)
                        }
                    }
                }
                return e(g, h, i)
            };
            $.ajaxSetup({
                beforeSend: function(h, g) {
                    if ((!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(g.type)) && g.url && g.url.indexOf("/api/") > 0) {
                        h.setRequestHeader("RequestVerificationToken", f)
                    }
                }
            })
        }
    }
}(onMessage));
(function(a) {
    a.Captcha = {
        Settings: {
            ScriptLoaded: false,
            SiteKey: "6LcYjggTAAAAAFZixPQotuvtEmFn-MSObAelDNa8",
            ContainerId: "g_recaptcha",
            ErrorContainerId: "g_recaptcha_error",
            WidgetId: null,
            RenderOptions: {}
        },
        GetContainer: function() {
            return '<div id="' + a.Captcha.Settings.ContainerId + '"></div><div class="alert alert-danger" id="' + a.Captcha.Settings.ErrorContainerId + '">Please complete the Captcha test.</div>'
        },
        Initialize: function(b) {
            a.Captcha.Dispose();
            b = b || {};
            if (!b.sitekey) {
                b.sitekey = a.Captcha.Settings.SiteKey
            }
            a.Captcha.Settings.RenderOptions = b;
            if (a.Captcha.Settings.ScriptLoaded) {
                a.Captcha.Render();
                return true
            }
            var c = document.createElement("script");
            c.src = "https://www.google.com/recaptcha/api.js?onload=reCaptchaCallback&render=explicit";
            c.async = true;
            c.defer = true;
            document.head.appendChild(c);
            a.Captcha.Settings.ScriptLoaded = true;
            return true
        },
        Dispose: function() {
            a.Captcha.Settings.RenderOptions = {};
            a.Captcha.Settings.WidgetId = null;
            $("#" + a.Captcha.Settings.ContainerId).empty();
            a.Captcha.HideError()
        },
        Render: function() {
            if (a.Captcha.Settings.WidgetId !== null) {
                grecaptcha.reset(a.Captcha.Settings.WidgetId)
            } else {
                a.Captcha.Settings.WidgetId = grecaptcha.render(a.Captcha.Settings.ContainerId, a.Captcha.Settings.RenderOptions)
            }
        },
        GetResponse: function() {
            return grecaptcha.getResponse(a.Captcha.Settings.WidgetId)
        },
        DisplayError: function() {
            $("#" + a.Captcha.Settings.ErrorContainerId).show()
        },
        HideError: function() {
            $("#" + a.Captcha.Settings.ErrorContainerId).hide()
        }
    }
}(onMessage.App.Utilities));
var reCaptchaCallback = function() {
    onMessage.App.Utilities.Captcha.Render()
};
(function(a, b) {
    b.Utilities.displayPhotoAlbum = function(d) {
        var c = {
            Id: 0,
            ContentTypeId: 31,
            Style: {
                Id: 0,
                StyleTypeId: 3,
                StyleModeId: 1,
                ContentTypeId: 31,
                Options: {
                    Header: {
                        Visible: false
                    },
                    Title: {
                        Visible: true
                    },
                    Caption: {
                        Visible: true
                    },
                    LongDescription: {
                        Visible: true
                    },
                    Description: {
                        Visible: true
                    },
                    Details: {
                        Visible: true,
                        Location: "inside",
                        Position: "bottom",
                        Shows: "hover"
                    },
                    Counter: {
                        Visible: true,
                        Alignment: "left",
                        Position: "top"
                    },
                    Pager: {
                        Visible: false,
                        Type: "shapes",
                        Alignment: "center",
                        Position: "bottom",
                        Location: "outside"
                    },
                    Arrows: {
                        Visible: true
                    }
                }
            }
        };
        a.Utilities.openIframeModal("/page/tmpl?albumid=" + d + "&ismodal=true&block=" + encodeURI(JSON.stringify(c)), {
            Flush: true
        });
        a.Utilities.logAlbumView(d)
    };
    b.Utilities.displayAudioAlbum = function(d) {
        var c = {
            Id: 0,
            ContentTypeId: 165,
            Style: {
                Id: 0,
                StyleTypeId: 1,
                StyleModeId: 1,
                ContentTypeId: 165,
                Options: {
                    Header: {
                        Visible: false
                    },
                    Title: {
                        Visible: true
                    },
                    Caption: {
                        Visible: true
                    },
                    LongDescription: {
                        Visible: true
                    },
                    AlbumSelect: {
                        Visible: true
                    },
                    AlbumName: {
                        Visible: true
                    }
                }
            }
        };
        a.Utilities.openIframeModal("/page/tmpl?albumid=" + d + "&ismodal=true&block=" + encodeURI(JSON.stringify(c)));
        a.Utilities.logAlbumView(d)
    };
    b.Utilities.displayVideoAlbum = function(d) {
        var c = {
            Id: 0,
            ContentTypeId: 167,
            Style: {
                Id: 0,
                StyleTypeId: 3,
                StyleModeId: 1,
                ContentTypeId: 167,
                Options: {
                    Header: {
                        Visible: false
                    },
                    Title: {
                        Visible: true
                    },
                    Caption: {
                        Visible: true
                    },
                    LongDescription: {
                        Visible: true
                    },
                    Description: {
                        Visible: true
                    },
                    Details: {
                        Visible: true,
                        Location: "inside",
                        Position: "bottom",
                        Shows: "hover"
                    },
                    Counter: {
                        Visible: true,
                        Alignment: "left",
                        Position: "top"
                    },
                    Pager: {
                        Visible: false,
                        Type: "shapes",
                        Alignment: "center",
                        Position: "bottom",
                        Location: "outside"
                    },
                    Arrows: {
                        Visible: true
                    }
                }
            }
        };
        a.Utilities.openIframeModal("/page/tmpl?albumid=" + d + "&ismodal=true&block=" + encodeURI(JSON.stringify(c)), {
            Flush: true,
            attributes: "allowfullscreen webkitallowfullscreen mozallowfullscreen"
        });
        a.Utilities.logAlbumView(d)
    }
}(onMessage.App, onMessage.App.module("media")));
(function(a, b) {
    b.Utilities.displayGivingForm = function(f) {
        if (a.Utilities.ensureSsl()) {
            var d = "",
                e = null,
                g = f,
                c = null;
            if (f.indexOf("r") > 0) {
                c = f.split("r");
                if (c.length > 1) {
                    g = c[0];
                    e = c[1]
                }
            }
            if (e !== undefined && e !== null) {
                d = "&r=" + e
            }
            a.Utilities.openIframeModal("/podium/default.aspx?t=1706&pe=1&pem=1&co=1&wapp=1&pk=" + g + d + "&invuri=" + encodeURIComponent(window.location.href), {
                Tall: true
            })
        }
    };
    b.Utilities.displayInquiryForm = function(c) {
        if (a.Utilities.ensureSsl()) {
            a.Utilities.openIframeModal("/podium/default.aspx?t=1705&pe=1&pem=1&co=1&wapp=1&pk=" + c, {
                Tall: true
            })
        }
    };
    b.Utilities.displayRegForm = function(f, g) {
        if (a.Utilities.ensureSsl()) {
            var d = "",
                e = null,
                h = f,
                c = null;
            if (f.indexOf("r") > 0) {
                c = f.split("r");
                if (c.length > 1) {
                    h = c[0];
                    e = c[1]
                }
            }
            if (e !== undefined && e !== null) {
                d = "&r=" + e
            }
            a.Utilities.openIframeModal("/podium/default.aspx?t=36644&pe=1&pem=1&co=1&wapp=1&rid=" + h + d + "&invuri=" + encodeURIComponent(window.location.href), {
                Tall: true
            })
        }
    }
}(onMessage.App, onMessage.App.module("forms"), onMessage));
(function(a, b) {
    b.Data = {
        ProductOptions: {}
    };
    b.Models.ProductOptions = Backbone.Model.extend({
        idAttribute: "ProductId",
        urlRoot: function() {
            return a.Config.ApiPath + "store/productoptions"
        }
    });
    b.Models.CartGuid = Backbone.Model.extend({
        urlRoot: function() {
            return a.Config.ApiPath + "store/cartguid"
        }
    });
    b.Models.CartItem = Backbone.Model.extend({
        idAttribute: "StoreCartId",
        urlRoot: function() {
            return a.Config.ApiPath + "store/cartitem"
        }
    });
    b.Models.CartTotal = Backbone.Model.extend({
        url: function() {
            return a.Config.ApiPath + "store/carttotal"
        }
    });
    b.Collections.Cart = Backbone.Collection.extend({
        model: b.Models.CartItem,
        url: function() {
            return a.Config.ApiPath + "store/cart"
        }
    });
    b.Views.Cart = Backbone.View.extend({
        template: "Store/Cart/store.cart.template.html",
        initialize: function() {
            this.collection.on("reset", this.renderTemplate, this);
            this.itemViews = []
        },
        render: function(c) {
            var d = this;
            $(c).html(d.el)
        },
        renderTemplate: function() {
            var c = this;
            a.Utilities.fetchTemplate(c.template, function(d) {
                c.$el.html(d({
                    cart: c.collection.toJSON()
                }));
                c.renderItems();
                c.renderTotal();
                c.$el.find(".close").click(function(f) {
                    f.preventDefault();
                    if (c.isValid()) {
                        a.Utilities.clearHash();
                        return false
                    }
                })
            })
        },
        renderItems: function() {
            var d = this,
                c = d.$el.find("#cart_product_list");
            d.itemViews = [];
            d.collection.each(function(f) {
                var e = new b.Views.CartItem({
                    model: f
                });
                e.on("save", function() {
                    d.renderTotal()
                }).on("error", function() {
                    d.isValid()
                }).on("remove", function() {
                    d.collection.fetch()
                });
                d.itemViews.push(e);
                a.Utilities.renderView(e, c)
            })
        },
        renderTotal: function() {
            var e = this,
                c = e.$el.find("#cart_total"),
                d = new b.Models.CartTotal();
            d.fetch({
                success: function() {
                    var f = new b.Views.CartTotal({
                        model: d
                    });
                    f.on("gocheckout", function() {
                        if (e.isValid()) {
                            a.Router.navigate("store/checkout", true)
                        }
                    });
                    a.Utilities.renderView(f, c)
                }
            })
        },
        isValid: function() {
            var e = this,
                d = true,
                c = 0;
            _.each(e.itemViews, function(f) {
                d = f.isValid();
                if (!d) {
                    c++;
                    return
                }
            });
            if (!d) {
                $("#cart_error").show()
            } else {
                $("#cart_error").show()
            }
            return (c === 0)
        }
    });
    b.Views.CartItem = Backbone.View.extend({
        template: "Store/Cart/store.cart.item.template.html",
        tagName: "tr",
        events: {
            "change .cartitem-logo": "updateItem",
            "change .cartitem-size": "updateItem",
            "change .cartitem-color": "updateItem",
            "change .cartitem-ship": "updateItem",
            "change .cartitem-qty": "updateItem",
            "click .cartitem-delete": "removeItem"
        },
        initialize: function() {
            this.model.on("change", this.renderTemplate, this)
        },
        render: function(c) {
            var d = this;
            $(c).append(d.el);
            d.renderTemplate()
        },
        renderTemplate: function() {
            var c = this;
            a.Utilities.fetchTemplate(c.template, function(d) {
                c.loadProductOptions(function(h) {
                    c.$el.html(d({
                        cartItem: c.model.toJSON(),
                        itemOptions: h
                    }));
                    if (h.Logos && h.Logos.length > 0 && !c.model.get("Logo")) {
                        var f = c.$el.find(".cartitem-logo:first");
                        if (f && f.length > 0) {
                            c.model.set({
                                Logo: f.val()
                            }, {
                                silent: true
                            });
                            f.attr("checked", true)
                        }
                    } else {
                        var g = c.$el.find(".cartitem-logo");
                        if (g && g.length > 0) {
                            var e = g.filter("[value = " + c.model.get("Logo") + "]")
                        }
                        if (e && e.length > 0) {
                            e.attr("checked", true)
                        }
                    }
                    $.modal.setPosition()
                })
            })
        },
        loadProductOptions: function(c) {
            var f = this,
                d = f.model.get("ProductId"),
                e;
            if (b.Data.ProductOptions[d]) {
                return c(b.Data.ProductOptions[d])
            }
            e = new b.Models.ProductOptions({
                ProductId: d
            });
            e.fetch({
                success: function() {
                    b.Data.ProductOptions[d] = e.toJSON();
                    return c(b.Data.ProductOptions[d])
                }
            })
        },
        updateItem: function(i) {
            var l = this,
                d = l.$el.find(".cartitem-logo"),
                h = l.$el.find(".cartitem-size"),
                c = l.$el.find(".cartitem-color"),
                g = l.$el.find(".cartitem-ship"),
                f = l.$el.find(".cartitem-qty"),
                k = {},
                j;
            if (d.length > 0) {
                k.Logo = d.filter(":checked").val()
            }
            if (h.length > 0) {
                k.Size = h.val()
            }
            if (c.length > 0) {
                k.Color = c.val()
            }
            if (g.length > 0) {
                k.StoreCartShipping = g.val()
            }
            if (f.length > 0) {
                k.Quantity = f.val()
            }
            l.model.set(k, {
                silent: true
            });
            if (isNaN(f.val()) || f.val() < 1) {
                l.trigger("error")
            } else {
                j = l.model.get("SalePrice");
                if (j === undefined || j === null || isNaN(j) || parseInt(j, 10) < 0) {
                    l.model.set("SalePrice", 0)
                }
                l.model.save({}, {
                    success: function() {
                        l.trigger("save")
                    },
                    error: function() {
                        l.trigger("error")
                    }
                })
            }
        },
        removeItem: function(c) {
            c.stopPropagation();
            c.preventDefault();
            var d = this;
            d.model.destroy({
                success: function() {
                    d.trigger("remove")
                }
            });
            return false
        },
        isValid: function() {
            var f = this,
                c = true,
                d = f.model.get("ProductId"),
                e = b.Data.ProductOptions[d];
            f.$el.find("td").removeClass("bootstrap-error");
            if (f.model.get("Quantity") <= 0) {
                f.$el.find(".cartitem-qty").closest("td").addClass("bootstrap-error");
                c = false
            }
            if (e) {
                if (e.Sizes && e.Sizes.length > 0) {
                    if (!f.model.get("Size")) {
                        f.$el.find(".cartitem-size").closest("td").addClass("bootstrap-error");
                        c = false
                    }
                }
                if (e.Colors && e.Colors.length > 0) {
                    if (!f.model.get("Color")) {
                        f.$el.find(".cartitem-color").closest("td").addClass("bootstrap-error");
                        c = false
                    }
                }
                if (e.Logos && e.Logos.length > 0) {
                    if (!f.model.get("Logo")) {
                        f.$el.find(".cartitem-logo").closest("td").addClass("bootstrap-error");
                        c = false
                    }
                }
            }
            return c
        }
    });
    b.Views.CartTotal = Backbone.View.extend({
        template: "Store/Cart/store.cart.total.template.html",
        events: {
            "click #cart_checkout": "sendToCheckout"
        },
        render: function(c) {
            var d = this;
            $(c).html(d.el);
            d.renderTemplate()
        },
        renderTemplate: function() {
            var c = this;
            a.Utilities.fetchTemplate(c.template, function(d) {
                c.$el.html(d({
                    cartTotal: c.model.toJSON()
                }))
            })
        },
        sendToCheckout: function() {
            var c = this;
            c.trigger("gocheckout")
        }
    });
    b.Utilities.addToCart = function(d) {
        var c = new b.Models.CartItem({
            ProductId: d
        });
        c.save({}, {
            success: function() {
                a.Router.navigate("store/cart", true)
            }
        })
    };
    b.Utilities.displayCart = function() {
        if (a.Utilities.ensureSsl()) {
            var c = new b.Collections.Cart();
            a.Utilities.renderModalView(new b.Views.Cart({
                collection: c
            }), {
                Bootstrap: true
            });
            c.fetch({})
        }
    };
    b.Utilities.displayCheckout = function() {
        if (a.Utilities.ensureSsl()) {
            var f = "",
                g = null,
                i = window.location.href,
                c = "",
                e = null,
                d = null,
                h = null;
            if (i.indexOf("#") > -1) {
                e = i.split("#store/");
                if (e.length > 0) {
                    c = e[1];
                    if (c.indexOf("r") > -1) {
                        d = c.split("r");
                        if (d.length > 0) {
                            g = d[1]
                        }
                    }
                }
            }
            if (g !== undefined && g !== null) {
                f = "&r=" + g
            }
            h = new b.Models.CartGuid();
            h.fetch({
                success: function() {
                    a.Utilities.openIframeModal("/podium/default.aspx?t=8984&pe=1&pem=1&co=1&wapp=1&cartguid=" + h.get("CartGuid") + f + "&invuri=" + encodeURIComponent(i), {
                        Tall: true
                    })
                }
            })
        }
    }
}(onMessage.App, onMessage.App.module("store"), onMessage));
(function(a, b) {
    b.Models.Comment = Backbone.Model.extend({
        idAttribute: "Id",
        url: function() {
            return a.Config.ApiPath + "news/commentsave/?format=json"
        }
    });
    b.Collections.Comments = Backbone.Collection.extend({
        model: b.Models.Comment,
        initialize: function(c) {
            this.newsId = c.NewsId || 0;
            this.dateSortOrder = c.DateSortOrder || 0
        },
        url: function() {
            return a.Config.ApiPath + "news/commentsget/" + this.newsId + "?format=json&sortOrder=" + this.dateSortOrder
        }
    });
    b.Views.Comment = Backbone.View.extend({
        el: $(".newscommententry"),
        events: {
            "click #saveComment": "saveComment",
            "change input": "clearError",
            "change textarea": "clearError",
            "click #captcharefresh": "captchaRefresh"
        },
        initialize: function() {
            this.newsId = this.options.NewsId || 0
        },
        saveComment: function(c) {
            $("span").removeClass("bootstrap-error");
            var h = this,
                f, g = "",
                d = $("#h_lastname");
            if (d && d.val().length == 0) {
                h.model.set({
                    Id: 1,
                    NewsId: h.newsId,
                    FirstName: $(".newscommententry #FirstName").val(),
                    LastName: $(".newscommententry #LastName").val(),
                    Email: $(".newscommententry #Email").val(),
                    Comment: $(".newscommententry #Comment").val(),
                    honeypotFieldResponse: d.val()
                });
                if (h.isModelValid()) {
                    h.model.save({}, {
                        error: function(i, j) {
                            var e;
                            $("#saveMessage").hide();
                            if (j && j.responseJSON && j.responseJSON.ErrorType && j.responseJSON.ErrorType == "INVALID_PARAMETER") {
                                e = " Invalid values entered."
                            } else {
                                e = j
                            }
                            b.Utilities.displayError(e, $(".newscommententry #message"))
                        },
                        success: function(e, i) {
                            $("input").val("");
                            $(".comment").val("");
                            f = new b.Models.Comment(i);
                            switch (f.get("ApprovalType")) {
                                case 0:
                                    g = "Your comment was submitted successfully!";
                                    break;
                                case 1:
                                    g = "Your comment was submitted and will appear once approved.";
                                    break;
                                case 2:
                                    g = "You will be e-mailed a confirmation link that you must click to post your comment.";
                                    break
                            }
                            $("#saveMessage").html("<h5>" + g + "</h5><br />");
                            $("#saveMessage").show();
                            h.trigger("commentSaved", h.model)
                        }
                    })
                } else {
                    b.Utilities.displayError("Please enter all required information", $(".newscommententry #message"))
                }
            }
            return false
        },
        clearError: function(c) {
            $("#" + c.target.id + "Group").removeClass("error");
            $("#saveMessage").hide()
        },
        isModelValid: function() {
            var d = this,
                c = true;
            d.$el.find("#FirstName").closest("div").removeClass("bootstrap-error");
            if (d.model.get("FirstName").trim().length === 0) {
                d.$el.find("#FirstName").closest("div").addClass("bootstrap-error");
                c = false
            }
            d.$el.find("#LastName").closest("div").removeClass("bootstrap-error");
            d.$el.find("#LasttName").removeClass("bootstrap-error");
            if (d.model.get("LastName").trim().length === 0) {
                d.$el.find("#LastName").closest("div").addClass("bootstrap-error");
                c = false
            }
            d.$el.find("#Email").closest("div").removeClass("bootstrap-error");
            d.$el.find("#Email").removeClass("bootstrap-error");
            if (d.model.get("Email").trim().length === 0) {
                d.$el.find("#Email").closest("div").addClass("bootstrap-error");
                c = false
            } else {
                if (!/^([^@]+@[^\.@\+'][^@\'\+]*\.[a-z]{2,})*$/.test(d.model.get("Email"))) {
                    d.$el.find("#Email").closest("div").addClass("bootstrap-error");
                    c = false
                }
            }
            d.$el.find("#Comment").closest("div").removeClass("bootstrap-error");
            d.$el.find("#Comment").removeClass("bootstrap-error");
            if (d.model.get("Comment").trim().length === 0) {
                d.$el.find("#Comment").closest("div").addClass("bootstrap-error");
                c = false
            }
            return c
        }
    });
    b.Utilities.postComment = function(f, c) {
        var d = new b.Models.Comment({
                NewsId: f
            }),
            e = new b.Views.Comment({
                model: d,
                NewsId: f,
                Cid: c
            });
        e.saveComment()
    };
    b.Views.Error = Backbone.View.extend({
        className: "alert",
        render: function(c) {
            this.$el.html(this.options.message).addClass(this.options.messageClass);
            $(c).append(this.el).fadeIn(1000).delay(3000).fadeOut(1000)
        }
    });
    b.Utilities.displayError = function(d, c) {
        c.html("");
        c.show();
        a.Utilities.renderView(new b.Views.Error({
            message: d,
            messageClass: "alert-error"
        }), c)
    }
}(onMessage.App, onMessage.App.module("NewsComments")));
(function(a, b) {
    b.Models.GameGet = Backbone.Model.extend({
        idAttribute: "ScheduleId",
        url: function() {
            return a.Config.ApiPath + "athleticschedule/gameview?format=json&scheduleId=" + this.get("ScheduleId")
        }
    });
    b.Models.PracticeDetailsGet = Backbone.Model.extend({
        idAttribute: "ScheduleId",
        url: function() {
            return a.Config.ApiPath + "datadirect/practicedetailsget?format=json&scheduleId=" + this.get("ScheduleId")
        }
    });
    b.Views.GameScheduleDetailsView = Backbone.View.extend({
        template: "athletics/teamschedule/athleticschedule.details.template.html",
        events: {
            "click .close": "closeModal"
        },
        closeModal: function(c) {
            c.preventDefault();
            a.Utilities.closeModal();
            return false
        },
        initialize: function() {
            this.scheduleItem = this.options.scheduleItem
        },
        render: function(d) {
            var i = this,
                g = false,
                h = false,
                f = i.scheduleItem,
                e, c = [];
            if (f.ScrimmageInd) {
                c.push("Scrimmage")
            }
            if (f.TournamentInd) {
                c.push("Tournament")
            }
            if (f.InvitationalInd) {
                c.push("Invitational")
            }
            if (f.PlayoffInd) {
                c.push("Playoff")
            }
            if (i.options.showTransprtation) {
                if (f.DismissalTime || (f.Vehicles && f.Vehicles.length > 0) || f.DepartureNote || f.DepartureTime || f.PickupNote || f.PickupTime || f.AdditionalNotes) {
                    g = true
                }
            }
            e = f.LocationDetail;
            if (e && (e.Directions || e.MapUrl || e.AddressLine1)) {
                h = true;
                if (e.Directions) {
                    e.Directions = e.Directions.replace(/\r/g, "<br />")
                }
            }
            $(".simplemodal-close").attr("tabindex", "0");
            a.Utilities.fetchTemplate(i.template, function(l) {
                var k = "",
                    j = "";
                if (e && e.AddressLine1) {
                    k = e.AddressLine1;
                    j = e.AddressLine1;
                    if (e.AddressLine2) {
                        k += " " + e.AddressLine2;
                        j += "<br />" + e.AddressLine2
                    }
                    if (e.AddressLine3) {
                        k += " " + e.AddressLine3;
                        j += "<br />" + e.AddressLine3
                    }
                    if (e.City) {
                        k += " " + e.City;
                        j += "<br />" + e.City
                    }
                    if (e.StateShort) {
                        k += " " + e.StateShort;
                        if (e.City) {
                            j += ", " + e.StateShort
                        } else {
                            j += "<br />" + e.StateShort
                        }
                    }
                    if (e.Zip) {
                        k += " " + e.Zip;
                        if (e.City || e.State) {
                            j += " " + e.Zip
                        } else {
                            j += "<br />" + e.Zip
                        }
                    }
                }
                i.$el.html(l({
                    scheduleItem: f,
                    showDetail: g,
                    showDirections: h,
                    address: j,
                    categories: c.join(", ")
                }));
                $(d).html(i.el);
                if (e && e.AddressLine1) {
                    b.Utilities.addMapScript(k)
                }
                a.Utilities.trapModalFocus()
            })
        }
    });
    b.Views.PracticeDetailsView = Backbone.View.extend({
        template: "athletics/teamschedule/practice.details.template.html",
        events: {
            "click .close": "closeModal"
        },
        closeModal: function(c) {
            c.preventDefault();
            a.Utilities.closeModal();
            return false
        },
        initialize: function() {
            this.scheduleItem = this.options.scheduleItem
        },
        render: function(c) {
            var g = this,
                e = false,
                f = false,
                d = g.scheduleItem;
            if (g.options.showTransprtation) {
                if (d.DismissalTime || (d.Vehicles && d.Vehicles.length > 0) || d.DepartureNote || d.DepartureTime || d.PickupNote || d.PickupTime || d.AdditionalNotes) {
                    e = true
                }
            }
            if (d.directions || d.map_url || d.line_one) {
                f = true;
                if (d.directions) {
                    d.directions = d.directions.replace(/\r/g, "<br />")
                }
            }
            $(".simplemodal-close").attr("tabindex", "0");
            a.Utilities.fetchTemplate(g.template, function(j) {
                var i = "",
                    h = "";
                if (d.line_one) {
                    i = d.line_one;
                    h = d.line_one;
                    if (d.line_two) {
                        i += " " + d.line_two;
                        h += "<br />" + d.line_two
                    }
                    if (d.line_three) {
                        i += " " + d.line_three;
                        h += "<br />" + d.line_three
                    }
                    if (d.city) {
                        i += " " + d.city;
                        h += "<br />" + d.city
                    }
                    if (d.state_short) {
                        i += " " + d.state_short;
                        if (d.city) {
                            h += ", " + d.state_short
                        } else {
                            h += "<br />" + d.state_short
                        }
                    }
                    if (d.zip) {
                        i += " " + d.zip;
                        if (d.city || d.state_short) {
                            h += " " + d.zip
                        } else {
                            h += "<br />" + d.zip
                        }
                    }
                }
                g.$el.html(j({
                    scheduleItem: d,
                    showDetail: e,
                    showDirections: f,
                    address: h
                }));
                $(c).html(g.el);
                if (d.line_one) {
                    b.Utilities.addMapScript(i)
                }
                a.Utilities.trapModalFocus()
            })
        }
    });
    b.Views.Error = Backbone.View.extend({
        className: "alert",
        render: function(c) {
            this.$el.html(this.options.message).addClass(this.options.messageClass);
            $(c).append(this.el).fadeIn(1000).delay(3000).fadeOut(1000)
        }
    });
    b.Utilities.showDirections = function(e, g, c) {
        var f, d;
        if (c) {
            f = b.Utilities.getPracticeDetails(e);
            d = new b.Views.PracticeDetailsView({
                scheduleItem: f.toJSON(),
                showTransprtation: g
            })
        } else {
            f = b.Utilities.getGameDetails(e);
            d = new b.Views.GameScheduleDetailsView({
                scheduleItem: f.toJSON(),
                showTransprtation: g
            })
        }
        a.Utilities.renderModalView(d, {
            Bootstrap: false,
            Lightbox: true
        })
    };
    b.Utilities.getGameDetails = function(d) {
        var c = new b.Models.GameGet({
            ScheduleId: d
        });
        c.fetch({
            async: false,
            error: function(e, f) {
                b.Utilities.displayError("Error loading game")
            },
            success: function() {
                var h = new Date(c.get("Gamedate")),
                    f, e = a.Tools.shortDateDisplayNoTime(h),
                    k = a.Tools.timeDisplay(h),
                    g, j = 0,
                    l;
                c.set("StartTime", k);
                if (c.get("GameEndDate")) {
                    f = new Date(c.get("GameEndDate"));
                    g = a.Tools.timeDisplay(f);
                    c.set("EndTime", g)
                } else {
                    c.set("GameEndDate", e)
                }
                c.set("StartDisplay", k);
                c.set("Gamedate", e);
                c.set("OpponentId", 0);
                c.set("Team", c.get("Team"));
                if (c.get("ScheduleType") === 0 && c.get("Opponents").length === 1) {
                    c.set("OpponentId", c.get("Opponents")[0].Id)
                }
                if (c.get("Opponents").length > 0 && c.get("Opponents").length < 2) {
                    c.set("OpponentName", c.get("Opponents")[0].Name)
                } else {
                    if (c.get("Opponents").length > 1) {
                        c.set("OpponentName", "Multiple")
                    } else {
                        c.set("OpponentName", "")
                    }
                }
                if (c.get("Vehicles").length > 0) {
                    l = c.get("Vehicles");
                    for (j = 0; j < l.length; j++) {
                        l[j].BeginTime = l[j].BeginDate.split(" ", 2)[1];
                        l[j].BeginDate = l[j].BeginDate.split(" ", 2)[0];
                        l[j].EndTime = l[j].EndDate.split(" ", 2)[1];
                        l[j].EndDate = l[j].EndDate.split(" ", 2)[0]
                    }
                }
                if (c.get("DismissalTime") === "00:00:00") {
                    c.set("DismissalTime", "")
                } else {
                    c.set("DismissalTime", a.Tools.timeDisplay(e + " " + c.get("DismissalTime")))
                }
                if (c.get("DepartureTime") === "00:00:00") {
                    c.set("DepartureTime", "")
                } else {
                    c.set("DepartureTime", a.Tools.timeDisplay(e + " " + c.get("DepartureTime")))
                }
                if (c.get("PickupTime") === "00:00:00") {
                    c.set("PickupTime", "")
                } else {
                    c.set("PickupTime", a.Tools.timeDisplay(e + " " + c.get("PickupTime")))
                }
                if (c.get("LeagueInd")) {
                    c.set("Classification", "League")
                } else {
                    c.set("Classification", "Non-League")
                }
                if (c.get("ScrimmageInd")) {
                    c.set("Category", "Scrimmage")
                }
                if (c.get("TournamentInd")) {
                    c.set("Category", "Tournament")
                }
                if (c.get("InvitationalInd")) {
                    c.set("Category", "Invitational")
                }
                if (c.get("PlayoffInd")) {
                    c.set("Category", "Playoff")
                }
                if ((!c.get("ScrimmageInd")) && (!c.get("TournamentInd")) && (!c.get("InvitationalInd")) && (!c.get("PlayoffInd"))) {
                    c.set("Category", "")
                }
            }
        });
        return c
    };
    b.Utilities.getPracticeDetails = function(d) {
        var c = new b.Models.PracticeDetailsGet({
            ScheduleId: d
        });
        c.fetch({
            async: false,
            error: function(e, f) {
                b.Utilities.displayError("Error loading practice")
            },
            success: function() {
                var h = new Date(c.get("event_date_start")),
                    f, e, g;
                c.set("PracticeDate", a.Tools.shortDateDisplayNoTime(h));
                c.set("StartTime", a.Tools.timeDisplay(new Date("01/01/2000 " + c.get("start_time"))));
                c.set("EndTime", a.Tools.timeDisplay(new Date("01/01/2000 " + c.get("end_time"))));
                if (c.get("student_dismissal_time")) {
                    f = new Date(c.get("student_dismissal_time"));
                    c.set("DismissalTime", a.Tools.timeDisplay(f))
                }
                if (c.get("departure_time")) {
                    e = new Date(c.get("departure_time"));
                    c.set("DepartureTime", a.Tools.timeDisplay(e))
                }
                if (c.get("pickuptime")) {
                    g = new Date(c.get("pickuptime"));
                    c.set("PickupTime", a.Tools.timeDisplay(g))
                }
            }
        });
        return c
    };
    b.Utilities.displayError = function(d, c) {
        c.html("");
        a.Utilities.renderView(new b.Views.Error({
            message: d,
            messageClass: "alert-error"
        }), c)
    };
    b.Utilities.addMapScript = function(c) {
        var f, d = $("#map-container"),
            e = $("#map-link");
        if (b.MapData.MQMap) {
            d.show();
            b.MapData.MQMap = new Microsoft.Maps.Map("#bing-map", {
                zoom: 12
            });
            b.MapData.MQMap.entities.clear();
            b.MapData.geocodeQuery(c)
        } else {
            if (window.location.protocol === "https:") {
                f = "https://www.bing.com/api/maps/mapcontrol?callback=GetMap"
            } else {
                f = "http://www.bing.com/api/maps/mapcontrol?callback=GetMap"
            }
            head.js(f, function() {
                window.GetMap = function() {
                    d.show();
                    b.MapData.MQMap = new Microsoft.Maps.Map("#bing-map", {
                        credentials: "SOg3kx9B8b8QFO8qTAi6~aMoA9TLDaXoobrXJe8N9qg~AnFujmbftpAk0WjCGdragIldj-ac_00Qk8VXMb4HFwPyWXIRb2ckmwJdzusI2fiD",
                        zoom: 12
                    });
                    b.MapData.geocodeQuery(c)
                }
            })
        }
        e.show();
        e.attr("href", "http://bing.com/maps/default.aspx?rtp=~adr." + encodeURIComponent(c))
    };
    b.MapData = {
        geocodeQuery: function(c) {
            if (!b.MapData.searchManager) {
                Microsoft.Maps.loadModule("Microsoft.Maps.Search", function() {
                    b.MapData.searchManager = new Microsoft.Maps.Search.SearchManager(b.MapData.MQMap);
                    b.MapData.geocodeQuery(c)
                })
            } else {
                var d = {
                    where: c,
                    callback: function(f) {
                        if (f && f.results && f.results.length > 0) {
                            var e = new Microsoft.Maps.Pushpin(f.results[0].location, {
                                icon: "/podium/images/mapMarker.png",
                                title: c
                            });
                            b.MapData.MQMap.entities.push(e);
                            b.MapData.MQMap.setView({
                                bounds: f.results[0].bestView,
                                padding: 80
                            })
                        }
                    }
                };
                b.MapData.searchManager.geocode(d)
            }
        }
    }
}(onMessage.App, onMessage.App.module("AthleticSchedule")));
(function(a, b) {
    b.Models.Athlete = Backbone.Model.extend({
        idAttribute: "UserId",
        url: function() {
            return a.Config.ApiPath + "datadirect/athletedetailsget?format=json&athleteId=" + this.get("UserId") + "&sectionId=" + this.get("SectionId")
        }
    });
    b.Views.AthleteDetailsView = Backbone.View.extend({
        template: "athletics/roster/athleticroster.details.template.html",
        events: {
            "click .close": "closeModal"
        },
        closeModal: function(c) {
            c.preventDefault();
            a.Utilities.closeModal();
            return false
        },
        initialize: function() {
            this.athlete = this.options.athlete
        },
        render: function(c) {
            var e = this,
                d = document.getElementById("pageengine-modal");
            a.Utilities.fetchTemplate(e.template, function(f) {
                e.$el.html(f({
                    athlete: e.athlete
                }));
                document.body.insertAdjacentElement("afterbegin", e.el);
                $(c).html(e.el);
                d.style.removeProperty("height");
                d.style.removeProperty("width");
                d.style.setProperty("height", "auto", "important");
                d.style.setProperty("width", "auto", "important")
            })
        }
    });
    b.Utilities.showAthleteDetails = function(d, f) {
        var c, e;
        c = b.Utilities.getAthleteDetails(d, f);
        e = new b.Views.AthleteDetailsView({
            athlete: c.toJSON()
        });
        a.Utilities.renderModalView(e, {
            Bootstrap: false,
            Lightbox: true
        })
    };
    b.Utilities.getAthleteDetails = function(d, e) {
        var c = new b.Models.Athlete({
            UserId: d,
            SectionId: e
        });
        c.fetch({
            async: false
        });
        return c
    }
}(onMessage.App, onMessage.App.module("AthleticRoster")));
(function(a, b) {
    b.Models.ActiveModelForSite = Backbone.Model.extend({});
    b.Models.StyleModelForSite = Backbone.Model.extend({});
    b.Collections.ActiveCollectionForSite = Backbone.Collection.extend({
        model: b.Models.ActiveModelForSite,
        url: function() {
            return a.Config.ApiPath + "emergencybulletin/ActiveViewForSite?format=json&siteId=" + onMessage.settings.SiteId
        }
    });
    b.Collections.BulletinStylesForSite = Backbone.Collection.extend({
        model: b.Models.StyleModelForSite,
        url: function() {
            return a.Config.ApiPath + "emergencybulletin/BulletinStylesForSite?format=json&siteId=" + onMessage.settings.SiteId
        }
    });
    b.Views.ActiveBannerViewForSite = Backbone.View.extend({
        template: "emergencybulletin/emergencybulletin.banner.template.html",
        initialize: function() {
            this.SiteId = this.options.SiteId
        },
        render: function() {
            var c = this;
            a.Utilities.fetchTemplate(c.template, function(d) {
                c.$el.html(d({
                    data: {
                        bulletins: c.collections.bulletins.toJSON(),
                        styles: c.collections.styles.toJSON()
                    }
                }));
                document.body.insertAdjacentElement("afterbegin", c.el);
                b.Utilities.bulletinBanner.init()
            })
        }
    });
    b.Views.ActiveLightBoxViewForSite = Backbone.View.extend({
        template: "emergencybulletin/emergencybulletin.lightbox.template.html",
        initialize: function() {
            this.SiteId = this.options.SiteId
        },
        render: function(c) {
            var d = this;
            a.Utilities.fetchTemplate(d.template, function(e) {
                d.$el.html(e({
                    data: {
                        bulletins: d.collections.bulletins.toJSON(),
                        styles: d.collections.styles.toJSON()
                    }
                }));
                document.body.insertAdjacentElement("afterbegin", d.el);
                b.Utilities.bulletinLightbox.init()
            });
            return d
        }
    });
    b.Views.Error = Backbone.View.extend({
        className: "alert",
        render: function(c) {
            this.$el.html(this.options.message).addClass(this.options.messageClass);
            $(c).append(this.el).fadeIn(1000).delay(3000).fadeOut(1000)
        }
    });
    b.Utilities.processEmergencyBulletins = function() {
        var c = new b.Collections.ActiveCollectionForSite();
        c.fetch({
            async: false,
            error: function(d, f, e) {
                b.Utilities.displayError("Error loading emergency bulletin")
            },
            success: function() {
                if (c.length > 0) {
                    b.Utilities.renderBulletins(c)
                }
            }
        })
    };
    b.Utilities.displayError = function(d, c) {
        c.html("");
        a.Utilities.renderView(new b.Views.Error({
            message: d,
            messageClass: "alert-error"
        }), c)
    };
    b.Utilities.renderBulletins = function(f) {
        var c = new b.Collections.ActiveCollectionForSite(f.filter(function(i) {
                return i.get("DisplayAsBanner")
            })),
            h = new b.Collections.ActiveCollectionForSite(f.filter(function(i) {
                return i.get("DisplayAsLightbox")
            })),
            d, e, g = new b.Collections.BulletinStylesForSite();
        g.fetch({
            async: false,
            success: function() {
                if (g.length > 0) {
                    (g.at(0).toJSON().Table1).forEach(function(i) {
                        i.display_settings = JSON.parse(i.display_settings)
                    })
                }
            }
        });
        c = b.Utilities.showEmergencyBulletin("om-ebb", c);
        if (c.length > 0) {
            d = new b.Views.ActiveBannerViewForSite();
            d.collections = {
                bulletins: c,
                styles: g
            };
            d.render()
        }
        h = b.Utilities.showEmergencyBulletin("om-ebl", h);
        if (h.length > 0) {
            e = new b.Views.ActiveLightBoxViewForSite();
            e.collections = {
                bulletins: h,
                styles: g
            };
            e.render("body")
        }
    };
    b.Utilities.bulletinLightbox = {
        init: function() {
            var c = $("#emergency-bulletin-lightbox");
            if (c.length > 0) {
                c.bulletinLightbox()
            }
        }
    };
    b.Utilities.bulletinBanner = {
        init: function() {
            var c = $("#emergency-bulletin-banner");
            c.bulletinBanner();
            onMessage.fixRegion();
            onMessage.scrollSpyInit()
        }
    };
    b.Utilities.showEmergencyBulletin = function(g, d) {
        var f = decodeURI(onMessage.tools.getCookie(g)).split(","),
            j = 0,
            h, e, c;
        for (j = 0; j < f.length; j++) {
            h = f[j].split("|");
            e = parseInt(h[0], 10);
            if (h.length > 1) {
                c = h[1]
            }
            d.remove(d.find(function(i) {
                var k = a.Tools.parseDate(i.get("BeginDateTime"));
                if (!isNaN(k)) {
                    k = k.toISOString().slice(0, 10)
                } else {
                    k = ""
                }
                return i.get("BroadcastId") == e && k == c && !i.get("DisplayAlways")
            }))
        }
        return d
    }
}(onMessage.App, onMessage.App.module("EmergencyBulletin")));

function ical_download(r, i, q, g, u, f, l, d, c, p, t, o, a, b) {
    $("a.calendarAnchor").remove();
    var s, n, m, h, j, v, k, e;
    v = $("#calendarType option:selected").val();
    if (v === "") {
        return false
    }
    s = r.split(" ");
    if (s[1] === "PM") {
        s = s[0].split(":");
        if (12 + parseInt(s[0], 10) !== 24) {
            r = 12 + parseInt(s[0], 10) + ":" + s[1] + ":00"
        } else {
            r = "12:" + s[1] + ":00"
        }
    } else {
        s = s[0].split(":");
        if (s[0].length === 1) {
            s[0] = "0" + s[0]
        }
        if (s[0] === "12") {
            r = "00:" + s[1] + ":00"
        } else {
            r = s[0] + ":" + s[1] + ":00"
        }
    }
    if (u === "" && p === "game") {
        if (o !== "" && a === "") {
            u = t + " vs. " + o + " - " + b
        } else {
            if (o !== "" && a !== "") {
                u = t + " vs. " + o + " - " + b + " - " + a
            } else {
                if (o === "" && a === "") {
                    u = t + " - " + b
                } else {
                    u = t + " - " + b + " - " + a
                }
            }
        }
    }
    if (p === "game" && !i) {
        n = r.split(":");
        m = parseInt(n[0], 10) + 3;
        if (m < 10) {
            m = "0" + m
        }
        if (m > 24) {
            h = g.split("/");
            g = h[0] + "/" + (parseInt(h[1], 10) + 1) + "/" + h[2];
            i = "0" + (parseInt(m, 10) - 24) + ":" + n[1] + ":" + n[2]
        } else {
            i = m + ":" + n[1] + ":" + n[2]
        }
    }
    if (r === "") {
        r = "00:00:00"
    }
    j = i;
    j = i.split(" ");
    if (j[1] === "PM") {
        j = j[0].split(":");
        if (12 + parseInt(j[0], 10) !== 24) {
            i = 12 + parseInt(j[0], 10) + ":" + j[1] + ":00"
        } else {
            i = "12:" + j[1] + ":00"
        }
    } else {
        j = j[0].split(":");
        i = j[0] + ":" + j[1] + ":00"
    }
    q = q.split(" ");
    q = q[0].split("/");
    if (q[0].length === 1) {
        q[0] = "0" + q[0]
    }
    if (q[1].length === 1) {
        q[1] = "0" + q[1]
    }
    q = q[2] + "/" + q[0] + "/" + q[1];
    g = g.split(" ");
    g = g[0].split("/");
    if (g[0].length === 1) {
        g[0] = "0" + g[0]
    }
    if (g[1].length === 1) {
        g[1] = "0" + g[1]
    }
    g = g[2] + "/" + g[0] + "/" + g[1];
    k = {
        title: u,
        location: l,
        description: f,
        dateAlpha: q.replace(/[^0-9]+/g, ""),
        dateOmega: g.replace(/[^0-9]+/g, ""),
        timeAlpha: r.replace(/[^0-9]+/g, ""),
        timeOmega: i.replace(/[^0-9]+/g, "")
    };
    k.getAlpha = function() {
        var w = this.dateAlpha;
        if (this.timeAlpha !== "") {
            if (this.timeAlpha.length === 3) {
                this.timeAlpha = "0" + this.timeAlpha
            }
            w += "T" + this.timeAlpha
        }
        return w
    };
    k.getOmega = function() {
        var w = this.dateOmega;
        if (this.timeOmega !== "") {
            if (this.timeOmega.length === 3) {
                this.timeOmega = "0" + this.timeOmega
            }
            w += "T" + this.timeOmega
        }
        return w
    };
    $(".athletic-directions").append('<a href="" target="_blank" class="calendarAnchor"></a>');
    if (v === "google") {
        e = ["action=TEMPLATE", "text=" + encodeURIComponent(k.title), "dates=" + k.getAlpha() + "/" + k.getOmega(), "details=" + encodeURIComponent(k.description), "location=" + encodeURIComponent(k.location)];
        $("a.calendarAnchor").attr("href", "https://www.google.com/calendar/event?" + e.join("&"))
    } else {
        e = ["BEGIN:VCALENDAR", "VERSION:2.0", "METHOD:REQUEST", "BEGIN:VEVENT", "DTSTAMP:" + d, "DTSTART:" + k.getAlpha(), "DTEND:" + k.getOmega(), "LOCATION:" + k.location, "DESCRIPTION:" + k.description, "SUMMARY:" + k.title, "SEQUENCE:0", "END:VEVENT", "END:VCALENDAR"];
        if (v === "outlook") {
            $("a.calendarAnchor").attr("download", "event.ics").attr("href", "data:text/calendar;charset=utf8," + encodeURI(e.join("\n")))
        }
        if (v === "outlookcom") {
            $("a.calendarAnchor").attr("download", "event.ics").attr("href", "data:text/calendar;charset=utf8," + encodeURI(e.join("\n")))
        }
        if (v === "ateappleical") {
            $("a.calendarAnchor").attr("download", "event.ics").attr("href", "data:text/calendar;charset=utf8," + encodeURI(e.join("\n")))
        }
    }
    $("a.calendarAnchor")[0].click()
};